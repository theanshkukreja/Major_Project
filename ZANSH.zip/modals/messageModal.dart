enum Type {text, image}

class Message {

  Message({
    required this.read,
    required this.fromId,
    required this.toId,
    required this.type,
    required this.message,
    required this.sent,
    this.isApplication = "false",
  });

  late String read;
  late String fromId;
  late String toId;
  late Type type;
  late String message;
  late String sent;
  late String isApplication;  //isApplication

  Message.fromJson(Map<String, dynamic> json){
    isApplication = json['isApplication'].toString();
    read = json['read'].toString();
    fromId = json['from_id'].toString();
    toId = json['to_id'].toString();
    type = json['type'].toString() == Type.image.name ? Type.image : Type.text;
    message = json['message'].toString();
    sent = json['sent'].toString();
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['isApplication'] = isApplication;
    data['read'] = read;
    data['from_id'] = fromId;
    data['to_id'] = toId;
    data['type'] = type.name;
    data['message'] = message;
    data['sent'] = sent;
    return data;
  }
}
