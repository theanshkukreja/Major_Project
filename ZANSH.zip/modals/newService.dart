class ServicePost {
  ServicePost({
    required this.image,
    required this.sFeesPer,
    required this.latitude,
    required this.sCity,
    required this.sTitle,
    required this.uploadTime,
    required this.isJob,
    required this.sDesc,
    required this.sVisibility,
    required this.sFees,
    required this.name,
    required this.sState,
    required this.sStreetAddress,
    required this.sImage,
    required this.sPhone,
    required this.email,
    required this.longitude,
    required this.likes,
    required this.sFeesCurrency,
    required this.callAction,
    required this.chatAction,
    required this.postViews,
    this.distance = 0,
    this.duration,
    required this.id,
  });
  late final String image;
  late final String sFeesPer;
  late final String latitude;
  late final String sCity;
  late final String sTitle;
  late final String uploadTime;
  late final String sVisibility;
  late final String sFeesCurrency;
  late final bool isJob;
  late final String sDesc;
  late final String sFees;
  late final String name;
  late final String sState;
  late final String sStreetAddress;
  late final String sImage;
  late final String email;
  late final String longitude;
  late final String likes;
  late final String callAction;
  late final String chatAction;
  late final String postViews;
  late final String sPhone;
  late double? distance;
  late int? duration;
  late String id;

  ServicePost.fromJson(Map<String, dynamic> json){
    id = json['id']  ?? '';
    postViews = json['postViews']  ?? '';
    callAction = json['callAction']  ?? '';
    chatAction = json['chatAction']  ?? '';
    sPhone = json['sPhone']  ?? '';
    image = json['image']  ?? '';
    sVisibility = json['sVisibility'] ?? '';
    sFeesPer = json['sFeesPer']  ?? '';
    latitude = json['latitude']  ?? '';
    sFeesCurrency = json['sFeesCurrency']  ?? '';
    sCity = json['sCity']  ?? '';
    sTitle = json['sTitle']  ?? '';
    uploadTime = json['uploadTime']  ?? '';
    isJob = json['isJob']  ?? '';
    sDesc = json['sDesc']  ?? '';
    sFees = json['sFees']  ?? '';
    name = json['name']  ?? '';
    sState = json['sState']  ?? '';
    sStreetAddress = json['sStreetAddress']  ?? '';
    sImage = json['sImage']  ?? '';
    email = json['email']  ?? '';
    longitude = json['longitude']  ?? '';
    likes = json['likes']  ?? '';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['postViews'] = postViews;
    data['chatAction'] = chatAction;
    data['callAction'] = callAction;
    data['sPhone'] = sPhone;
    data['image'] = image;
    data['sVisibility'] = sVisibility;
    data['sFeesPer'] = sFeesPer;
    data['latitude'] = latitude;
    data['sCity'] = sCity;
    data['sFeesCurrency'] = sFeesCurrency;
    data['sTitle'] = sTitle;
    data['uploadTime'] = uploadTime;
    data['isJob'] = isJob;
    data['sDesc'] = sDesc;
    data['sFees'] = sFees;
    data['name'] = name;
    data['sState'] = sState;
    data['sStreetAddress'] = sStreetAddress;
    data['sImage'] = sImage;
    data['email'] = email;
    data['longitude'] = longitude;
    data['likes'] = likes;
    return data;
  }
}