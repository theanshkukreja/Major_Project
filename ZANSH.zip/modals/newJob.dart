class JobPost {
  JobPost({
    required this.jCity,
    required this.image,
    required this.jRequirements,
    required this.jSalaryCurrency,
    required this.latitude,
    required this.jImage,
    required this.uploadTime,
    required this.jDesc,
    required this.isJob,
    required this.jState,
    required this.jisItAWorkFromHome,
    required this.jSalary,
    required this.jVisibility,
    required this.name,
    required this.jSalaryPer,
    required this.jType,
    required this.jTitle,
    required this.jStreetAddress,
    required this.email,
    required this.likes,
    required this.longitude,
    required this.callAction,
    required this.chatAction,
    required this.postViews,
    required this.jPhone,
    this.distance = 0,
    this.duration,
    required this.id,
  });
  late final String jCity;
  late final String image;
  late final String jRequirements;
  late final String jSalaryCurrency;
  late final String latitude;
  late final String jImage;
  late final String jVisibility;
  late final String uploadTime;
  late final String jDesc;
  late final bool isJob;
  late final String jState;
  late final bool jisItAWorkFromHome;
  late final String jSalary;
  late final String name;
  late final String jSalaryPer;
  late final String jType;
  late final String jTitle;
  late final String jStreetAddress;
  late final String email;
  late final String likes;
  late final String longitude;
  late final String callAction;
  late final String chatAction;
  late final String postViews;
  late final String jPhone;
  late double? distance;
  late int? duration;
  late String id;

  JobPost.fromJson(Map<String, dynamic> json){
    id = json['id']  ?? '';
    postViews = json['postViews']  ?? '';
    callAction = json['callAction']  ?? '';
    chatAction = json['chatAction']  ?? '';
    jPhone = json['jPhone'] ?? '';
    jCity = json['jCity']  ?? '';
    image = json['image']  ?? '';
    jVisibility = json['jVisibility'] ?? '';
    jRequirements = json['jRequirements']  ?? '';
    jSalaryCurrency = json['jSalaryCurrency']  ?? '';
    latitude = json['latitude']  ?? '';
    jImage = json['jImage']  ?? '';
    uploadTime = json['uploadTime']  ?? '';
    jDesc = json['jDesc']  ?? '';
    isJob = json['isJob']  ?? '';
    jState = json['jState']  ?? '';
    jisItAWorkFromHome = json['jisItAWorkFromHome']  ?? '';
    jSalary = json['jSalary']  ?? '';
    name = json['name']  ?? '';
    jSalaryPer = json['jSalaryPer']  ?? '';
    jType = json['jType']  ?? '';
    jTitle = json['jTitle']  ?? '';
    jStreetAddress = json['jStreetAddress']  ?? '';
    email = json['email']  ?? '';
    likes = json['likes']  ?? '';
    longitude = json['longitude']  ?? '';
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['postViews'] = postViews;
    data['chatAction'] = chatAction;
    data['callAction'] = callAction;
    data['jPhone'] = jPhone;
    data['jCity'] = jCity;
    data['image'] = image;
    data['jRequirements'] = jRequirements;
    data['jSalaryCurrency'] = jSalaryCurrency;
    data['latitude'] = latitude;
    data['jImage'] = jImage;
    data['jVisibility'] = jVisibility;
    data['uploadTime'] = uploadTime;
    data['jDesc'] = jDesc;
    data['isJob'] = isJob;
    data['jState'] = jState;
    data['jisItAWorkFromHome'] = jisItAWorkFromHome;
    data['jSalary'] = jSalary;
    data['name'] = name;
    data['jSalaryPer'] = jSalaryPer;
    data['jType'] = jType;
    data['jTitle'] = jTitle;
    data['jStreetAddress'] = jStreetAddress;
    data['email'] = email;
    data['likes'] = likes;
    data['longitude'] = longitude;
    return data;
  }
}