import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:zansh/api/apis.dart';
import 'package:zansh/auth/loginScreen.dart';
import '../main.dart';
import 'homeScreen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    APIs.getCurrentUser();
    Future.delayed(const Duration(milliseconds: 1000), () {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.black,
        statusBarColor: Colors.black
      ));

      if(APIs.auth.currentUser != null){
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
      }
      else{
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    mq = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.black87,

      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(width: mq.width,),
          Container(
            padding: const EdgeInsets.all(4),
            width: mq.width * 0.34,
            margin: EdgeInsets.only(top: mq.height * 0.24,bottom: mq.height * 0.074),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(19),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 4,
                    blurRadius: 19,
                    offset: const Offset(0, 0),
                  ),
                ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(19),
              child: Image.asset("assets/images/logo.png"),
            ),
          ),

          const Text(
              "Work & Hire Near You!",
              style: TextStyle(fontWeight: FontWeight.w700, color: Color.fromARGB(
                  255, 253, 253, 253), fontSize: 17, fontFamily: 'Monts', letterSpacing: 0.7),
              textAlign: TextAlign.center
          ),
          SizedBox(height: mq.width * 0.64,),
          const Text(
              "ZANSH",
              style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white, fontSize: 12, fontFamily: 'Monts', letterSpacing: 4),
              textAlign: TextAlign.center
          ),

          //SizedBox(height: mq.height * 0.17,)
        ],
      ),
    );
  }
}
