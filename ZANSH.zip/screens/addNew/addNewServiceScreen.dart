import 'dart:developer';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:zansh/api/apis.dart';
import 'package:zansh/main.dart';
import 'package:zansh/screens/homeScreenX.dart';

import '../../showUps/dialogs.dart';


class AddNewServiceScreen extends StatefulWidget {
  const AddNewServiceScreen({super.key});

  @override
  State<AddNewServiceScreen> createState() => _AddNewServiceScreenState();
}

class _AddNewServiceScreenState extends State<AddNewServiceScreen> {
  late Position currentPosition;
  bool isLocationGranted = false;
  late String sImageRef;
  final _formkey = GlobalKey<FormState>();

  bool isJob = false;
  String sTitle = " ";
  String sDesc = " ";
  String sFees = " ";
  String sFeesPer = "Per-Task";
  String sStreetAddress = " ";
  String sCity = " ";
  String sState = " ";
  String sPhone = " ";
  String? sImage = " ";
  String sFeesCurrency = "rupee";
  String sVisibility = "everyone";

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          flexibleSpace: _appBar(context),
        ),

        body: SafeArea(
          child: SingleChildScrollView(
            child: Form(
              key: _formkey,
              child: Container(
                padding: EdgeInsets.only(top: mq.height * 0.017),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    SizedBox(width: mq.width,),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 30, 30, 30),
                          border: Border.all(color: Colors.white70, width: 1),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: TextFormField(
                          key: const ValueKey("sTitle"),
                          decoration: InputDecoration(
                            hintText: "Service Title..",
                            hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                            border: InputBorder.none,
                            errorStyle: TextStyle(
                                color: Colors.red.shade400, // Change error text color here
                                fontStyle: FontStyle.italic,
                                letterSpacing: 0.9,
                                fontWeight: FontWeight.w500,
                                fontSize: 11
                            ),
                          ),
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: 0.4),
                          maxLength: 29,

                          validator: (value) {
                            if(value == null || (value.length <= 3)){
                              return "Please Enter a Valid Service Title";
                            }
                            else{
                              return null;
                            }
                          },
                          onSaved: (val){
                            setState(() {
                              sTitle = val.toString();
                            });
                          },
                        ),
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 30, 30, 30),
                          border: Border.all(color: Colors.white70, width: 1),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: TextFormField(
                          key: const ValueKey("sDesc"),
                          decoration: InputDecoration(
                            hintText: "Service Description..",
                            hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                            border: InputBorder.none,
                            errorStyle: TextStyle(
                                color: Colors.red.shade400, // Change error text color here
                                fontStyle: FontStyle.italic,
                                letterSpacing: 0.9,
                                fontWeight: FontWeight.w500,
                                fontSize: 11
                            ),
                          ),
                          maxLength: 400,
                          style: const TextStyle(fontSize: 14.7),
                          maxLines: null,
                          validator: (value) {
                            if(value == null || (value.length <= 10)){
                              return "Please Enter a Valid Service Description";
                            }
                            else{
                              return null;
                            }
                          },
                          onSaved: (val){
                            setState(() {
                              sDesc = val.toString();
                            });
                          },
                        ),
                      ),
                    ),

                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 2),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Fees Currency", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
                          Container(
                            width:  mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButton<String>(
                              value: sFeesCurrency,
                              dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                              borderRadius: BorderRadius.circular(20),
                              style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 16),
                              underline: const SizedBox(),
                              onChanged: (String? newValue){
                                if(newValue != null){
                                  setState(() {
                                    sFeesCurrency = newValue;
                                  });
                                }
                              },

                              items: const [
                                DropdownMenuItem<String>(
                                  value: "rupee",
                                  child: Row(
                                    children: [
                                      Text("₹", style: TextStyle(color: Colors.white),),
                                      SizedBox(width: 4,),
                                      Text("Rupees", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),)
                                    ],
                                  ),
                                ),

                                DropdownMenuItem<String>(
                                  value: "dollar",
                                  child: Row(
                                    children: [
                                      Text("\$", style: TextStyle(color: Colors.white),),
                                      SizedBox(width: 4,),
                                      Text("Dollars", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),)
                                    ],
                                  ),
                                ),
                              ],

                            ),
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Fees Approx", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Container(
                            //height: mq.width * 0.14,
                            width: mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: TextFormField(
                              key: const ValueKey("jSalary"),
                              decoration: InputDecoration(
                                prefixIcon: sFeesCurrency == "rupee" ? const Icon(Icons.currency_rupee, size: 18,) : const Padding(
                                  padding: EdgeInsets.only(right: 4.7),
                                  child: Text("\$", style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 16),),
                                ),
                                prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
                                hintText: "e.g. 6000",
                                hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14),
                                border: InputBorder.none,
                                errorStyle: TextStyle(
                                    color: Colors.red.shade400, // Change error text color here
                                    fontStyle: FontStyle.italic,
                                    letterSpacing: 0.9,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 11
                                ),
                              ),
                              style: const TextStyle(fontSize: 14.9, fontWeight: FontWeight.w600, color: Colors.white),
                              // maxLength: 10,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if(value == null || (value.isEmpty) || (value.length >= 9) ){
                                  return "Enter Valid Fees";
                                }
                                else{
                                  return null;
                                }
                              },
                              onSaved: (val){
                                setState(() {
                                  sFees = val.toString();
                                });
                              },
                            ),
                          ),

                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Fees Per", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
                          Container(
                            width: mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04,),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButton<String>(
                              value: sFeesPer,
                              dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                              borderRadius: BorderRadius.circular(20),
                              icon: const Icon(Icons.arrow_drop_down, color: Colors.white70,),
                              style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 14),
                              underline: const SizedBox(),
                              onChanged: (String? newValue){
                                if(newValue != null){
                                  setState(() {
                                    sFeesPer = newValue;
                                  });
                                }
                              },

                              items: const [
                                DropdownMenuItem<String>(
                                  value: "Per-Task",
                                  child: Text("Per-Task", style: TextStyle(fontSize: 14),),
                                ),

                                DropdownMenuItem<String>(
                                  value: "Per-Week",
                                  child: Text("Per-Week", style: TextStyle(fontSize: 14),),
                                ),

                                DropdownMenuItem<String>(
                                  value: "Per-Month",
                                  child: Text("Per-Month", style: TextStyle(fontSize: 14),),
                                ),

                                DropdownMenuItem<String>(
                                  value: "Per-Year",
                                  child: Text("Per-Year", style: TextStyle(fontSize: 14),),
                                ),
                              ],

                            ),
                          ),
                        ],
                      ),
                    ),

                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
                    const Text("Service Location", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.019, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Street", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("sStreetAddress"),
                                decoration: InputDecoration(
                                  hintText: "Enter your Street Address",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 100,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid Address";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    sStreetAddress = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("   City", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("sCity"),
                                decoration: InputDecoration(
                                  hintText: "Enter your City",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 29,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid City";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    sCity = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text(" State", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("sState"),
                                decoration: InputDecoration(
                                  hintText: "Enter your State",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 29,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid State";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    sState = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),

                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),

                    const Text("Contact Details", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),

                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.019, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Phone Number", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("sPhone"),
                                decoration: InputDecoration(
                                  hintText: "809XXXXX09",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                keyboardType: TextInputType.number,
                                maxLines: 1,
                                validator: (value) {
                                  if(value == null || (value.length <= 9) || (value.length >= 19) || double.tryParse(value) == null ){
                                    return "Please Enter a Valid Phone Number";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  String ph = val.toString();
                                  setState(() {
                                    sPhone = ph.replaceAll(' ', '');
                                  });
                                },
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),

                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),

                    // Padding(
                    //   padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                    //   child: SingleChildScrollView(
                    //     scrollDirection: Axis.horizontal,
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       children: [
                    //         const Text("Who can see your Post ?", style: TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600),),
                    //
                    //         Container(
                    //           //width: mq.width * 0.47,
                    //           margin: EdgeInsets.only(left: mq.width * 0.04),
                    //           padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    //           decoration: BoxDecoration(
                    //             color: const Color.fromARGB(255, 30, 30, 30),
                    //             border: Border.all(color: Colors.white70, width: 1),
                    //             borderRadius: BorderRadius.circular(14),
                    //           ),
                    //           child: DropdownButton<String>(
                    //             value: sVisibility,
                    //             dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                    //             borderRadius: BorderRadius.circular(20),
                    //             icon: const Icon(Icons.arrow_drop_down, color: Colors.white70,),
                    //             style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 14),
                    //             underline: const SizedBox(),
                    //             onChanged: (String? newValue){
                    //               if(newValue != null){
                    //                 setState(() {
                    //                   sVisibility = newValue;
                    //                 });
                    //               }
                    //             },
                    //
                    //             items: const [
                    //               DropdownMenuItem<String>(
                    //                 value: "everyone",
                    //                 child: Text("Everyone"),
                    //               ),
                    //
                    //               DropdownMenuItem<String>(
                    //                 value: "nearby",
                    //                 child: Text("Nearby People"),
                    //               ),
                    //
                    //             ],
                    //
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    //
                    // const Padding(
                    //   padding: EdgeInsets.only(top: 4.0, bottom: 7),
                    //   child: Divider(color: Colors.white70, thickness: 0.1),
                    // ),

                    const Text("Add Image (Optional)", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),

                    GestureDetector(
                        onTap: (){
                          _showImageBottomSheet();
                        },
                        child: Container(
                          width: mq.width * 0.9,
                          height: mq.width * 0.9,
                          margin: EdgeInsets.only(left: mq.width * 0.05, right: mq.width * 0.05, bottom: mq.width * 0.02, top: mq.width * 0.04),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(19),
                          ),

                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(7),
                            child: sImage != " " ?
                            Image.file(
                              File(sImage!),
                              fit: BoxFit.cover,
                            )
                                :
                            const Icon(CupertinoIcons.photo_fill,size: 40,),
                          ),
                        )
                    ),

                    sImage != " " ?
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035),
                      child: Row(
                        children: [
                          const Spacer(),
                          ElevatedButton(
                              onPressed: (){
                                setState(() {
                                  sImage = " ";
                                });
                              },
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(Colors.white10),
                            ),
                              child: Row(
                                children: [
                                Text("Remove Image", style: TextStyle(
                                  color: Colors.red.shade400, // Change error text color here
                                  fontStyle: FontStyle.italic,
                                  letterSpacing: 0.9,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12
                                ),),
                                  Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 19,)
                                ],
                              ),
                          ),

                        ],
                      ),
                    )
                    :
                        const SizedBox(),

                    SizedBox(height: mq.height * 0.04,),
                    // Container(
                    //   margin: EdgeInsets.only(bottom: mq.width * 0.1, top: mq.height * 0.029),
                    //   width: mq.width * 0.84,
                    //   height: mq.width * 0.1,
                    //   child: ElevatedButton(
                    //     onPressed: (){
                    //       if(_formkey.currentState!.validate()){
                    //         _formkey.currentState!.save();
                    //         Dialogs.showCircularProgress(context, Colors.white);
                    //         uploadNewServicePost().then((x) {
                    //           Navigator.pop(context);
                    //           Dialogs.showSnackBar(context, "Service Posted Successfully!");
                    //         });
                    //       }
                    //     },
                    //     style: ButtonStyle(
                    //       backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    //     ),
                    //     child: const Center(child: Text("Add Service", style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w500),)),
                    //   ),
                    // ),

                  ],
                ),
              ),
            ),
          ),
        ),

      ),
    );
  }

  void _showImageBottomSheet(){
    showModalBottomSheet(context: context, builder: (_){
      return SafeArea(
        child: ListView(

          shrinkWrap: true,
          padding: EdgeInsets.only(top: mq.height * 0.027, bottom: mq.height * 0.067),
          children: [

            const Text("Upload Image", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19, color: Colors.white70), textAlign: TextAlign.center,),

            const SizedBox(height: 40,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: ()async{
                    final ImagePicker picker = ImagePicker();
                    final XFile? image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 19);

                    if(image != null){
                      setState(() {
                        sImage = image.path;
                      });
                      log("---- IMAGE PATH - GALLERY ----");
                      log(image.path.toString());
                      Navigator.pop(context);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: const CircleBorder(),
                    fixedSize: Size(mq.width * 0.27, mq.width * 0.27),
                  ),
                  child: Image.asset('assets/images/gallery.png'),
                ),

                const SizedBox(width: 47),
                ElevatedButton(
                  onPressed: ()async{

                    final ImagePicker picker = ImagePicker();
                    final XFile? photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 19);
                    if(photo != null){
                      setState(() {
                        sImage = photo.path;
                      });
                      log("---- IMAGE PATH - CAMERA  ----");
                      log(photo.path.toString());
                      Navigator.pop(context);
                    }

                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: const CircleBorder(),
                      fixedSize: Size(mq.width * 0.27, mq.width * 0.27)
                  ),
                  child: Image.asset('assets/images/camera.png'),
                ),
              ],
            ),

            const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 40.0),
                child: Text("( Note - Images with 1:1 aspect ratio fits best :) )", style: TextStyle(fontSize: 11),),
              ),
            )
          ],
        ),
      );
    },
        backgroundColor: const Color.fromARGB(255, 43, 43, 43),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(29), topLeft: Radius.circular(29)))
    );
  }

  Future<void> getCurrentLocation()async{

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Dialogs.showSnackBar(context, "Location Access Denied!");
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      Dialogs.showSnackBar(context, "Location Access Denied!!");
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
    );

    setState(() {
      currentPosition = position;
      isLocationGranted = true;
    });
  }

  Future<void> uploadNewServicePost() async{
    await getCurrentLocation().then((value) {

      if(isLocationGranted){
        if(sImage != " "){
          uploadImage(File(sImage!)).then((value) {
            APIs.createNewServicePost(sPhone: sPhone, sFeesPer: sFeesPer, latitude: currentPosition.latitude.toString(), longitude: currentPosition.longitude.toString(), sCity: sCity, sTitle: sTitle, sDesc: sDesc, sFees: sFees, sState: sState, sStreetAddress: sStreetAddress, sImage: sImageRef ?? "", sFeesCurrency: sFeesCurrency, sVisibility: sVisibility);
          });
        }
        else{
          APIs.createNewServicePost(sPhone: sPhone, sFeesPer: sFeesPer,latitude :currentPosition.latitude.toString(), longitude: currentPosition.longitude.toString(), sCity: sCity, sTitle: sTitle, sDesc: sDesc, sFees: sFees, sState: sState, sStreetAddress: sStreetAddress, sImage: " ", sFeesCurrency: sFeesCurrency, sVisibility: sVisibility);
        }

      }
      else{

      }

    });
  }

  Future<void> uploadImage(File file) async {
    final time = DateTime.now().millisecondsSinceEpoch.toString();

    final ext = file.path.split('.').last;

    final ref = APIs.fStorage.ref().child('sImages/$time.$ext');

    await ref.putFile(file, SettableMetadata(contentType: "image/$ext")).then((p0) {
      log("---- Data Transfferred : ${p0.bytesTransferred / 1000} kb ----");
    });
    sImageRef = await ref.getDownloadURL();
  }


  Widget _appBar(BuildContext context){
    return SafeArea(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          IconButton(onPressed: (){
            Navigator.pop(context);
            //Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreenX()));
          }, icon: const Icon(Icons.arrow_back_rounded, color: Colors.white,)),

          SizedBox(width: mq.width * 0.02,),

          const Text("Add New Service", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.2),),

          const Spacer(),

          Container(
            margin: EdgeInsets.only(right: mq.width * 0.07),
            width: mq.width * 0.34,
            height: mq.width * 0.09,
            child: ElevatedButton(
              onPressed: (){
                //Dialogs.showCircularProgress(context, Colors.white);
                if(_formkey.currentState!.validate()){
                  _formkey.currentState!.save();
                  Dialogs.showCircularProgress(context, Colors.white);
                  uploadNewServicePost().then((x) {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        '/homeN', (Route<dynamic> route) => false
                    );
                    Dialogs.showSnackBar(context, "Service Posted!");
                  });
                }
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
              ),
              child: const Center(child: Text("Add Service", style: TextStyle(color: Color.fromARGB(255, 245, 245, 245), fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 0.2),)),
            ),
          ),

        ],
      ),
    );
  }

}
