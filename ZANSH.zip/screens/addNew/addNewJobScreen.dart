import 'dart:developer';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:zansh/api/apis.dart';
import 'package:zansh/main.dart';
import '../../showUps/dialogs.dart';


class AddNewJobScreen extends StatefulWidget {
  const AddNewJobScreen({super.key});

  @override
  State<AddNewJobScreen> createState() => _AddNewJobScreenState();
}

class _AddNewJobScreenState extends State<AddNewJobScreen> {
  late Position currentPosition;
  bool isLocationGranted = false;
  late String jImageRef;
  final _formkey = GlobalKey<FormState>();

  String jTitle = " ";
  String jDesc = " ";
  String jType = "Part-Time";
  String jSalary = " ";
  String jSalaryPer = "Per-Month";
  String jSalaryCurrency = "rupee";
  String jRequirements = " ";
  bool jisItAWorkFromHome = false;
  String jStreetAddress = " ";
  String jCity = " ";
  String jState = " ";
  String jPhone = " ";
  String? jImage = " ";
  String jVisibility = "everyone";

  String latitude = " ";
  String longitude = " ";


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          flexibleSpace: _appBar(context),
        ),

        body: SafeArea(
          child: SingleChildScrollView(
            child: Form(
              key: _formkey,
              child: Container(
                padding: EdgeInsets.only(top: mq.height * 0.01),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
          
                    SizedBox(width: mq.width,),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 30, 30, 30),
                          border: Border.all(color: Colors.white70, width: 1),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: TextFormField(
                          key: const ValueKey("jTitle"),
                          decoration: InputDecoration(
                            hintText: "Job Title..",
                            hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                            border: InputBorder.none,
                            errorStyle: TextStyle(
                              color: Colors.red.shade400, // Change error text color here
                              fontStyle: FontStyle.italic,
                              letterSpacing: 0.9,
                              fontWeight: FontWeight.w500,
                              fontSize: 11
                            ),
                          ),
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: 0.4),
                          maxLength: 29,
          
                          validator: (value) {
                            if(value == null || (value.length <= 3)){
                              return "Please Enter a Valid Job Title";
                            }
                            else{
                              return null;
                            }
                          },
                          onSaved: (val){
                            setState(() {
                              jTitle = val.toString();
                            });
                          },
                        ),
                      ),
                    ),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 30, 30, 30),
                          border: Border.all(color: Colors.white70, width: 1),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: TextFormField(
                          key: const ValueKey("jDesc"),
                          decoration: InputDecoration(
                            hintText: "Job Description..",
                            hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                            border: InputBorder.none,
                            errorStyle: TextStyle(
                                color: Colors.red.shade400, // Change error text color here
                                fontStyle: FontStyle.italic,
                                letterSpacing: 0.9,
                                fontWeight: FontWeight.w500,
                                fontSize: 11
                            ),
                          ),
                          maxLength: 400,
                          style: const TextStyle(fontSize: 14.7),
                          maxLines: null,
                          validator: (value) {
                            if(value == null || (value.length <= 10)){
                              return "Please Enter a Valid Job Description";
                            }
                            else{
                              return null;
                            }
                          },
                          onSaved: (val){
                            setState(() {
                              jDesc = val.toString();
                            });
                          },
                        ),
                      ),
                    ),
          
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 2),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Salary Currency", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
                          Container(
                            width:  mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButton<String>(
                              value: jSalaryCurrency,
                              dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                              borderRadius: BorderRadius.circular(20),
                              style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 16),
                              underline: const SizedBox(),
                              onChanged: (String? newValue){
                                if(newValue != null){
                                  setState(() {
                                    jSalaryCurrency = newValue;
                                  });
                                }
                              },
          
                              items: const [
                                DropdownMenuItem<String>(
                                  value: "rupee",
                                  child: Row(
                                    children: [
                                      Text("₹", style: TextStyle(color: Colors.white),),
                                      SizedBox(width: 4,),
                                      Text("Rupees", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),)
                                    ],
                                  ),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "dollar",
                                  child: Row(
                                    children: [
                                      Text("\$", style: TextStyle(color: Colors.white),),
                                      SizedBox(width: 4,),
                                      Text("Dollars", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),)
                                    ],
                                  ),
                                ),
                              ],
          
                            ),
                          ),
                        ],
                      ),
                    ),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Salary Approx", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
          
                          Container(
                            //height: mq.width * 0.14,
                            width: mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: TextFormField(
                              key: const ValueKey("jSalary"),
                              decoration: InputDecoration(
                                prefixIcon: jSalaryCurrency == "rupee" ? const Icon(Icons.currency_rupee, size: 18,) : const Padding(
                                  padding: EdgeInsets.only(right: 4.7),
                                  child: Text("\$", style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 16),),
                                ),
                                prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
                                hintText: "e.g. 6000",
                                hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14),
                                border: InputBorder.none,
                                errorStyle: TextStyle(
                                    color: Colors.red.shade400, // Change error text color here
                                    fontStyle: FontStyle.italic,
                                    letterSpacing: 0.9,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 11
                                ),
                              ),
                              style: const TextStyle(fontSize: 14.9, fontWeight: FontWeight.w600, color: Colors.white),
                              // maxLength: 10,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if(value == null || (value.isEmpty) || (value.length >= 9) ){
                                  return "Enter Valid Salary";
                                }
                                else{
                                  return null;
                                }
                              },
                              onSaved: (val){
                                setState(() {
                                  jSalary = val.toString();
                                });
                              },
                            ),
                          ),
          
                        ],
                      ),
                    ),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Salary Per", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
                          Container(
                            width: mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04,),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButton<String>(
                              value: jSalaryPer,
                              dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                              borderRadius: BorderRadius.circular(20),
                              icon: const Icon(Icons.arrow_drop_down, color: Colors.white70,),
                              style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 14),
                              underline: const SizedBox(),
                              onChanged: (String? newValue){
                                if(newValue != null){
                                  setState(() {
                                    jSalaryPer = newValue;
                                  });
                                }
                              },
          
                              items: const [
                                DropdownMenuItem<String>(
                                  value: "Per-Task",
                                  child: Text("Per-Task", style: TextStyle(fontSize: 14),),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "Per-Week",
                                  child: Text("Per-Week", style: TextStyle(fontSize: 14),),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "Per-Month",
                                  child: Text("Per-Month", style: TextStyle(fontSize: 14),),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "Per-Year",
                                  child: Text("Per-Year", style: TextStyle(fontSize: 14),),
                                ),
                              ],
          
                            ),
                          ),
                        ],
                      ),
                    ),
          
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 2),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
          
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Job Type", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
                          Container(
                            width: mq.width * 0.47,
                            margin: EdgeInsets.only(left: mq.width * 0.04),
                            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 30, 30, 30),
                              border: Border.all(color: Colors.white70, width: 1),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DropdownButton<String>(
                              value: jType,
                              dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                              borderRadius: BorderRadius.circular(20),
                              icon: const Icon(Icons.arrow_drop_down, color: Colors.white70,),
                              style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 14),
                              underline: const SizedBox(),
                              onChanged: (String? newValue){
                                if(newValue != null){
                                  setState(() {
                                    jType = newValue;
                                  });
                                }
                              },
          
                              items: const [
                                DropdownMenuItem<String>(
                                  value: "Single-Time",
                                  child: Text("Single-Time"),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "Part-Time",
                                  child: Text("Part-Time"),
                                ),
          
                                DropdownMenuItem<String>(
                                  value: "Full-Time",
                                  child: Text("Full-Time"),
                                ),
                              ],
          
                            ),
                          ),
                        ],
                      ),
                    ),
          
                    // const Padding(
                    //   padding: EdgeInsets.only(top: 4.0, bottom: 2),
                    //   child: Divider(color: Colors.white70, thickness: 0.1),
                    // ),
          
                    // Padding(
                    //   padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, bottom: mq.width * 0.0035, top: mq.width * 0.0035),
                    //   child: Row(
                    //     mainAxisAlignment: MainAxisAlignment.center,
                    //     children: [
                    //       Text("Is it Work From Home", style: TextStyle(fontSize: 14, color: jisItAWorkFromHome ? Colors.white : Colors.white70, fontWeight: FontWeight.w600),),
                    //       SizedBox(width: mq.width * 0.02,),
                    //       Switch(value: jisItAWorkFromHome,
                    //           onChanged: (val){
                    //               setState(() {
                    //                 jisItAWorkFromHome = val;
                    //               });
                    //           },
                    //         inactiveThumbColor: Colors.white,
                    //         inactiveTrackColor: Colors.blue.shade700,
                    //         activeColor: Colors.blue,
                    //         materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    //       ),
                    //     ],
                    //   ),
                    // ),
          
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
                    const Text("Skills Required for Job", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),
                    Padding(
                      padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.019, bottom: mq.height * 0.0035),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 30, 30, 30),
                          border: Border.all(color: Colors.white70, width: 1),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: TextFormField(
                          key: const ValueKey("jRequirements"),
                          decoration: InputDecoration(
                            hintText: "Enter Skills",
                            hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                            border: InputBorder.none,
                            errorStyle: TextStyle(
                                color: Colors.red.shade400, // Change error text color here
                                fontStyle: FontStyle.italic,
                                letterSpacing: 0.9,
                                fontWeight: FontWeight.w500,
                                fontSize: 11
                            ),
                          ),
                          maxLength: 400,
                          style: const TextStyle(fontSize: 14.7),
                          maxLines: null,
                          validator: (value) {
                            if(value == null || (value.length < 2)){
                              return "Please Enter Valid Job Requirements";
                            }
                            else{
                              return null;
                            }
                          },
                          onSaved: (val){
                            setState(() {
                              jRequirements = val.toString();
                            });
                          },
                        ),
                      ),
                    ),
          
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
                    const Text("Job Location", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.019, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Street", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
          
                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("jStreetAddress"),
                                decoration: InputDecoration(
                                  hintText: "Enter your Street Address",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 100,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid Address";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    jStreetAddress = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),
          
                        ],
                      ),
                    ),
          
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("   City", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
          
                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("jCity"),
                                decoration: InputDecoration(
                                  hintText: "Enter your City",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 29,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid City";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    jCity = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),
          
                        ],
                      ),
                    ),
          
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text(" State", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),
          
                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("jState"),
                                decoration: InputDecoration(
                                  hintText: "Enter your State",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                maxLines: null,
                                maxLength: 29,
                                validator: (value) {
                                  if(value == null || (value.length <= 1) ){
                                    return "Please Enter a Valid State";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  setState(() {
                                    jState = val.toString();
                                  });
                                },
                              ),
                            ),
                          ),
          
                        ],
                      ),
                    ),
          
                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),

                    const Text("Contact Details", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),

                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.019, bottom:  mq.height * 0.0035),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Text("Phone Number", style: TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600),),

                          Expanded(
                            child: Container(
                              //width: mq.width * 0.47,
                              margin: EdgeInsets.only(left: mq.width * 0.04),
                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 30, 30, 30),
                                border: Border.all(color: Colors.white70, width: 1),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: TextFormField(
                                key: const ValueKey("jPhone"),
                                decoration: InputDecoration(
                                  hintText: "809XXXXX09",
                                  hintStyle: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w400, fontSize: 14),
                                  border: InputBorder.none,
                                  errorStyle: TextStyle(
                                      color: Colors.red.shade400, // Change error text color here
                                      fontStyle: FontStyle.italic,
                                      letterSpacing: 0.9,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 11
                                  ),
                                ),
                                keyboardType: TextInputType.number,
                                maxLines: 1,
                                validator: (value) {
                                  if(value == null || (value.length <= 9) || (value.length >= 19) || double.tryParse(value) == null ){
                                    return "Please Enter a Valid Phone Number";
                                  }
                                  else{
                                    return null;
                                  }
                                },
                                onSaved: (val){
                                  String ph = val.toString();
                                  setState(() {
                                    jPhone = ph.replaceAll(' ', '');
                                  });
                                },
                              ),
                            ),
                          ),

                        ],
                      ),
                    ),

                    const Padding(
                      padding: EdgeInsets.only(top: 4.0, bottom: 7),
                      child: Divider(color: Colors.white70, thickness: 0.1),
                    ),
          
                    // Padding(
                    //   padding: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.height * 0.0035),
                    //   child: SingleChildScrollView(
                    //     scrollDirection: Axis.horizontal,
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       children: [
                    //         const Text("Who can see your Post ?", style: TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600),),
                    //
                    //         Container(
                    //           //width: mq.width * 0.47,
                    //           margin: EdgeInsets.only(left: mq.width * 0.04),
                    //           padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    //           decoration: BoxDecoration(
                    //             color: const Color.fromARGB(255, 30, 30, 30),
                    //             border: Border.all(color: Colors.white70, width: 1),
                    //             borderRadius: BorderRadius.circular(14),
                    //           ),
                    //           child: DropdownButton<String>(
                    //             value: jVisibility,
                    //             dropdownColor: const Color.fromARGB(255, 30, 30, 30),
                    //             borderRadius: BorderRadius.circular(20),
                    //             icon: const Icon(Icons.arrow_drop_down, color: Colors.white70,),
                    //             style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 14),
                    //             underline: const SizedBox(),
                    //             onChanged: (String? newValue){
                    //               if(newValue != null){
                    //                 setState(() {
                    //                   jVisibility = newValue;
                    //                 });
                    //               }
                    //             },
                    //
                    //             items: const [
                    //               DropdownMenuItem<String>(
                    //                 value: "everyone",
                    //                 child: Text("Everyone"),
                    //               ),
                    //
                    //               DropdownMenuItem<String>(
                    //                 value: "nearby",
                    //                 child: Text("Nearby People"),
                    //               ),
                    //
                    //             ],
                    //
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // ),
                    //
                    // const Padding(
                    //   padding: EdgeInsets.only(top: 4.0, bottom: 7),
                    //   child: Divider(color: Colors.white70, thickness: 0.1),
                    // ),
          
                    const Text("Add Image (Optional)", style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600),),
          
                    GestureDetector(
                      onTap: (){
                        _showImageBottomSheet();
                      },
                      child: Container(
                        width: mq.width * 0.9,
                        height: mq.width * 0.9,
                        margin: EdgeInsets.only(left: mq.width * 0.05, right: mq.width * 0.05, bottom: mq.width * 0.04, top: mq.width * 0.04),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(19),
                        ),
          
                        child: ClipRRect(
                              borderRadius: BorderRadius.circular(7),
                              child: jImage != " " ?
                              Image.file(
                                File(jImage!),
                                fit: BoxFit.cover,
                              )
                                  :
                              const Icon(CupertinoIcons.photo_fill,size: 40,),
                      ),
                    )
                    ),
          
                    jImage != " " ?
                    Padding(
                      padding: EdgeInsets.only( left: mq.width * 0.07,right: mq.width * 0.07, top:  mq.height * 0.0035),
                      child: Row(
                        children: [
                          const Spacer(),
                          ElevatedButton(
                            onPressed: (){
                              setState(() {
                                jImage = " ";
                              });
                            },
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(Colors.white10),
                            ),
                            child: Row(
                              children: [
                                Text("Remove Image", style: TextStyle(
                                    color: Colors.red.shade400, // Change error text color here
                                    fontStyle: FontStyle.italic,
                                    letterSpacing: 0.9,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12
                                ),),
                                Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 19,)
                              ],
                            ),
                          ),
          
                        ],
                      ),
                    )
                        :
                    const SizedBox(),
          
                    SizedBox(height: mq.height * 0.04,),
                  ],
                ),
              ),
            ),
          ),
        ),

      ),
    );
  }

  void _showImageBottomSheet(){
    showModalBottomSheet(context: context, builder: (_){
      return SafeArea(
        child: ListView(

          shrinkWrap: true,
          padding: EdgeInsets.only(top: mq.height * 0.027, bottom: mq.height * 0.067),
          children: [

            const Text("Upload Image", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19, color: Colors.white70), textAlign: TextAlign.center,),

            const SizedBox(height: 40,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: ()async{
                    final ImagePicker picker = ImagePicker();
                    final XFile? image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 19);

                    if(image != null){
                      setState(() {
                        jImage = image.path;
                      });
                      log("---- IMAGE PATH - GALLERY ----");
                      log(image.path.toString());
                      Navigator.pop(context);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: const CircleBorder(),
                    fixedSize: Size(mq.width * 0.27, mq.width * 0.27),
                  ),
                  child: Image.asset('assets/images/gallery.png'),
                ),

                const SizedBox(width: 47),
                ElevatedButton(
                  onPressed: ()async{

                    final ImagePicker picker = ImagePicker();
                    final XFile? photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 19);
                    if(photo != null){
                      setState(() {
                        jImage = photo.path;
                      });
                      log("---- IMAGE PATH - CAMERA  ----");
                      log(photo.path.toString());
                      Navigator.pop(context);
                    }

                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: const CircleBorder(),
                      fixedSize: Size(mq.width * 0.27, mq.width * 0.27)
                  ),
                  child: Image.asset('assets/images/camera.png'),
                ),
              ],
            ),

            const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 40.0),
                child: Text("( Note - Images with 1:1 aspect ratio fits best :) )", style: TextStyle(fontSize: 11),),
              ),
            )
          ],
        ),
      );
    },
        backgroundColor: const Color.fromARGB(255, 43, 43, 43),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(29), topLeft: Radius.circular(29)))
    );
  }

  Future<void> getCurrentLocation()async{

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Dialogs.showSnackBar(context, "Location Access Denied!");
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      Dialogs.showSnackBar(context, "Location Access Denied!!");
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
    );

    setState(() {
      currentPosition = position;
      isLocationGranted = true;
    });
  }

  Future<void> uploadNewJobPost() async{
    await getCurrentLocation();
    await getCurrentLocation().then((value) {

      if(isLocationGranted){
        if(jImage != " "){
          uploadImage(File(jImage!)).then((value) {
            APIs.createNewJobPost(jPhone: jPhone, jCity: jCity, jRequirements: jRequirements, jSalaryCurrency: jSalaryCurrency, longitude: currentPosition.longitude.toString(), latitude: currentPosition.latitude.toString(), jImage: jImageRef ?? "", jDesc: jDesc, jState: jState, jVisibility: jVisibility, jisItAWorkFromHome: jisItAWorkFromHome, jSalary: jSalary, jSalaryPer: jSalaryPer, jType: jType, jTitle: jTitle, jStreetAddress: jStreetAddress);
          });
        }
        else{
          APIs.createNewJobPost(jPhone: jPhone, jCity: jCity, jRequirements: jRequirements, jSalaryCurrency: jSalaryCurrency, longitude: currentPosition.longitude.toString(), latitude: currentPosition.latitude.toString(), jImage: "", jDesc: jDesc, jState: jState, jVisibility: jVisibility, jisItAWorkFromHome: jisItAWorkFromHome, jSalary: jSalary, jSalaryPer: jSalaryPer, jType: jType, jTitle: jTitle, jStreetAddress: jStreetAddress);
        }

      }
      else{

      }

    });
  }

  Future<void> uploadImage(File file) async {
    final time = DateTime.now().millisecondsSinceEpoch.toString();

    final ext = file.path.split('.').last;

    final ref = APIs.fStorage.ref().child('jImages/$time.$ext');

    await ref.putFile(file, SettableMetadata(contentType: "image/$ext")).then((p0) {
      log("---- Data Transfferred : ${p0.bytesTransferred / 1000} kb ----");
    });
    jImageRef = await ref.getDownloadURL();
  }

  Widget _appBar(BuildContext context){
    return SafeArea(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          IconButton(onPressed: (){
            Navigator.pop(context);
            //Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreenX()));
          }, icon: const Icon(Icons.arrow_back_rounded, color: Colors.white,)),

          SizedBox(width: mq.width * 0.02,),

          const Text("Add New Job", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.2),),

          const Spacer(),

          Container(
            margin: EdgeInsets.only(right: mq.width * 0.07),
            width: mq.width * 0.34,
            height: mq.width * 0.09,
            child: ElevatedButton(
              onPressed: (){
                if(_formkey.currentState!.validate()){
                  _formkey.currentState!.save();
                  Dialogs.showCircularProgress(context, Colors.white);
                  uploadNewJobPost().then((x) {
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        '/homeN', (Route<dynamic> route) => false
                    );
                    Dialogs.showSnackBar(context, "Job Posted!");
                  });
                }
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
              ),
              child: const Center(child: Text("Add Job", style: TextStyle(color: Color.fromARGB(255, 245, 245, 245), fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 0.2),)),
            ),
          ),

        ],
      ),
    );
  }

}