import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zansh/screens/addNew/addNewJobScreen.dart';
import '../main.dart';
import 'addNew/addNewServiceScreen.dart';

class AddNewPostScreen extends StatefulWidget {
  const AddNewPostScreen({super.key});

  @override
  State<AddNewPostScreen> createState() => _AddNewPostScreenState();
}

class _AddNewPostScreenState extends State<AddNewPostScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            flexibleSpace: _appBar(),
          ),
          backgroundColor: Colors.black,
          body: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(width: mq.width,),
              SizedBox(
                  width: mq.width * 0.64,
                  child: Opacity(
                    opacity: 0.84,
                      child: Image.asset("assets/images/lead1.png", )),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.width * 0.04),
                width: mq.width * 0.74,
                height: mq.width * 0.129,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(29),
                  border: Border.all(color: Colors.white, width: 1.4),
                ),
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        transitionDuration: const Duration(milliseconds: 200),
                        pageBuilder: (_, __, ___) => const AddNewJobScreen(),
                        transitionsBuilder: (_, animation, __, child) {
                          return FadeTransition(
                            opacity: animation,
                            child: child,
                          );
                        },
                      ),
                    );
                  },
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(const Color.fromARGB(224, 4, 123, 218)),
                  ),
                  child: const Text("Add Job", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),),
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: mq.width * 0.07, vertical: mq.width * 0.04),
                width: mq.width * 0.74,
                height: mq.width * 0.129,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(29),
                  border: Border.all(color: Colors.white, width: 1.4),
                ),
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(
                      context,
                      PageRouteBuilder(
                        transitionDuration: const Duration(milliseconds: 200),
                        pageBuilder: (_, __, ___) => const AddNewServiceScreen(),
                        transitionsBuilder: (_, animation, __, child) {
                          return FadeTransition(
                            opacity: animation,
                            child: child,
                          );
                        },
                      ),
                    );
                  },
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(const Color.fromARGB(224, 4, 123, 218)),
                  ),
                  child: const Text("Add Service", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),),
                ),
              ),
              SizedBox(
                width: mq.width * 0.64,
                child: Opacity(
                    opacity: 0.84,
                    child: Image.asset("assets/images/lead4.png")
                ),
              ),
            ],
          ),
        )
    );
  }
}

Widget _appBar(){
  return Padding(
    padding: EdgeInsets.only(left: mq.width * 0.07, top: 12),
    child: const Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text("~  Upload Job / Service", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.2, fontFamily: "Monts"),textAlign: TextAlign.center,),
      ],
    ),
  );
}