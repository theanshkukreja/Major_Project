import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:zansh/modals/chatUser.dart';
import 'package:zansh/screens/homeScreen.dart';
import '../main.dart';
import '../api/apis.dart';
import 'package:zansh/showUps/dialogs.dart';
import '../widgets/chatCard.dart';


class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  late List<ChatUser> userList = [];

  late TextEditingController searchText = TextEditingController();
  late List<ChatUser> allUsersList = [];
  late List<ChatUser> searchList = [];
  late List<DocumentSnapshot>? searchListDS;
  bool isSearching = false;
  bool isDataFetched = false;

  @override
  void initState() {
    super.initState();
    fetchAllUsers();
  }

  @override
  Widget build(BuildContext context) {
    late TextEditingController searchText = TextEditingController();

    return SafeArea(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: PopScope(
          onPopInvoked: (x){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
          },
          canPop: false,
          child: Scaffold(
            // TextField(
            //   decoration: InputDecoration(
            //     hintText: "eg Tony Stark",
            //     hintStyle: const TextStyle(color: Colors.white70, ),
            //     //constraints: const BoxConstraints(maxHeight: 29),
            //     border: OutlineInputBorder(
            //       borderSide: const BorderSide(color: Colors.white70),
            //       borderRadius: BorderRadius.circular(9),
            //     ),
            //
            //     // enabledBorder: OutlineInputBorder(
            //     //   borderSide: const BorderSide(color: Colors.white70),
            //     //   borderRadius: BorderRadius.circular(9),
            //     // ),
            //
            //     focusedBorder: OutlineInputBorder(
            //       borderSide: const BorderSide(color: Colors.white70),
            //       borderRadius: BorderRadius.circular(9),
            //     ),
            //
            //   ),
            //
            //   autofocus: false,
            //   cursorColor: Colors.white,
            //   style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w400, letterSpacing: 0.4),
            //   onChanged: (val){
            //     searchList.clear();
            //
            //     for( var n in userList){
            //       if( n.name.toLowerCase().contains(val.toLowerCase()) || n.email.toLowerCase().contains(val.toLowerCase()) ){
            //         searchList.add(n);
            //       }
            //     } // CHECKPOINT
            //     setState(() {
            //       searchList;
            //     });
            //
            //   },
            // ),

            body: isSearching ?

                isDataFetched ?
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _appBar(),
                      searchList.isEmpty ?

                        searchText.text.isNotEmpty?
                          Padding(
                              padding: EdgeInsets.only(top: mq.height * 0.29),
                              child: const Text("Search User's Name/Email..", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
                              ))
                              :
                          Padding(
                          padding: EdgeInsets.only(top: mq.height * 0.29),
                          child: const Center(
                            child: Text("No User Found with this Name/Email  : ]", style: TextStyle(fontSize: 12.9, fontWeight: FontWeight.w600, color: Colors.white70),
                            ),
                          ))
                      :
                      ListView.builder(
                        shrinkWrap: true,
                          itemCount: searchList.length,
                          padding: const EdgeInsets.only(top: 7),
                          physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                          itemBuilder: (context, index){
                            return ChatCard(user: searchList[index], inMessages: true,);
                          }
                      ),

                    ],
                  ),
                )
                :
                const Center(
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.2),
                )
                :
            SingleChildScrollView(
              child: Column(
                children: [
                  _appBar(),

                  FutureBuilder<String>(
                    future: APIs.getCurrentUser(),
                    builder: (context, snapshot) {

                      if (snapshot.connectionState == ConnectionState.waiting) {

                        return const Center(child: CircularProgressIndicator(strokeWidth: 2,));
                      }
                      else if (snapshot.hasError) {
                        return const Center(child: Text('Something Went Wrong!', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),));
                      }
                      else if(snapshot.connectionState == ConnectionState.done){
                        // return currentScreenIndex == 0 ?
                        return StreamBuilder(
                          stream: APIs.getMyUsersId(),
                          builder: (context, snapshot){

                            // if(snapshot.hasData){
                            //   final data = snapshot.data!.docs;
                            //   for(var x in data){
                            //     log("Data - ${jsonEncode(x.data())}");
                            //   }
                            // }

                            return StreamBuilder(
                              stream: APIs.getAllUsers(
                                snapshot.data?.docs.map((e) => e.id).toList() ?? [''],
                              ),

                              builder: (context, snapshot){


                                switch(snapshot.connectionState){

                                  case ConnectionState.waiting:
                                    return const Center(child: CircularProgressIndicator());
                                  case ConnectionState.none:

                                  case ConnectionState.active:
                                  case ConnectionState.done:

                                    var data = snapshot.data?.docs;
                                    userList = data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];

                                    if(userList.isNotEmpty){

                                      return ListView.builder(
                                        shrinkWrap: true,
                                          itemCount: isSearching ? searchList.length : userList.length,
                                          padding: const EdgeInsets.only(top: 7),
                                          physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                          itemBuilder: (context, index){
                                            return ChatCard(user: isSearching ? searchList[index] : userList[index],);
                                          }
                                      );

                                    }else{
                                      return Center(
                                        child: Padding(
                                          padding: EdgeInsets.only(top: mq.height * 0.37),
                                          child: Text("No Connections Found : ]", style: TextStyle(fontSize: mq.width * .04, fontWeight: FontWeight.w400),),
                                        ),);
                                    }

                                }
                              },
                            );

                          },
                        );

                      }

                      else{
                        return const Center(child: CircularProgressIndicator(strokeWidth: 2,));
                      }
                    },
                  ),
                ],
              ),
            ),

          ),
        ),
      ),
    );
  }


  void addNewUserDialog(){
    String email = '';
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(children: [
        Icon(Icons.person, color: Colors.blue, size: 27,),
        Text('  Add User'),
      ],),

      content: TextFormField(
        onChanged: (value) => email=value,
        maxLength: 50,
        decoration: InputDecoration(
            hintText: 'example@gmail.com',
            prefixIcon: const Icon(Icons.mail, color: Colors.blue,),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(9),
            )
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 16, color: Colors.blue),),),

        MaterialButton(onPressed: (){
          if(email.isNotEmpty){
            Navigator.pop(context);
            APIs.addNewUser(email).then((value) {
              if(!value){
                Dialogs.showSnackBar(context, "User doesn't Exists!");
              }
            });
          }
        }, child: const Text('Add', style: TextStyle(fontSize: 16, color: Colors.blue),),),
      ],
    ));
  }

  Future<void> fetchAllUsersSnapshots() async {
    final CollectionReference usersRef = FirebaseFirestore.instance.collection('users');
    QuerySnapshot querySnapshot = await usersRef.get();
    searchListDS = querySnapshot.docs;
  }

  Future<void> fetchAllUsers()async {
    fetchAllUsersSnapshots().then((value) async {

      if(searchListDS != null){
        for(DocumentSnapshot a in searchListDS!){
          var data = a.data() as Map<String, dynamic>?;

          if (data != null){
          allUsersList.add(ChatUser.fromJson(data)

              // ChatUser(
              //   image: data != null && data['image'] != null ? data['image'] : "",
              //   about: data != null && data['about'] != null ? data['about'] : "",
              //   name: data != null && data['name'] != null ? data['name'] : "",
              //   createdAt: data != null && data['created_at'] != null ? data['created_at'] : "",
              //   id: data != null && data['id'] != null ? data['id'] : "",
              //   lastActive: data != null && data['last_active'] != null ? data['last_active'] : "",
              //   isOnline: data != null && data['is_online'] != null ? data['is_online'] : "",
              //   pushToken: data != null && data['push_token'] != null ? data['push_token'] : "",
              //   email: data != null && data['email'] != null ? data['email'] : "",
              //   phoneNumber: data != null && data['phoneNumber'] != null ? data['phoneNumber'] : "",
              // )
          );
      }
        }
        setState(() {
          isDataFetched = true;
        });
      }
      else{
        setState(() {
          isDataFetched = true;
        });
      }

    });
  }

  Widget _appBar(){
    return Padding(
      padding: EdgeInsets.symmetric(vertical: mq.width * 0.04),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(width: mq.width * 0.07,),
          Text(isSearching ? "Searching.." : "Messages", style: const TextStyle(fontSize: 14.9, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.2),),

          const Spacer(),
          Container(
            margin: EdgeInsets.only(right: mq.width * 0.04),
            padding: const EdgeInsets.only(left: 16, right: 1),
            width: mq.width * 0.6,
            height: mq.width * 0.12,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white, width: 1.4),
              borderRadius: BorderRadius.circular(24),
            ),
            child: TextField(
              maxLength: null,
              controller: searchText,
              onTap: (){
                if(!isSearching){
                  setState(() {
                    isSearching = true;
                  });
                }
              },
              onChanged: (val){
                searchList.clear();

                for( ChatUser n in allUsersList){
                  // dev.log(n.jTitle);
                  if( n.name.toLowerCase().contains(val.toLowerCase()) || n.email.toLowerCase().contains(val.toLowerCase()) ){
                    searchList.add(n);
                    log(n.email.toString());
                  }
                }

                setState(() {
                  searchList;
                });

              },
              decoration: InputDecoration(
                hintText: "Search User..",
                hintStyle: const TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w500),
                suffixIconConstraints: const BoxConstraints(minHeight: 0, minWidth: 0),
                suffixIcon: IconButton(
                  onPressed: (){
                    if(isSearching){
                      FocusScope.of(context).unfocus();
                      searchText.clear();
                    }
                    setState(() {
                      isSearching = !isSearching;
                    });

                  },
                  icon: Icon(isSearching ? Icons.close : Icons.search_rounded, color: Colors.white,),
                ),
                border: InputBorder.none,
                hintFadeDuration: const Duration(milliseconds: 247),
              ),
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.white, letterSpacing: 0.2),
            ),
          ),
        ],
      ),
    );
  }

}