import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:zansh/modals/newService.dart';
import 'package:zansh/screens/chatUserScreen.dart';
import 'package:zansh/screens/search/viewUserProfile.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../../modals/chatUser.dart';
import '../../showUps/dialogs.dart';
import 'package:zansh/modals/messageModal.dart';

class ViewServiceBriefly extends StatefulWidget {
  final ServicePost service;
  final bool isMe;
  const ViewServiceBriefly({super.key, required this.service, this.isMe = false});

  @override
  State<ViewServiceBriefly> createState() => _ViewServiceBrieflyState();
}

class _ViewServiceBrieflyState extends State<ViewServiceBriefly> {

  bool isSaved = false;
  late ChatUser postUser;
  String isUserFetched = "false";
  Color cxColor = Colors.white;

  @override
  void initState() {
    super.initState();
    checkSaveStatus(widget.service.id);
    getPostUser();
    updateViews();
  }

  void updateViews() async {
    try{
      int n = int.tryParse(widget.service.postViews) ?? 0;
      await APIs.updateXPostViews(pId: widget.service.id, views: n+1);
    }
    catch(e){
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _appBar(),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                child: const Divider(color: Colors.white38, thickness: 0.2, height: 7, ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(vertical: mq.height * 0.014, horizontal: mq.width * 0.05),
                child: Center(
                  child: Text(widget.service.sTitle, style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 19, color: Color.fromARGB(255, 27, 183, 241),
                      letterSpacing: 0.49, fontFamily: "Monts"
                  ),),
                ),
              ),

              Container(
                width: mq.width * 0.9,
                margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049),
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.021, vertical: mq.width * 0.02),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(mq.width * 0.02),
                  color: const Color.fromARGB(049, 43, 45, 48),
                ),
                child: Text(widget.service.sDesc, style: TextStyle(
                  fontWeight: FontWeight.w600, fontSize: 14, color: cxColor,
                  letterSpacing: 0.49,
                ),
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.17),
                child: Divider(color: Colors.white38, thickness: 0.2, height: mq.width * 0.1, ),
              ),


              Container(
                width: mq.width * 0.9,
                margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049),
                padding: EdgeInsets.only(left: mq.width * 0.021, right: mq.width * 0.021,bottom: mq.width * 0.02),
                child: Text("Fees Approx", style: TextStyle(
                  fontSize: 12, color: Colors.blue.shade400,
                  fontWeight: FontWeight.w500,
                  fontFamily: "Monts",
                  letterSpacing: 0.6,
                ),
                ),
              ),

              Container(
                width: mq.width * 0.9,
                margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049),
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.021, vertical: mq.width * 0.02),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(mq.width * 0.02),
                  color: const Color.fromARGB(255, 43, 45, 48),
                ),
                child: Row(
                  children: [
                    Text(widget.service.sFeesCurrency == "rupee" ? "₹ " : "\$ ", style: TextStyle(fontSize: widget.service.sFeesCurrency == "rupee" ? 16 : 14, fontWeight: FontWeight.w600, color: Colors.greenAccent, letterSpacing: 0.4),),
                    Text(widget.service.sFees, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.greenAccent, letterSpacing: 0.4),),
                    const SizedBox(width: 7,),
                    Text(widget.service.sFeesPer, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: cxColor, letterSpacing: 0.4),),

                    const Spacer(),
                  ],
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.17),
                child: Divider(color: Colors.white38, thickness: 0.2, height: mq.width * 0.1, ),
              ),

              Container(
                width: mq.width * 0.9,
                margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049),
                padding: EdgeInsets.only(left: mq.width * 0.021, right: mq.width * 0.021,bottom: mq.width * 0.02),
                child: Text("Location", style: TextStyle(
                  fontSize: 12, color: Colors.blue.shade400,
                  fontWeight: FontWeight.w500,
                  fontFamily: "Monts",
                  letterSpacing: 0.6,
                ),
                ),
              ),

              Container(
                width: mq.width * 0.9,
                margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049),
                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.021, vertical: mq.width * 0.02),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(mq.width * 0.02),
                  color: const Color.fromARGB(255, 43, 45, 48),
                ),
                child: Text("${widget.service.sStreetAddress}, ${widget.service.sCity}, ${widget.service.sState}",
                  style: TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w600, color: cxColor, letterSpacing: 0.4,
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.only(left: mq.width * 0.17, right: mq.width * 0.17, top: mq.width * 0.049),
                child: const Divider(color: Colors.white38, thickness: 0.2, height: 0, ),
              ),

              widget.service.sImage != "" && widget.service.sImage != " "?
              Center(
                child: Padding(
                  padding: EdgeInsets.only(top: mq.width * 0.07, bottom: mq.width * 0.07),
                  child: Container(
                    height: mq.width * 0.9,
                    width: mq.width * 0.9,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(19),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(7),
                      child: CachedNetworkImage(
                        imageUrl: widget.service.sImage,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Center(child: SizedBox(height: mq.width * 0.07, width: mq.width * 0.07, child: const CircularProgressIndicator(strokeWidth: 2,))),
                        errorWidget: (context, url, error) => const Icon(Icons.error_outline_rounded,size: 40,),
                      ),
                    ),
                  ),
                ),
              )
                  :
              SizedBox(height: mq.width * 0.07,),

              widget.service.sImage != "" && widget.service.sImage != " "?
              Padding(
                padding: EdgeInsets.only(left: mq.width * 0.17, right: mq.width * 0.17, bottom: mq.width * 0.049),
                child: const Divider(color: Colors.white38, thickness: 0.2, height: 0, ),
              )
                  :
              const SizedBox(),

              Row(
                children: [
                  Container(
                    width: mq.width * 0.29,
                    margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049, bottom: mq.width * 0.04),
                    padding: EdgeInsets.only(left: mq.width * 0.021, right: mq.width * 0.021,bottom: mq.width * 0.02),
                    child: Text("Posted by ~", style: TextStyle(
                      fontSize: 12, color: Colors.blue.shade400,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Monts",
                      letterSpacing: 0.6,
                    ),
                    ),
                  ),

                  const Spacer(),

                  Container(
                    width: mq.width * 0.29,
                    margin: EdgeInsets.only(left: mq.width * 0.049, right: mq.width * 0.049, bottom: mq.width * 0.04),
                    padding: EdgeInsets.only(left: mq.width * 0.021, right: mq.width * 0.021,bottom: mq.width * 0.02),
                    child: Text(getUploadTime(uploadTime: widget.service.uploadTime), style: TextStyle(
                      fontSize: 12, color: Colors.blue.shade400,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Monts",
                      letterSpacing: 0.6,
                    ),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),

              isUserFetched == "true" ?
              GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ViewUserProfile(user: postUser)));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    Container(
                      height: mq.width * 0.258,
                      width: mq.width * 0.258,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white70, width: 1.7),
                        borderRadius: BorderRadius.circular(mq.width * 0.129),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(mq.width * 0.12),
                        child: CachedNetworkImage(
                          height: mq.width * 0.24,
                          width: mq.width * 0.24,
                          fit: BoxFit.cover,
                          imageUrl: postUser.image,
                          placeholder: (context, url) => const CircularProgressIndicator(color: Colors.white70,strokeWidth: 1.2,),
                          errorWidget: (context, url, error) => const CircleAvatar(child:Icon(Icons.account_circle, color: Colors.white70,),),
                        ),
                      ),
                    ),

                    SizedBox(width: mq.width * 0.04),

                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            width: mq.width * 0.47,
                            child: Text(postUser.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),overflow: TextOverflow.ellipsis,)
                        ),

                        SizedBox(height: mq.height * 0.007,),

                        SizedBox(
                            width: mq.width * 0.47,
                            child: Text(postUser.email, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white70),overflow: TextOverflow.ellipsis,)
                        ),
                        // SizedBox(height: mq.height * 0.01,),
                        // Text(widget.user.about, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.black54),),
                      ],
                    ),

                  ],
                ),
              )
                  :
              isUserFetched == "empty" ?
              const Center(
                child: Text("Unable to fetch User Details..", style: TextStyle(
                  fontSize: 11, color: Colors.redAccent,
                  fontWeight: FontWeight.w400,
                  fontFamily: "Monts",
                  letterSpacing: 0.6,
                ),
                ),
              )
                  :
              const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1),),

              Padding(
                padding: EdgeInsets.only(top: mq.width * 0.049, bottom: mq.width * 0.09),
                child: const Divider(color: Colors.white38, thickness: 0.2, height: 0, ),
              ),

              widget.service.sPhone != '' && widget.service.sPhone != ' ' && widget.service.sPhone.isNotEmpty ?
              Center(
                child: SizedBox(
                  width: mq.width * 0.9,
                  height: 40,
                  child: ElevatedButton(
                    onPressed: (){
                      makePhoneCall(widget.service.sPhone);
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(const Color.fromARGB(224, 4, 123, 218)),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text("Call ", style: TextStyle(color: Color.fromARGB(255, 245, 245, 245), fontWeight: FontWeight.w400, fontSize: 12.9, letterSpacing: 0.2, fontFamily: "Monts"),),
                          const Icon(Icons.call, color: Colors.white, size: 12.9),
                          Text(" ${widget.service.sPhone}", style: const TextStyle(color: Color.fromARGB(255, 245, 245, 245), fontWeight: FontWeight.w400, fontSize: 12.9, letterSpacing: 0.2, fontFamily: "Monts"),),
                        ],
                      ),
                    ),
                  ),
                ),
              )
                  :
              const SizedBox(),

              widget.service.sPhone != '' && widget.service.sPhone != ' ' && widget.service.sPhone.isNotEmpty ?
              SizedBox(height: mq.width * 0.049) : SizedBox(height: mq.width * 0.019),

              Center(
                child: SizedBox(
                  width: mq.width * 0.9,
                  height: 40,
                  child: ElevatedButton(
                    onPressed: (){
                      //applyForServiceDialog();

                      if(widget.isMe == false){
                        if(isUserFetched == "true"){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => ChatUserScreen(user: postUser)));
                          APIs.sendFirstMessage(postUser, " -- ${widget.service.sTitle} --\n\n\tHey! I am Interested in this Service..", Type.text, isApplication: "true");
                        }
                        else{
                          Dialogs.showSnackBar(context, "Something Went Wrong!");
                        }
                      }
                      else{
                        Dialogs.showSnackBar(context, "Can't Chat!");
                      }
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(const Color.fromARGB(224, 4, 123, 218)),
                    ),
                    child: const Center(child: Text("Chat with User", style: TextStyle(color: Color.fromARGB(255, 245, 245, 245), fontWeight: FontWeight.w500, fontSize: 12.9, letterSpacing: 0.2, fontFamily: "Monts"),)),
                  ),
                ),
              ),

              SizedBox(height: mq.width * 0.2,),

            ],
          ),
        ),
      ),
    );
  }

  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(width: mq.width * 0.027,),
        IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back_ios_new_sharp, color: cxColor, size: 21,)
        ),
        //const Icon(Icons.edit, color: Colors.white70, size: 21,),
        SizedBox(width: mq.width * 0.04,),
        Text("Service Details", style: TextStyle(fontSize: 14.9, color: cxColor, fontWeight: FontWeight.w500, fontFamily: "Monts"),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
          textAlign: TextAlign.start,
        ),

        const Spacer(),

        IconButton(
            onPressed: (){
              if(!widget.isMe){
                void savePost()async {
                  await APIs.savePost(widget.service.id).then((value) {
                    Dialogs.showSnackBar(context, "Saved!");
                  });
                  setState(() {
                    isSaved = !isSaved;
                  });
                }
                void unSavePost()async{
                  await APIs.unSavePost(widget.service.id);
                  setState(() {
                    isSaved = !isSaved;
                  });
                }

                isSaved ?
                unSavePost()
                    :
                savePost();
              }
            },
            icon: widget.isMe ?
            PopupMenuButton(
                icon: const Icon(Icons.more_vert, color: Colors.white70,),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                color: const Color.fromARGB(255, 43, 45, 48),
                itemBuilder: ((context){
                  return [

                    PopupMenuItem(
                        child: ListTile(
                          onTap: (){
                            deletePostDialog();
                          },
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                          leading: const Padding(
                            padding: EdgeInsets.only(left: 9.0),
                            child: Icon(Icons.delete, color: Colors.redAccent,),
                          ),
                          title: const Text("Delete Post", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.redAccent),),
                        )
                    ),

                  ];}))
                :
            Icon(isSaved ? CupertinoIcons.bookmark_fill : CupertinoIcons.bookmark, size: 29, color: Colors.blue,)
        ),
        SizedBox(width: widget.isMe ? mq.width * 0.02 : mq.width * 0.04,)
      ],
    );
  }

  void makePhoneCall(String phoneNumber) async {
    final Uri url = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );

    if (await canLaunchUrl(url)) {
      try{
        await launchUrl(url);
      }
      catch(e){
        log("~~~~~~~~~~~~~~~ ${e.toString()} !!!!!!!!!!!!!!!!");
        Dialogs.showSnackBar(context, "Unable To Call User!");
      }
    } else {
      Dialogs.showSnackBar(context, "Unable To Call User!");
    }
  }

  void deletePostDialog(){
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      backgroundColor: const Color.fromARGB(255, 43, 45, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Icon(Icons.delete, color: Colors.redAccent, size: 24,),
          SizedBox(width: 12,),
          Text('Delete Post Permanently', style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
        ],),

      content: Container(
        margin: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
        ),
        child: const Text(
          "Once Deleted, Post can't be Recovered!",
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 14, color: Colors.white70),),),

        MaterialButton(onPressed: (){
          if(widget.service.sImage != "" && widget.service.sImage != " "){
            Dialogs.showCircularProgress(context, Colors.white);
            APIs.deleteMyPost(widget.service.id, true, widget.service.sImage).then((value){
              Navigator.pop(context);
              Navigator.pop(context);
              Navigator.pop(context);
              Navigator.pop(context);
              Dialogs.showSnackBar(context, "Deleted!");
            });
          }
          else{
            Dialogs.showCircularProgress(context, Colors.white);
            APIs.deleteMyPost(widget.service.id, false, "").then((value){
              Navigator.pop(context);
              Navigator.pop(context);
              Navigator.pop(context);
              Navigator.pop(context);
              Dialogs.showSnackBar(context, "Deleted!");

            });
          }
        }, child: const Text('Delete!', style: TextStyle(fontSize: 14, color: Colors.redAccent),),),
      ],
    ));
  }

  void applyForServiceDialog(){
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      backgroundColor: const Color.fromARGB(255, 43, 45, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Icon(Icons.gpp_good, color: Colors.blue, size: 24,),
          SizedBox(width: 12,),
          Text('Apply for the Service', style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
        ],),

      content: Container(
        margin: const EdgeInsets.only(top: 9, bottom: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
        ),
        child: Text(
          "~  ${widget.service.sTitle}",
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
          //textAlign: TextAlign.center,
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 14, color: Colors.white70),),),

        SizedBox(
          height: mq.width * 0.09,
          //width: mq.width * 0.24,
          child: ElevatedButton(
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
            ),
            onPressed: (){
              if(widget.isMe == false){
                if(isUserFetched == "true"){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ChatUserScreen(user: postUser)));
                  APIs.sendFirstMessage(postUser, " -- ${widget.service.sTitle} --\n\n\tHey! I am Interested in this Service..", Type.text, isApplication: "true");
                }
                else{
                  Dialogs.showSnackBar(context, "Something Went Wrong!");
                }
              }
              else{
                Navigator.pop(context);
                Dialogs.showSnackBar(context, "Can't  Apply!");
              }
            },
            child: const Text('Apply', style: TextStyle(fontSize: 14, color: Colors.white, fontFamily: "Monts", fontWeight: FontWeight.w400),),
          ),
        ),
      ],
    ));
  }

  Future<void> checkSaveStatus(String postId) async {
    List<DocumentSnapshot>? allSaves;

    Future<void> getAllSaves() async {
      final CollectionReference airChatsFireRef = FirebaseFirestore.instance.collection('users').doc(APIs.user.uid).collection('savedPosts');
      QuerySnapshot querySnapshot = await airChatsFireRef.get();
      allSaves = querySnapshot.docs;
    }

    await getAllSaves().then((value) {
      if (allSaves != null) {
        for (DocumentSnapshot a in allSaves!) {
          var data = a.data() as Map<String, dynamic>?;

          if(a.id.toString() == postId){
            //log("-- Working ${a.id} ----");
            setState(() {
              isSaved = true;
            });
          }
        }}
    }

    );
  }

  getPostUser() async{
    await APIs.getPostUserWEmail(widget.service.email, widget.service.name).then((user){
      setState(() {
        if(user != null){
          setState(() {
            postUser = user;
            isUserFetched = "true";
          });
        }
        else{
          setState(() {
            isUserFetched = "empty";
          });
        }
      });
    });
  }

  getUploadTime({required String uploadTime}){

    final int i = int.tryParse(uploadTime) ?? -1;

    if(i == -1) return '--';

    DateTime time = DateTime.fromMillisecondsSinceEpoch(i);
    String formattedTime = TimeOfDay.fromDateTime(time).format(context);
    int y = time.day;
    String month = _getMonth(time);

    return '${time.day} $month, ${time.year}';

  }

  static String _getMonth(DateTime date){
    switch(date.month){
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return 'NA';
    }

  }

}
