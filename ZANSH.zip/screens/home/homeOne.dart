import 'dart:developer' as dev;
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:zansh/modals/newJob.dart';
import 'package:zansh/modals/newService.dart';
import 'package:zansh/widgets/jobCard.dart';
import 'package:zansh/widgets/serviceCard.dart';
import '../../api/apis.dart';
import '../../main.dart';

class HomeOne extends StatefulWidget {
  const HomeOne({super.key});

  @override
  State<HomeOne> createState() => _HomeOneState();
}

class _HomeOneState extends State<HomeOne> with SingleTickerProviderStateMixin{

  late TabController _tabController;
  late TextEditingController searchText = TextEditingController();
  bool isLocationPermissionGranted = false;
  bool isLocationGranted = false;
  bool isPostsFetched = false;
  bool isPostsFetchedS = false;
  bool showOnlyJobs = true;
  late Position _currentPosition;

  late List<DocumentSnapshot>? jobsListDS;
  late List<DocumentSnapshot>? servicesListDS;
  List<JobPost> jobsList = [];
  List<ServicePost> servicesList = [];

  List<JobPost> jobsListX = [];
  List<ServicePost> servicesListX = [];
  List<JobPost> jobsListX9 = [];
  List<ServicePost> servicesListX9 = [];

  bool isSearching = false;
  bool showNearby = false; // "everyone";
  String feedContent = "all"; // jobs only, services only

  List<JobPost> jobsSearchList = [];
  List<ServicePost> servicesSearchList = [];

  @override
  void initState() {
    super.initState();
    APIs.updateActiveStatus(true);
    _tabController = TabController(length: 2, vsync: this);
    if(showNearby == true){
      fetchAllPosts();
    }
  }


  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (x){
        if(isSearching){
          setState(() {
            isSearching = false;
            searchText.clear();
          });
        }
      },
      canPop: isSearching ? false : true,
      child: SafeArea(
          child: GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Scaffold(
              body: isSearching ?

                  Column(
                    children: [
                      _appBar(),

                      ((jobsSearchList.length + servicesSearchList.length) != 0) ?
                      Expanded(
                        child: ListView.builder(
                          physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                          shrinkWrap: true,
                          padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                          itemCount: (jobsSearchList.length + servicesSearchList.length),
                          itemBuilder: (BuildContext context, int index){
                            //return JobCard(job: jobsSearchList[index], isNearby: false);
                            if(jobsSearchList.length > index){
                              return JobCard(job: jobsSearchList[index], isNearby: false,);
                            }
                            else if(jobsSearchList.length <= index){
                              return ServiceCard(service: servicesSearchList[index - jobsSearchList.length], isNearby: false,);
                            }
                            else{
                              return ServiceCard(service: servicesSearchList[index - jobsSearchList.length], isNearby: false,);

                            }
                          },
                        ),
                      )
                      :
                          searchText.text.isEmpty ?
                          Center(child: Padding(
                            padding: EdgeInsets.only(top: mq.height * 0.2),
                            child: const Text("Search for Job/Service..", style: TextStyle(fontSize: 12.9),),
                          ),)
                              :

                      Center(child: Padding(
                        padding: EdgeInsets.only(top: mq.height * 0.2),
                        child: const Text("No Post Found with this Title..", style: TextStyle(fontSize: 12.9),),
                      ),),
                    ],
                  )


                  :

              showNearby == true ?

              Column(
                children: [
                  _appBar(),

                  isLocationPermissionGranted ?

                  isLocationGranted ?

                  isPostsFetched && isPostsFetchedS ?

                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: ()async{
                        await refreshScreen();
                      },
                      color: Colors.white,
                      strokeWidth: 2.1,
                      backgroundColor: Colors.black,
                      child: ListView(
                        physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: mq.width * 0.07, top: mq.height * 0.024),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                GestureDetector(
                                  onTap: (){
                                    if(!showOnlyJobs){
                                      setState(() {
                                        showOnlyJobs = true;
                                      });
                                    }
                                  },
                                  child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 299),
                                      height: 40,
                                      padding: const EdgeInsets.only(left: 21, right: 21, top: 1, bottom: 1),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(mq.width * 0.85),
                                        color: showOnlyJobs ? Colors.lightBlue.shade900 : Colors.white24,
                                      ),
                                      child: Center(child: Text("Jobs", style: TextStyle(color: const Color.fromARGB(255, 219, 222, 222), fontSize: 14, fontWeight: showOnlyJobs? FontWeight.w500 : FontWeight.w400),))
                                  ),
                                ),
                                GestureDetector(
                                  onTap: (){
                                    if(showOnlyJobs){
                                      setState(() {
                                        showOnlyJobs = false;
                                      });
                                    }
                                  },
                                  child: AnimatedContainer(
                                      margin: const EdgeInsets.only(left: 9),
                                      duration: const Duration(milliseconds: 299),
                                      height: 40,
                                      padding: const EdgeInsets.only(left: 17, right: 17, top: 1, bottom: 1),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(mq.width * 0.85),
                                        color: !showOnlyJobs ? Colors.lightBlue.shade900 : Colors.white24,
                                      ),
                                      child: Center(child: Text("Services", style: TextStyle(color: const Color.fromARGB(255, 219, 222, 222), fontSize: 14, fontWeight: !showOnlyJobs? FontWeight.w500 : FontWeight.w400),))
                                  ),
                                )
                              ],
                            ),
                          ),

                          showOnlyJobs ?
                                  (jobsList.isNotEmpty) ?
                                  ListView.builder(
                                    physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                    shrinkWrap: true,
                                    itemCount: (jobsList.length), //servicesList.length
                                    itemBuilder: (BuildContext context, int index) {

                                      return Padding(
                                          padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                          child: JobCard(job: jobsList[index], isNearby: true,)
                                      );

                                    },

                                  )
                                      :
                                      Center(
                                        child: Padding(
                                            padding: EdgeInsets.only(top: mq.height * 0.32),
                                          child: const Text("No Nearby Posts Found :]"),
                                        ),
                                      )
                              :
                                  (servicesList.isNotEmpty) ?
                                  ListView.builder(
                                    physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                    shrinkWrap: true,
                                    itemCount: (servicesList.length),
                                    itemBuilder: (BuildContext context, int index) {

                                      return Padding(
                                          padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                          child: ServiceCard(service: servicesList[index], isNearby: true,)
                                      );

                                    },

                                  )
                                      :
                                  Center(
                                    child: Padding(
                                      padding: EdgeInsets.only(top: mq.height * 0.32),
                                      child: const Text("No Nearby Posts Found :]"),
                                    ),
                                  ),

                          const Padding(
                            padding: EdgeInsets.only(top: 19,bottom: 19.0, left: 9, right: 9),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text("Connect with us on Instagram @zansh.co.in", style: TextStyle(fontSize: 9.9, color: Colors.white60, fontWeight: FontWeight.w500, fontFamily: "Monts"),),
                                SizedBox(height: 4,),
                                Text("For Feedback/Suggestions mail us - contact@zansh.co.in", style: TextStyle(fontSize: 9.9, color: Colors.white60, fontWeight: FontWeight.w500, fontFamily: "Monts"),),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  )

                      :

                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: mq.height * 0.27,),
                      const CircularProgressIndicator(color: Colors.white,strokeWidth: 1.9,),
                    ],
                  )
                      :

                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: mq.height * 0.27,),
                      const CircularProgressIndicator(color: Colors.white,strokeWidth: 1.9,),
                    ],
                  )

                      :

                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: mq.height * 0.29,),
                        IconButton(
                          onPressed: (){
                            getCurrentLocation().then((value) { });
                          },
                          icon: const Icon(Icons.location_on_outlined, color: Colors.blue, size: 49,),
                        ),
                        const SizedBox(height: 19,),
                        const Text('Need Access to Location :)', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 12),),
                      ],
                    ),
                  ),

                ],
              )

                  :

              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _appBar(),

                  Expanded(
                    child: StreamBuilder(
                      stream: APIs.getAllJobs(),
                      builder: (context, snapshot){
                    
                        switch(snapshot.connectionState){
                          case ConnectionState.waiting:
                            return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                          case ConnectionState.none:
                    
                          case ConnectionState.active:
                          case ConnectionState.done:
                    
                            var data = snapshot.data?.docs;
                            jobsListX9 = [];
                            jobsListX9 = data?.map((e) => JobPost.fromJson(e.data())).toList() ?? [];
                            jobsListX = [];
                            for(var x in jobsListX9){
                              if(true){             // x.jVisibility == "everyone"
                                jobsListX.add(x);
                              }
                            }
                    
                            return StreamBuilder(
                                stream: APIs.getAllServices(),
                                builder: (context, snapshot){
                    
                                  switch(snapshot.connectionState){
                                    case ConnectionState.waiting:
                                      return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                                    case ConnectionState.none:
                    
                                    case ConnectionState.active:
                                    case ConnectionState.done:
                    
                                      var data = snapshot.data?.docs;
                                      servicesListX9 = [];
                                      servicesListX9 = data?.map((e) => ServicePost.fromJson(e.data())).toList() ?? [];
                                      servicesListX = [];
                                      for(var x in servicesListX9){
                                        if(true){       // x.sVisibility == "everyone"
                                          servicesListX.add(x);
                                        }
                                      }
                    
                                      return RefreshIndicator(
                                        onRefresh: ()async{
                                          await refreshScreen();
                                        },
                                        color: Colors.white,
                                        strokeWidth: 2.1,
                                        backgroundColor: Colors.black,
                                        child: ListView(
                                          physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                          children: [

                                            Padding(
                                              padding: EdgeInsets.only(left: mq.width * 0.07, top: mq.height * 0.024),
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  GestureDetector(
                                                    onTap: (){
                                                      if(!showOnlyJobs){
                                                        setState(() {
                                                          showOnlyJobs = true;
                                                        });
                                                      }
                                                    },
                                                    child: AnimatedContainer(
                                                        duration: const Duration(milliseconds: 299),
                                                        height: 40,
                                                        padding: const EdgeInsets.only(left: 21, right: 21, top: 1, bottom: 1),
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.circular(mq.width * 0.85),
                                                          color: showOnlyJobs ? Colors.lightBlue.shade900 : Colors.white24,
                                                        ),
                                                        child: Center(child: Text("Jobs", style: TextStyle(color: const Color.fromARGB(255, 219, 222, 222), fontSize: 14, fontWeight: showOnlyJobs? FontWeight.w500 : FontWeight.w400),))
                                                    ),
                                                  ),
                                                  GestureDetector(
                                                    onTap: (){
                                                      if(showOnlyJobs){
                                                        setState(() {
                                                          showOnlyJobs = false;
                                                        });
                                                      }
                                                    },
                                                    child: AnimatedContainer(
                                                        margin: const EdgeInsets.only(left: 9),
                                                        duration: const Duration(milliseconds: 299),
                                                        height: 40,
                                                        padding: const EdgeInsets.only(left: 17, right: 17, top: 1, bottom: 1),
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.circular(mq.width * 0.85),
                                                          color: !showOnlyJobs ? Colors.lightBlue.shade900 : Colors.white24,
                                                        ),
                                                        child: Center(child: Text("Services", style: TextStyle(color: const Color.fromARGB(255, 219, 222, 222), fontSize: 14, fontWeight: !showOnlyJobs? FontWeight.w500 : FontWeight.w400),))
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),

                                            showOnlyJobs ?
                                                (jobsListX.isNotEmpty) ?
                                                    ListView.builder(
                                                      shrinkWrap: true,
                                                        itemCount: (jobsListX.length), //servicesListX.length
                                                        //padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                        physics: const BouncingScrollPhysics(
                                                            decelerationRate: ScrollDecelerationRate.fast
                                                        ),
                                                        itemBuilder: (context, index) {

                                                          return Padding(
                                                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                              child: JobCard(job: jobsListX[index], isNearby: false,)
                                                          );

                                                        }
                                                    )
                                                        :
                                                    Center(
                                                      child: Padding(
                                                        padding: EdgeInsets.only(top: mq.height * 0.32),
                                                        child: const Text("No Posts Found :]"),
                                                      ),
                                                    )
                                            :
                                                (servicesListX.isNotEmpty) ?
                                                    ListView.builder(
                                                        shrinkWrap: true,
                                                        itemCount: (servicesListX.length),
                                                        //padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                        physics: const BouncingScrollPhysics(
                                                            decelerationRate: ScrollDecelerationRate.fast
                                                        ),
                                                        itemBuilder: (context, index) {
                                                          return Padding(
                                                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                              child: ServiceCard(service: servicesListX[index], isNearby: false,)
                                                          );
                                                        }
                                                    )
                                                        :
                                                    Center(
                                                      child: Padding(
                                                        padding: EdgeInsets.only(top: mq.height * 0.32),
                                                        child: const Text("No Posts Found :]"),
                                                      ),
                                                    ),

                                            const Padding(
                                              padding: EdgeInsets.only(top: 19,bottom: 19.0, left: 9, right: 9),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Text("Connect with us on Instagram @zansh.co.in", style: TextStyle(fontSize: 9.9, color: Colors.white60, fontWeight: FontWeight.w500, fontFamily: "Monts"),),
                                                  SizedBox(height: 4,),
                                                  Text("For Feedback/Suggestions mail us - contact@zansh.co.in", style: TextStyle(fontSize: 9.9, color: Colors.white60, fontWeight: FontWeight.w500, fontFamily: "Monts"),),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      );
                    
                                  }
                                }
                            );
                    
                        }
                    
                      },
                    ),
                  )
                ],
              ),

            ),
          )
      ),
    );
  }



  Future<void> fetchAllPostsSnapshots() async {
    final CollectionReference airChatsFireRef = FirebaseFirestore.instance.collection('posts');
    QuerySnapshot querySnapshot = await airChatsFireRef.where('isJob', isEqualTo: true).get();
    QuerySnapshot querySnapshotS = await airChatsFireRef.where('isJob', isEqualTo: false).get();
    jobsListDS = querySnapshot.docs;
    servicesListDS = querySnapshotS.docs;
  }

  double radians(double degrees) {
    return degrees * pi / 180;
  }

  Future<void> getCurrentLocation()async{

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return;
    }

    setState(() {
      isLocationPermissionGranted = true;
    });
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.bestForNavigation,
    );

    setState(() {
      _currentPosition = position;
      isLocationGranted = true;
    });
  }

  int findTimeDifferenceHours(int time){
    int currentTimeMillis = DateTime.now().millisecondsSinceEpoch;
    int previousTimeMillis = time;

    DateTime currentTime = DateTime.fromMillisecondsSinceEpoch(currentTimeMillis);
    DateTime previousTime = DateTime.fromMillisecondsSinceEpoch(previousTimeMillis);

    Duration difference = currentTime.difference(previousTime);
    int differenceInHours = difference.inHours;

    return differenceInHours;
  }

  double getDistanceInKm(double startLatitude, double startLongitude, double endLatitude, double endLongitude) {
    const double earthRadius = 6371; // Earth's radius in meters

    double lat1Rad = radians(startLatitude);
    double lat2Rad = radians(endLatitude);
    double deltaLat = radians(endLatitude - startLatitude);
    double deltaLon = radians(endLongitude - startLongitude);

    double a = pow(sin(deltaLat / 2), 2) + cos(lat1Rad) * cos(lat2Rad) * pow(sin(deltaLon / 2), 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double distance = earthRadius * c;

    return distance;
  }

  Future<void> fetchAllPosts()async{
    getCurrentLocation().then((value){

      fetchAllPostsSnapshots().then((value) async {

        if(jobsListDS != null){
          for(DocumentSnapshot a in jobsListDS!){
            dev.log(a.toString());

            var data = a.data() as Map<String, dynamic>?;
            double? pLong = (data != null && data['longitude'] != null ? double.tryParse(data['longitude']) : null);
            double? pLat = data != null && data['latitude'] != null ? double.tryParse(data['latitude']) : null;
            double uLong = _currentPosition.longitude;
            double uLat = _currentPosition.latitude;

            double distance = getDistanceInKm(uLat, uLong, pLat ?? 0, pLong ?? 0);

            //Adding final Jobs to List..
            int? uTime = data != null && data['uploadTime'] != null ? int.tryParse(data['uploadTime']) : null;
            int duration = findTimeDifferenceHours(uTime ?? 0);

            //String? visibility = data != null && data['jVisibility'] != null ? data['jVisibility'] : "";
            // visibility == "everyone"

            if(distance <= 20){
              jobsList.add(
                  JobPost(
                    id: data != null && data['id'] != null ? data['id'] : "",
                    callAction: data != null && data['callAction'] != null ? data['callAction'] : "",
                    chatAction: data != null && data['chatAction'] != null ? data['chatAction'] : "",
                    postViews: data != null && data['postViews'] != null ? data['postViews'] : "",
                    jPhone: data != null && data['jPhone'] != null ? data['jPhone'] : "",
                    distance: distance,
                    duration: duration,
                    jCity: data != null && data['jCity'] != null ? data['jCity'] : "",
                    image: data != null && data['image'] != null ? data['image'] : "",
                    jRequirements: data != null && data['jRequirements'] != null ? data['jRequirements'] : "",
                    jSalaryCurrency: data != null && data['jSalaryCurrency'] != null ? data['jSalaryCurrency'] : "",
                    latitude: data != null && data['latitude'] != null ? data['latitude'] : "",
                    jImage: data != null && data['jImage'] != null ? data['jImage'] : "",
                    uploadTime: data != null && data['uploadTime'] != null ? data['uploadTime'] : "",
                    jDesc: data != null && data['jDesc'] != null ? data['jDesc'] : "",
                    isJob: data != null && data['isJob'] != null ? data['isJob'] : "",
                    jState: data != null && data['jState'] != null ? data['jState'] : "",
                    jisItAWorkFromHome: data != null && data['jisItAWorkFromHome'] != null ? data['jisItAWorkFromHome'] : "",
                    jSalary: data != null && data['jSalary'] != null ? data['jSalary'] : "",
                    jVisibility: data != null && data['jVisibility'] != null ? data['jVisibility'] : "",
                    name: data != null && data['name'] != null ? data['name'] : "",
                    jSalaryPer: data != null && data['jSalaryPer'] != null ? data['jSalaryPer'] : "",
                    jType: data != null && data['jType'] != null ? data['jType'] : "",
                    jTitle: data != null && data['jTitle'] != null ? data['jTitle'] : "",
                    jStreetAddress: data != null && data['jStreetAddress'] != null ? data['jStreetAddress'] : "",
                    email: data != null && data['email'] != null ? data['email'] : "",
                    likes: data != null && data['likes'] != null ? data['likes'] : "",
                    longitude: data != null && data['longitude'] != null ? data['longitude'] : "",
                  )
              );
            }

          }
          setState(() {
            isPostsFetched = true;
          });
        }
        else{
          setState(() {
            isPostsFetched = true;
          });
        }

        if(servicesListDS != null){
          for(DocumentSnapshot a in servicesListDS!){
            dev.log(a.toString());

            var data = a.data() as Map<String, dynamic>?;
            double? pLong = (data != null && data['longitude'] != null ? double.tryParse(data['longitude']) : null);
            double? pLat = data != null && data['latitude'] != null ? double.tryParse(data['latitude']) : null;
            double uLong = _currentPosition.longitude;
            double uLat = _currentPosition.latitude;

            double distance = getDistanceInKm(uLat, uLong, pLat ?? 0, pLong ?? 0);

            //Adding final Services to List..
            int? uTime = data != null && data['uploadTime'] != null ? int.tryParse(data['uploadTime']) : null;
            int duration = findTimeDifferenceHours(uTime ?? 0);
            //String? visibility = data != null && data['sVisibility'] != null ? data['sVisibility'] : "";

            if(distance <= 20){
              servicesList.add(
                  ServicePost(
                    duration: duration,
                      distance: distance,
                      callAction: data != null && data['callAction'] != null ? data['callAction'] : "",
                      chatAction: data != null && data['chatAction'] != null ? data['chatAction'] : "",
                      postViews: data != null && data['postViews'] != null ? data['postViews'] : "",
                      id: data != null && data['id'] != null ? data['id'] : "",
                      sPhone: data != null && data['sPhone'] != null ? data['sPhone'] : "",
                      image: data != null && data['image'] != null ? data['image'] : "",
                      sFeesPer: data != null && data['sFeesPer'] != null ? data['sFeesPer'] : "",
                      latitude: data != null && data['latitude'] != null ? data['latitude'] : "",
                      sCity: data != null && data['sCity'] != null ? data['sCity'] : "",
                      sTitle: data != null && data['sTitle'] != null ? data['sTitle'] : "",
                      uploadTime: data != null && data['uploadTime'] != null ? data['uploadTime'] : "",
                      isJob: data != null && data['isJob'] != null ? data['isJob'] : "",
                      sDesc: data != null && data['sDesc'] != null ? data['sDesc'] : "",
                      sVisibility: data != null && data['sVisibility'] != null ? data['sVisibility'] : "",
                      sFees: data != null && data['sFees'] != null ? data['sFees'] : "",
                      name: data != null && data['name'] != null ? data['name'] : "",
                      sState: data != null && data['sState'] != null ? data['sState'] : "",
                      sStreetAddress: data != null && data['sStreetAddress'] != null ? data['sStreetAddress'] : "",
                      sImage: data != null && data['sImage'] != null ? data['sImage'] : "",
                      email: data != null && data['email'] != null ? data['email'] : "",
                      longitude: data != null && data['longitude'] != null ? data['longitude'] : "",
                      likes: data != null && data['likes'] != null ? data['likes'] : "",
                      sFeesCurrency: data != null && data['sFeesCurrency'] != null ? data['sFeesCurrency'] : "",
                  )
              );
            }

          }
          setState(() {
            isPostsFetchedS = true;
            dev.log(" LENGTHS ${jobsList.length} -- ${servicesList.length}");
          });
        }
        else{
          setState(() {
            isPostsFetchedS = true;
          });
        }

      });

    });

  }

  Widget _appBar(){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: mq.width * 0.029,),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //IconButton(onPressed: (){}, icon: const Icon(Icons.add_circle_outline, color: Colors.black,)),
            SizedBox(width: mq.width * 0.09,),
            const Text("ZANSH", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: Color.fromARGB(
                255, 253, 253, 253), letterSpacing: 0.4, fontFamily: "Monts"),)
          ],
        ),

        SizedBox(height: mq.height * 0.014,),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.only(left: 16, right: 1),
              width: mq.width * 0.69,
              height: mq.width * 0.129,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 1.4),
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                maxLength: null,
                controller: searchText,
                onTap: (){
                  if(!isSearching){
                    jobsSearchList.clear();
                    servicesSearchList.clear();
                    setState(() {
                      isSearching = true;
                    });
                  }
                },
                onChanged: (val){
                  jobsSearchList.clear();
                  servicesSearchList.clear();

                  if(showNearby){

                    for( JobPost n in jobsList){
                      if( n.jTitle.toLowerCase().contains(val.toLowerCase()) || n.jDesc.toLowerCase().contains(val.toLowerCase()) || n.jCity.toLowerCase().contains(val.toLowerCase()) || n.jState.toLowerCase().contains(val.toLowerCase())){
                        jobsSearchList.add(n);
                        dev.log(n.jTitle);
                      }
                    }
                    for( ServicePost n in servicesList){
                      if( n.sTitle.toLowerCase().contains(val.toLowerCase()) || n.sDesc.toLowerCase().contains(val.toLowerCase()) || n.sCity.toLowerCase().contains(val.toLowerCase()) || n.sState.toLowerCase().contains(val.toLowerCase())){
                        servicesSearchList.add(n);
                        dev.log(n.sTitle);
                      }
                    }

                  }
                  else{

                    for( JobPost n in jobsListX){
                      if( n.jTitle.toLowerCase().contains(val.toLowerCase()) || n.jDesc.toLowerCase().contains(val.toLowerCase()) || n.jCity.toLowerCase().contains(val.toLowerCase()) || n.jState.toLowerCase().contains(val.toLowerCase())){
                        jobsSearchList.add(n);
                        dev.log(n.jTitle);
                      }
                    }
                    for( ServicePost n in servicesListX){
                      if( n.sTitle.toLowerCase().contains(val.toLowerCase()) || n.sDesc.toLowerCase().contains(val.toLowerCase()) || n.sCity.toLowerCase().contains(val.toLowerCase()) || n.sState.toLowerCase().contains(val.toLowerCase())){
                        servicesSearchList.add(n);
                        dev.log(n.sTitle);
                      }
                    }

                  }

                  setState(() {
                    jobsSearchList;
                    servicesSearchList;
                  });

                },
                decoration: InputDecoration(
                  hintText: "Search Job, Service..",
                  hintStyle: const TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w500),
                  suffixIconConstraints: const BoxConstraints(minHeight: 0, minWidth: 0),
                  suffixIcon: IconButton(
                    onPressed: (){
                      if(isSearching){
                        FocusScope.of(context).unfocus();
                        searchText.clear();
                      }
                      setState(() {
                        isSearching = !isSearching;
                      });

                    },
                    icon: Icon(isSearching ? Icons.close : Icons.search_rounded, color: Colors.white,),
                  ),
                  border: InputBorder.none,
                  hintFadeDuration: const Duration(milliseconds: 247),
                ),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.white, letterSpacing: 0.2),
              ),
            ),
            SizedBox(width: mq.width * 0.029,),
            isSearching ?
                const Text("\tSearch..\t", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),)
                :
                GestureDetector(
                  onTap: (){
                    jobsListX = [];
                    servicesListX = [];
                    jobsListX9 = [];
                    servicesListX9 = [];
                    jobsListDS = [];
                    servicesListDS = [];
                    jobsList = [];
                    servicesList = [];

                    showNearby = !showNearby;
                    if(showNearby == true){
                      isPostsFetched = false;
                      isPostsFetchedS = false;
                      Fluttertoast.showToast(
                        backgroundColor: Colors.black,
                          msg: "Showing Nearby Posts Only"
                      );
                      fetchAllPosts();
                    }
                    else{
                      Fluttertoast.showToast(
                          backgroundColor: Colors.black,
                          msg: "Showing All Posts"
                      );
                    }
                    setState(() {

                    });

                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 299),
                    height: mq.width * 0.129,
                    padding: const EdgeInsets.only(left: 4, right: 4, top: 4, bottom: 4),
                    width: mq.width * 0.17,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(mq.width * 0.85),
                      color: showNearby ? Colors.lightBlue.shade900 : Colors.white24,
                    ),
                    child: Icon(Icons.near_me_rounded, color: showNearby ? const Color.fromARGB(255, 219, 222, 222) : const Color.fromARGB(255, 219, 222, 222),)
                  ),
                ),

            // PopupMenuButton(
            //     icon: const Row(
            //       mainAxisSize: MainAxisSize.min,
            //       children: [
            //         Text("Filters", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),),
            //         Icon(Icons.expand_more_rounded,size: 14.9, color: Colors.white70),
            //       ],
            //     ),
            //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
            //     color: const Color.fromARGB(255, 30, 31, 34),
            //     itemBuilder: ((context){
            //       return [
            //
            //         PopupMenuItem(
            //           child: Padding(
            //             padding: const EdgeInsets.symmetric(vertical: 7,),
            //             child: Row(
            //               //mainAxisSize: MainAxisSize.min,
            //               mainAxisAlignment: MainAxisAlignment.center,
            //               children: [
            //                 const Text("Show Nearby Posts Only", style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 12.9,),),
            //                 SizedBox(width: mq.width * 0.029,),
            //                 Switch(
            //                   value: showNearby,
            //                   onChanged: (val){
            //                     jobsListX = [];
            //                     servicesListX = [];
            //                     jobsListX9 = [];
            //                     servicesListX9 = [];
            //                     jobsListDS = [];
            //                     servicesListDS = [];
            //                     jobsList = [];
            //                     servicesList = [];
            //
            //                     if(val == true){
            //                       fetchAllPosts();
            //                     }
            //                     setState(() {
            //                       showNearby = !showNearby;
            //                     });
            //                     Navigator.pop(context);
            //                   },
            //                   inactiveThumbColor: Colors.white,
            //                   inactiveTrackColor: Colors.blue.shade700,
            //                   activeColor: Colors.blue,
            //                   materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            //                 ),
            //
            //               ],
            //             ),
            //           ),
            //         ),
            //
            //       ];}))
          ],
        ),

        SizedBox(height: mq.height * 0.01,),

      ],
    );
  }

  Future<void> refreshScreen()async {
    await Future.delayed(const Duration(milliseconds: 400));
    setState(() {

    });
  }
}

