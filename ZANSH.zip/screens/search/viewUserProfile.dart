import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:zansh/modals/chatUser.dart';
import 'package:zansh/screens/chatUserScreen.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../../modals/newJob.dart';
import '../../modals/newService.dart';
import '../../widgets/jobCard.dart';
import '../../widgets/serviceCard.dart';

class ViewUserProfile extends StatefulWidget {
  final ChatUser user;
  const ViewUserProfile({super.key, required this.user});

  @override
  State<ViewUserProfile> createState() => _ViewUserProfileState();
}

class _ViewUserProfileState extends State<ViewUserProfile> {
  List<JobPost> jobsList = [];
  List<ServicePost> servicesList = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            _appBar(),

            SizedBox(height: mq.width * 0.04,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Container(
                  height: mq.width * 0.258,
                  width: mq.width * 0.258,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white70, width: 1.7),
                    borderRadius: BorderRadius.circular(mq.width * 0.129),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(mq.width * 0.12),
                    child: CachedNetworkImage(
                      height: mq.width * 0.24,
                      width: mq.width * 0.24,
                      fit: BoxFit.cover,
                      imageUrl: widget.user.image.toString() ?? "",
                      placeholder: (context, url) => const CircularProgressIndicator(color: Colors.white70,strokeWidth: 1.2,),
                      errorWidget: (context, url, error) => const CircleAvatar(child:Icon(Icons.account_circle, color: Colors.white70,),),
                    ),
                  ),
                ),

                SizedBox(width: mq.width * 0.04),

                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                        width: mq.width * 0.46,
                        child: Text(widget.user.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),maxLines: 1, overflow: TextOverflow.ellipsis,)),
                    SizedBox(height: mq.height * 0.007,),
                    SizedBox(
                        width: mq.width * 0.46,
                        child: Text(widget.user.email, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white70),maxLines: 1, overflow: TextOverflow.ellipsis,)),
                    // SizedBox(height: mq.height * 0.01,),
                    // Text(widget.user.about, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.black54),),
                  ],
                ),

              ],
            ),

            const Padding(
              padding: EdgeInsets.only(top: 19, bottom: 2),
              child: Divider(
                thickness: 0.2,
              ),
            ),

            Padding(
              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
              child: RichText(text: TextSpan(
                  children: [
                    const TextSpan(
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                        text: 'Bio : '
                    ),
                    TextSpan(
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white, letterSpacing: 0.29),
                      text: widget.user.about,
                    ),
                  ]
              ),
              ),
            ),

            const Padding(
              padding: EdgeInsets.only(top: 2, bottom: 2.9),
              child: Divider(
                thickness: 0.2,
              ),
            ),

            Padding(
                padding: EdgeInsets.symmetric(vertical: mq.height * 0.014),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Posts", style: TextStyle(color: Colors.blue, fontSize: 16, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
                ],
              ),
            ),

            Expanded(
              child: StreamBuilder(
                stream: APIs.getMyJobs(widget.user.email),
                builder: (context, snapshot){
              
                  switch(snapshot.connectionState){
                    case ConnectionState.waiting:
                      return Padding(
                        padding: EdgeInsets.only(top: mq.height * 0.2),
                        child: const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,)),
                      );
                    case ConnectionState.none:
              
                    case ConnectionState.active:
                    case ConnectionState.done:
              
                      var data = snapshot.data?.docs;
                      jobsList = data?.map((e) => JobPost.fromJson(e.data())).toList() ?? [];
              
                      return StreamBuilder(
                          stream: APIs.getMyServices(widget.user.email),
                          builder: (context, snapshot){
              
                            switch(snapshot.connectionState){
                              case ConnectionState.waiting:
                                return Padding(
                                  padding: EdgeInsets.only(top: mq.height * 0.2),
                                  child: const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,)),
                                );
                              case ConnectionState.none:
              
                              case ConnectionState.active:
                              case ConnectionState.done:
              
                                var data = snapshot.data?.docs;
                                servicesList = data?.map((e) => ServicePost.fromJson(e.data())).toList() ?? [];
              
                                if(jobsList.isNotEmpty || servicesList.isNotEmpty){
                                  return ListView.builder(
                                      physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                      itemCount: (jobsList.length + servicesList.length),
                                      //padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                      itemBuilder: (context, index) {
                                  
                                        if(jobsList.length > index){
                                          return Padding(
                                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                              child: JobCard(job: jobsList[index], isNearby: false,)
                                          );
                                        }
                                        else if(jobsList.length <= index){
                                          return Padding(
                                              padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                              child: ServiceCard(service: servicesList[index - jobsList.length], isNearby: false,)
                                          );
                                        }
                                        else{
                                          return null;
                                        }
                                  
                                      }
                                  );
                                }
                                else{
                                  return Padding(
                                    padding: EdgeInsets.only(top: mq.height * 0.2),
                                    child: const Text("No Posts", style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    color: Colors.white70
                                  ),),);
                                }
              
                            }
                          }
                      );
              
                  }
              
                },
              ),
            )

          ],
        ),
      ),
    );
  }


  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(width: mq.width * 0.019,),
        const BackButton(color: Colors.white),
        SizedBox(width: mq.width * 0.04,),
        SizedBox(
          width: mq.width * 0.6,
            child: const Text("View Profile", style: TextStyle(fontSize: 14.9, color: Colors.white, fontWeight: FontWeight.w500, fontFamily: "Monts"),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              textAlign: TextAlign.start,
            )
        ),

        const Spacer(),

        IconButton(
            onPressed: (){
              APIs.addNewUser(widget.user.email).then((value) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ChatUserScreen(user: widget.user)));
              });
            },
            icon: const Icon(Icons.chat, color: Colors.blue,)
        ),

        SizedBox(width: mq.width * 0.04,),
      ],
    );
  }

}
