import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:zansh/modals/chatUser.dart';
import 'dart:developer' as dev;
import '../../main.dart';
import '../../widgets/chatCard.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {

  late TextEditingController searchText = TextEditingController();
  late List<DocumentSnapshot>? usersListDS;
  late List<ChatUser> usersList = [];
  late List<ChatUser> searchList = [];

  bool isSearching = false;
  bool isDataFetched = false;

  @override
  void initState() {
    super.initState();
    fetchAllUsers();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: PopScope(
        onPopInvoked: (bool x){
          if(isSearching){
            setState(() {
              isSearching = !isSearching;
              searchText.text = "";
            });
          }
        },
        canPop: isSearching ? false : true,
        child: Scaffold(
          body:  isDataFetched ?
          Column(
            children: [
              _appBar(),

              isSearching ?
              searchList.isEmpty ?
                  searchText.text.isEmpty?
                  Padding(
                      padding: EdgeInsets.only(top: mq.height * 0.29),
                      child: const Text("Search User's Name/Email..", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                      ))
                  :
              Padding(
                padding: EdgeInsets.only(top: mq.height * 0.29),
                child: const Text("No User Found with this Name/Email  : ]", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Colors.white)),
              )
                  :
              Expanded(
                child: ListView.builder(
                    itemCount: searchList.length,
                    padding: const EdgeInsets.only(top: 7),
                    physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                    itemBuilder: (context, index){
                      return ChatCard(user: searchList[index], isViewingUser: true,);
                    }
                ),
              )
                :
            Padding(
              padding: EdgeInsets.only(top: mq.height * 0.29),
              child: const Text("Search for an Account..", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white),
              )),
            ],
          )
              :
              const Center(
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.2),
              ),
        ),
      ),
    );
  }

  Future<void> fetchAllUsersSnapshots() async {
    final CollectionReference usersRef = FirebaseFirestore.instance.collection('users');
    QuerySnapshot querySnapshot = await usersRef.get();
    usersListDS = querySnapshot.docs;
  }

  Future<void> fetchAllUsers()async {
    fetchAllUsersSnapshots().then((value) async {

      if(usersListDS != null){
        for(DocumentSnapshot a in usersListDS!){
          dev.log(a.toString());

          var data = a.data() as Map<String, dynamic>?;

          usersList.add(
              ChatUser(
                image: data != null && data['image'] != null ? data['image'] : "",
                about: data != null && data['about'] != null ? data['about'] : "",
                name: data != null && data['name'] != null ? data['name'] : "",
                createdAt: data != null && data['created_at'] != null ? data['created_at'] : "",
                id: data != null && data['id'] != null ? data['id'] : "",
                lastActive: data != null && data['last_active'] != null ? data['last_active'] : "",
                isOnline: data != null && data['is_online'] != null ? data['is_online'] : "",
                pushToken: data != null && data['push_token'] != null ? data['push_token'] : "",
                email: data != null && data['email'] != null ? data['email'] : "",
                phoneNumber: data != null && data['phoneNumber'] != null ? data['phoneNumber'] : "",
              )
          );

        }
        setState(() {
          isDataFetched = true;
        });
      }
      else{
        setState(() {
          isDataFetched = true;
        });
      }

    });
  }

  Widget _appBar(){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: mq.width * 0.029,),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //IconButton(onPressed: (){}, icon: const Icon(Icons.add_circle_outline, color: Colors.black,)),
            SizedBox(width: mq.width * 0.09,),
            const Text("ZANSH", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: Color.fromARGB(
                255, 253, 253, 253), letterSpacing: 0.4, fontFamily: "Monts"),)
          ],
        ),

        SizedBox(height: mq.height * 0.02,),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.only(left: 16, right: 1.4),
              width: mq.width * 0.9,
              height: mq.width * 0.129,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 1.4),
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                maxLength: null,
                controller: searchText,
                onTap: (){
                  if(!isSearching){
                    setState(() {
                      isSearching = true;
                    });
                  }
                },
                onChanged: (val){
                  searchList.clear();

                  for( ChatUser n in usersList){
                    // dev.log(n.jTitle);
                    if( n.name.toLowerCase().contains(val.toLowerCase()) || n.email.toLowerCase().contains(val.toLowerCase()) ){
                      searchList.add(n);
                      dev.log(n.name);
                    }
                  }

                  setState(() {
                    searchList;
                  });

                },
                decoration: InputDecoration(
                  hintText: "Search user's name or email..",
                  hintStyle: const TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w500),
                  suffixIconConstraints: const BoxConstraints(minHeight: 0, minWidth: 0),
                  suffixIcon: IconButton(
                    onPressed: (){
                      if(isSearching){
                        FocusScope.of(context).unfocus();
                        searchText.clear();
                        
                        setState(() {
                          isSearching = !isSearching;
                        });
                      }
                    },
                    icon: Icon(isSearching ? Icons.close : Icons.search_rounded, color: Colors.white,),
                  ),
                  border: InputBorder.none,
                  hintFadeDuration: const Duration(milliseconds: 247),
                ),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.white, letterSpacing: 0.2),
              ),
            ),
          ],
        ),

        SizedBox(height: mq.height * 0.02,),

      ],
    );
  }

}
