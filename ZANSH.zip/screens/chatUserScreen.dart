import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:zansh/modals/chatUser.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:zansh/screens/search/viewUserProfile.dart';
import 'package:zansh/showUps/dialogs.dart';
import '../main.dart';
import '../api/apis.dart';
import 'package:zansh/modals/messageModal.dart';
import '../widgets/messageCard.dart';

class ChatUserScreen extends StatefulWidget {
  final ChatUser user;
  bool isBlocked;
  ChatUserScreen({super.key, required this.user, this.isBlocked = false});

  @override
  State<ChatUserScreen> createState() => _ChatUserScreenState();
}

class _ChatUserScreenState extends State<ChatUserScreen> {

  List<Message> _list = [];
  final _textController = TextEditingController();
  bool showEmoji = false;
  bool isImageUploading = false;


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: SafeArea(
        child: PopScope(
          onPopInvoked: (x){
            if(showEmoji == true){
              setState(() {
                showEmoji = !showEmoji;
              });
            }
          },
          canPop: showEmoji == false ? true : false,
          child: Scaffold(
            backgroundColor: Colors.black87,
            //backgroundColor: const Color.fromARGB(255, 220, 240, 246),
            appBar: AppBar(
              automaticallyImplyLeading: false,
              flexibleSpace: _appBar(),
            ),
            body: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Expanded(
                  child: StreamBuilder(
                    stream: APIs.getAllMessages(widget.user),
                  
                    builder: (context, snapshot){
                  
                      switch(snapshot.connectionState){
                  
                        case ConnectionState.waiting:
                        case ConnectionState.none:
                        // return const Center(child: CircularProgressIndicator());
                  
                        case ConnectionState.active:
                        case ConnectionState.done:
                  
                          final data = snapshot.data?.docs;
                  
                          _list = data?.map((e) => Message.fromJson(e.data())).toList() ?? [];
                  
                          if(_list.isNotEmpty){
                            return ListView.builder(
                                reverse: true,
                                itemCount: _list.length,
                                padding: const EdgeInsets.only(top: 7),
                                physics: const BouncingScrollPhysics(),
                                itemBuilder: (context, index){
                                  return MessageCard(message: _list[index]);
                                }
                            );
                  
                          }else{
                            return Center(child: Text("Say Hi!  : ]", style: TextStyle(fontSize: mq.width * .047, fontWeight: FontWeight.w400),),);
                          }
                  
                      }
                    },
                  ),
                ),
                if(isImageUploading)
                  const Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 9, horizontal: 19),
                      child: CircularProgressIndicator(strokeWidth: 2,),),
                  ),

                SizedBox(height: mq.height * 0.01,),
                widget.isBlocked ?
                    const SizedBox(height: 9,)
                    :
                    _chatUser(),

                if(showEmoji)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: SizedBox(
                      height: mq.height * 0.4,
                      child: EmojiPicker(
                        textEditingController: _textController,
                        config: Config(
                          bgColor: Colors.white24,
                          //bgColor: const Color.fromARGB(255, 220, 240, 246),
                          columns: 8,
                          emojiSizeMax: 32 * (Platform.isIOS ? 1.30 : 1.0),
                        ),),
                    ),
                  ),


              ],),
          ),
        ),
      ),
    );
  }

  Widget _appBar(){
    return GestureDetector(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder: (context) => ViewUserProfile(user: widget.user)));
      },
      child: StreamBuilder(
        stream: APIs.getUserInfo(widget.user),

        builder: (context, snapshot){
          final data = snapshot.data?.docs;
          final list = data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];

          return Row(
            children: [
              const SizedBox(width: 4,),
              IconButton(onPressed: (){ Navigator.pop(context); }, icon: const Icon(Icons.arrow_back_rounded,color: Colors.white70,)),

              const SizedBox(width: 9,),
              ClipRRect(
                borderRadius: BorderRadius.circular(mq.width * 0.074),
                child: CachedNetworkImage(
                  height: mq.width * 0.117,
                  width: mq.width * 0.117,
                  fit: BoxFit.cover,
                  imageUrl: list.isNotEmpty && list[0].image.isNotEmpty ? list[0].image.toString() : widget.user.image != "" && widget.user.image != " " && widget.user.image.isNotEmpty ?  widget.user.image.toString() : " ",
                  placeholder: (context, url) => const CircularProgressIndicator(),
                  errorWidget: (context, url, error) => const CircleAvatar(
                    backgroundColor: Colors.white12,
                    child:Icon(Icons.account_circle, color: Colors.white,),),
                ),
              ),

              const SizedBox(width: 11,),
              // Column(
              //   crossAxisAlignment: CrossAxisAlignment.start,
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: [
              //     Text(list.isNotEmpty ? list[0].name : widget.user.name,  style: const TextStyle(fontSize: 14.9, color: Colors.white, fontWeight: FontWeight.w700),textAlign: TextAlign.left),
              //     const SizedBox(height: 1.74,),
              //     Text(list.isNotEmpty ?
              //     list[0].isOnline ? 'Online' :
              //     getLastActiveTime(BuildContext: context, lastActive: list[0].lastActive) : getLastActiveTime(BuildContext: context, lastActive: widget.user.lastActive) , style: const TextStyle(fontSize: 11, color: Colors.white60, fontWeight: FontWeight.w500),)
              //   ],
              // ),
              SizedBox(
                width: mq.width * 0.49,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(list.isNotEmpty ? list[0].name : widget.user.name,  style: const TextStyle(fontSize: 14.9, color: Colors.white, fontWeight: FontWeight.w700),textAlign: TextAlign.left, overflow: TextOverflow.ellipsis,),
                    const SizedBox(height: 1.74,),
                    Text(widget.user.email ,
                      style: const TextStyle(fontSize: 11, color: Colors.white60, fontWeight: FontWeight.w500),
                      textAlign: TextAlign.left, overflow: TextOverflow.ellipsis,
                    ),
                    // Text(list.isNotEmpty ?
                    // list[0].isOnline ? 'Online' :
                    // getLastActiveTime(BuildContext: context, lastActive: list[0].lastActive) : getLastActiveTime(BuildContext: context, lastActive: widget.user.lastActive) , style: const TextStyle(fontSize: 11, color: Colors.white60, fontWeight: FontWeight.w500),
                    // )
                  ],
                ),
              ),

              const Spacer(),

              PopupMenuButton(
                //padding: EdgeInsets.only(right: mq.width * 0.07),
                  icon: const Icon(Icons.more_vert_rounded, color: Colors.white60),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                  color: const Color.fromARGB(255, 43, 45, 48),
                  itemBuilder: ((context){
                    return [

                      PopupMenuItem(
                        child: ListTile(
                          onTap: (){
                            if(widget.isBlocked){
                              unBlockUserDialog();
                            }
                            else{
                              blockUserDialog();
                            }
                          },
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                          leading: Padding(
                            padding: const EdgeInsets.only(left: 9.0),
                            child: Icon(Icons.block, color: widget.isBlocked ? Colors.greenAccent : Colors.blue,),
                          ),
                          title: Text(widget.isBlocked ? "Unblock User" : "Block User", style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),),
                        )
                      ),

                    ];}))


            ],
          );
        },
      ),
    );
  }

  // void loggingOutDialog(){
  //   showDialog(context: context, builder: (_) => AlertDialog(
  //     contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
  //     shape: RoundedRectangleBorder(
  //       borderRadius: BorderRadius.circular(9),
  //     ),
  //     title: const Row(children: [
  //       Icon(Icons.logout, color: Colors.redAccent, size: 27,),
  //       Text('  Logout from AirChat'),
  //     ],),
  //
  //     content: Container(
  //       decoration: BoxDecoration(
  //         borderRadius: BorderRadius.circular(9),
  //       ),
  //       child: const Text(
  //         "Are you sure, you want to Logout!",
  //         style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black54),
  //       ),
  //     ),
  //
  //     actions: [
  //       MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 16, color: Colors.blue),),),
  //
  //       MaterialButton(onPressed: (){
  //         DialoX.showProgressIndicator(context);
  //         APIs.getCurrentUser().then((value) {
  //           APIs.updateActiveStatus(false).then((value) {
  //             signOutWGoogle();
  //           });
  //         });
  //       }, child: const Text('Logout!', style: TextStyle(fontSize: 16, color: Colors.redAccent),),),
  //     ],
  //   ));
  // }

  Widget _chatUser(){
    return Padding(
      padding: EdgeInsets.only(left: mq.width * 0.019, right: mq.width * 0.029, bottom: mq.width * 0.047),
      child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Card(
                color: Colors.white24,
                margin: const EdgeInsets.only(right: 7),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19)),
                child: Padding(
                  padding: const EdgeInsets.only(right: 14.9),
                  child: Row(
                    children: [
                      IconButton(onPressed: (){
                        hideKeyBoard().then((value){
                          Future.delayed(const Duration(milliseconds: 97), (){
                            setState(() {
                              showEmoji = !showEmoji;
                            });
                          });
                        });
                      }, icon: Icon(Icons.emoji_emotions,color: Colors.blue.shade600,)),

                      Expanded(child: ConstrainedBox(
                        constraints: BoxConstraints(
                            maxHeight: mq.height * 0.4
                        ),
                        child: TextField(
                          onTap: (){
                            setState(() {
                              if(showEmoji){
                                showEmoji = false;
                              }
                            });
                          },

                          controller: _textController,
                          keyboardType: TextInputType.multiline,
                          cursorColor: Colors.white60,
                          maxLines: null,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            hintText: "Message..",
                            hintStyle: TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                                fontWeight: FontWeight.w500
                            ),),),
                      ),),

                      // IconButton(onPressed: ()async{
                      //   final ImagePicker picker = ImagePicker();
                      //   final List<XFile> images = await picker.pickMultiImage(imageQuality: 10);
                      //   if(images.isNotEmpty){
                      //
                      //     for (XFile i in images){
                      //       setState(() {
                      //         isImageUploading = true;
                      //       });
                      //       await APIs.sendChatImage(widget.user ,File(i.path)).then((value) {
                      //         setState(() {
                      //           isImageUploading = false;
                      //         });
                      //       });
                      //       log("---- IMAGE PATH ----");
                      //       log(i.path.toString());
                      //     }
                      //
                      //   }
                      // }, icon: const Icon(Icons.image,color: Colors.blue,)),

                      // IconButton(
                      //   onPressed: ()async{
                      //
                      //     final ImagePicker picker = ImagePicker();
                      //     final XFile? photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 10);
                      //     if(photo != null){
                      //       setState(() {
                      //         isImageUploading = true;
                      //       });
                      //       await APIs.sendChatImage(widget.user ,File(photo.path)).then((value) {
                      //         setState(() {
                      //           isImageUploading = false;
                      //         });
                      //       });
                      //       log("---- IMAGE PATH ----");
                      //       log(photo.path.toString());
                      //     }
                      //
                      //   },
                      //  icon: const Icon(Icons.camera_alt,color: Colors.blue,)),
                    ],
                  ),
                ),
              ),
            ),

            MaterialButton(onPressed: (){
              if(_textController.text.isNotEmpty){
                if(_list.isEmpty){
                  APIs.sendFirstMessage(widget.user, _textController.text, Type.text);
                  _textController.clear();
                }
                else{
                  APIs.sendMessage(widget.user, _textController.text, Type.text);
                  _textController.clear();
                }
              }
            },
              minWidth: 0,
              shape: const CircleBorder(),
              padding: const EdgeInsets.only(top: 11.7, bottom: 11.7, left: 11.9, right: 7),
              color: Colors.blue,
              child: const Icon(Icons.send, color: Colors.white,size: 29.7),
            )
          ]
      ),
    );
  }

  Future<void> hideKeyBoard()async{
    FocusScope.of(context).unfocus();
  }

  getLastActiveTime({required BuildContext ,required String lastActive}){

    final int i = int.tryParse(lastActive) ?? -1;

    if(i == -1) return 'Last Seen not Available';

    DateTime time = DateTime.fromMillisecondsSinceEpoch(i);
    DateTime now = DateTime.now();

    String formattedTime = TimeOfDay.fromDateTime(time).format(context);

    if(time.day == now.day &&
        time.month == now.month &&
        time.year == now.year
    ){
      return 'Last Seen Today at $formattedTime';
    }

    int x = now.day;
    int y = time.day;

    if(time.month == now.month &&
        time.year == now.year &&
        x-y == 1){
      return 'Last Seen Yesterday at $formattedTime';
    }

    String month = _getMonth(time);
    return 'Last Seen ${time.day} $month at $formattedTime';

  }

  static String _getMonth(DateTime date){
    switch(date.month){
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return 'NA';
    }

  }

  void blockUserDialog(){
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      backgroundColor: const Color.fromARGB(255, 43, 45, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Icon(Icons.block, color: Colors.blue, size: 24,),
          SizedBox(width: 12,),
          Text('Block User', style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
        ],),

      content: Container(
        margin: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
        ),
        child: Text(
          "Add  '${widget.user.name}'  to Block List!",
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 14, color: Colors.white70),),),

        MaterialButton(onPressed: (){
          Dialogs.showCircularProgress(context, Colors.white);
          APIs.blockUser(widget.user.email).then((value) {
            Navigator.pop(context);
            Navigator.pop(context);
            Navigator.pop(context);
            Navigator.pop(context);
            if(value == false){
              Dialogs.showSnackBar(context, "Can't Block User!", duration: 2000, fSize: 16); // "Can't Blocked!"
            }
            else{
              Dialogs.showSnackBar(context, "User Blocked!");
              // Fluttertoast.showToast(
              //     msg: "User Added to Blocked List",
              //   toastLength: Toast.LENGTH_SHORT,
              //   gravity: ToastGravity.BOTTOM,
              //   backgroundColor: Colors.black87,
              //   textColor: Colors.white,
              //   fontSize: 9
              // );
            }
          });
        }, child: const Text('Block', style: TextStyle(fontSize: 14, color: Colors.blue),),),
      ],
    ));
  }

  void unBlockUserDialog(){
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      backgroundColor: const Color.fromARGB(255, 43, 45, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Icon(Icons.block, color: Colors.greenAccent, size: 24,),
          SizedBox(width: 12,),
          Text('Unblock User', style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
        ],),

      content: Container(
        margin: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
        ),
        child: Text(
          "Remove  '${widget.user.name}'  from Block List!",
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 14, color: Colors.white70),),),

        MaterialButton(onPressed: (){
          Dialogs.showCircularProgress(context, Colors.white);
          APIs.unBlockUser(widget.user.email).then((value) {
            Navigator.pop(context);
            Navigator.pop(context);
            Navigator.pop(context);
            Navigator.pop(context);
            if(value == false){
              Dialogs.showSnackBar(context, "Can't Unblock User!", duration: 2000, fSize: 16); // "Can't Blocked!"
            }
            else{
              Dialogs.showSnackBar(context, "User Unblocked!", duration: 1400);
            }
          });
        }, child: const Text('Unblock', style: TextStyle(fontSize: 14, color: Colors.blue),),),
      ],
    ));
  }

}
