import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../api/apis.dart';
import 'homeScreenX.dart';

const MethodChannel navigationChannel = MethodChannel('navigationChannel');

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  final PageController _pageController = PageController(initialPage: 0);
  int _currentPage = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }


  @override
  void initState(){
    super.initState();
    APIs.getCurrentUser();
    APIs.updateActiveStatus(true);

    SystemChannels.lifecycle.setMessageHandler((message) async {
      log('MESSAGE : $message');

      if(message.toString().contains('resumed')){
        await APIs.updateActiveStatus(true);
      }
      if(message.toString().contains('paused') || message.toString().contains('inactive') || message.toString().contains('detached')){
        await APIs.updateActiveStatus(false);
      }

      return Future.value(message);
    });

  }

  @override
  Widget build(BuildContext context) {
    return PageView(
      controller: _pageController,
      onPageChanged: (int page) {
          setState(() {
            _currentPage = page;
          });
      },
      children: const <Widget>[
        HomeScreenX(),
        //ChatScreen(),
      ],
    );
  }
}




