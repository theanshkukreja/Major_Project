import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rive/rive.dart';
import 'package:zansh/screens/profileScreen.dart';
import 'package:zansh/screens/search/searchScreen.dart';
import '../main.dart';
import '../showUps/riveAnimations.dart';
import 'addNewPostScreen.dart';
import 'chatsScreen.dart';
import 'home/homeOne.dart';

const MethodChannel navigationChannel = MethodChannel('navigationChannel');

class HomeScreenX extends StatefulWidget {
  const HomeScreenX({super.key});

  @override
  State<HomeScreenX> createState() => _HomeScreenXState();
}

class _HomeScreenXState extends State<HomeScreenX> {

  int aDuration = 200;
  var currentScreenIndex = 0;
  bool isAnimatedAddIconActive = false;
  RiveAsset selectedBottomNav = bottomNavs.first;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      bottomNavigationBar: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.black,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(color: Colors.white24,height: 0.29, margin: const EdgeInsets.only(bottom: 4),),
              Padding(
                padding: EdgeInsets.only(top: 7, right: 12, left: 12, bottom: mq.width * 0.047),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GestureDetector(
                      onTap: (){
                        bottomNavFun(0);
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          AnimatedContainer(
                            duration: Duration(milliseconds: aDuration),
                            margin: const EdgeInsets.only(bottom: 2),
                            height: 4, width: bottomNavs[0] == selectedBottomNav ? 20 : 0,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade400,
                              borderRadius: const BorderRadius.all(Radius.circular(14)),
                            ),
                          ),

                          SizedBox(
                            height: 34,
                            width: 34,
                            child: Opacity(
                              opacity: bottomNavs[0] == selectedBottomNav ? 1 : 0.5,
                              child:
                              RiveAnimation.asset(
                                bottomNavs.first.src,
                                fit: BoxFit.contain,
                                artboard: bottomNavs[0].artboard,
                                onInit: (artboard){
                                  StateMachineController controller =
                                  RiveUtils.getRiveController(artboard, stateMachineName: bottomNavs[0].stateMachineName);
                                  bottomNavs[0].input = controller.findSMI("active") as SMIBool;
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    GestureDetector(
                      onTap: (){
                        bottomNavFun(1);
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          AnimatedContainer(
                            duration: Duration(milliseconds: aDuration),
                            margin: const EdgeInsets.only(bottom: 2),
                            height: 4, width: bottomNavs[1] == selectedBottomNav ? 20 : 0,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade400,
                              borderRadius: const BorderRadius.all(Radius.circular(14)),
                            ),
                          ),

                          SizedBox(
                            height: 34,
                            width: 34,
                            child: Opacity(
                              opacity: bottomNavs[1] == selectedBottomNav ? 1 : 0.5,
                              child:
                              RiveAnimation.asset(
                                bottomNavs.first.src,
                                fit: BoxFit.contain,
                                artboard: bottomNavs[1].artboard,
                                onInit: (artboard){
                                  StateMachineController controller =
                                  RiveUtils.getRiveController(artboard, stateMachineName: bottomNavs[1].stateMachineName);
                                  bottomNavs[1].input = controller.findSMI("active") as SMIBool;
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    GestureDetector(
                      onTap: (){
                        bottomNavFun(2);
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          AnimatedContainer(
                            duration: Duration(milliseconds: aDuration),
                            margin: const EdgeInsets.only(bottom: 2),
                            height: 4, width: bottomNavs[2] == selectedBottomNav ? 20 : 0,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade400,
                              borderRadius: const BorderRadius.all(Radius.circular(14)),
                            ),
                          ),

                          SizedBox(
                            height: 34,
                            width: 34,
                            child: Opacity(
                              opacity: bottomNavs[2] == selectedBottomNav ? 1 : 0.5,
                              child: AnimatedContainer(
                                margin: EdgeInsets.only(left: isAnimatedAddIconActive ? 0 : 1.4, right: isAnimatedAddIconActive ? 0 : 1.4, bottom: isAnimatedAddIconActive ? 0 : 1.4, top: 2),
                                duration: const Duration(milliseconds: 499),
                                decoration: BoxDecoration(
                                  color: Colors.transparent,
                                  borderRadius: const BorderRadius.all(Radius.circular(70)),
                                  border: Border.all(color: Colors.white, width: 1.4),
                                ),
                                child: const Center(child: Icon(Icons.add, color: Colors.white, size: 19)),

                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    GestureDetector(
                      onTap: (){
                        bottomNavFun(3);
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          AnimatedContainer(
                            duration: Duration(milliseconds: aDuration),
                            margin: const EdgeInsets.only(bottom: 2),
                            height: 4, width: bottomNavs[3] == selectedBottomNav ? 20 : 0,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade400,
                              borderRadius: const BorderRadius.all(Radius.circular(14)),
                            ),
                          ),

                          SizedBox(
                            height: 34,
                            width: 34,
                            child: Opacity(
                              opacity: bottomNavs[3] == selectedBottomNav ? 1 : 0.5,
                              child:
                              RiveAnimation.asset(
                                bottomNavs.first.src,
                                fit: BoxFit.contain,
                                artboard: bottomNavs[3].artboard,
                                onInit: (artboard){
                                  StateMachineController controller =
                                  RiveUtils.getRiveController(artboard, stateMachineName: bottomNavs[3].stateMachineName);
                                  bottomNavs[3].input = controller.findSMI("active") as SMIBool;
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    GestureDetector(
                      onTap: (){
                        bottomNavFun(4);
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          AnimatedContainer(
                            duration: Duration(milliseconds: aDuration),
                            margin: const EdgeInsets.only(bottom: 2),
                            height: 4, width: bottomNavs[4] == selectedBottomNav ? 20 : 0,
                            decoration: BoxDecoration(
                              color: Colors.blue.shade400,
                              borderRadius: const BorderRadius.all(Radius.circular(14)),
                            ),
                          ),

                          SizedBox(
                            height: 34,
                            width: 34,
                            child: Opacity(
                              opacity: bottomNavs[4] == selectedBottomNav ? 1 : 0.5,
                              child:
                              RiveAnimation.asset(
                                bottomNavs.first.src,
                                fit: BoxFit.contain,
                                artboard: bottomNavs[4].artboard,
                                onInit: (artboard){
                                  StateMachineController controller =
                                  RiveUtils.getRiveController(artboard, stateMachineName: bottomNavs[4].stateMachineName);
                                  bottomNavs[4].input = controller.findSMI("active") as SMIBool;
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),


      body:
      currentScreenIndex == 0 ?
      const HomeOne()
          :
      currentScreenIndex == 1 ?
      const ChatScreen()
          :
      currentScreenIndex == 2 ?
      const AddNewPostScreen()
          :
      currentScreenIndex == 3 ?
      const SearchScreen()
          :
      ProfileScreen(),
    );

  }

  void bottomNavFun(int x){
    if(x != 2){
      // if(x == 1){
      //   Navigator.push(
      //     context,
      //     PageRouteBuilder(
      //       transitionDuration: const Duration(milliseconds: 200),
      //       pageBuilder: (_, __, ___) => const ChatScreen(),
      //       transitionsBuilder: (_, animation, __, child) {
      //         return FadeTransition(
      //           opacity: animation,
      //           child: child,
      //         );
      //       },
      //     ),
      //   );
      // }
      //else{
        setState(() {
          selectedBottomNav = bottomNavs[x];
          currentScreenIndex = x;
        });


        bottomNavs[x].input!.change(true);
        Future.delayed(const Duration(milliseconds: 1000), () {
          bottomNavs[x].input!.change(false);
        });
      //}

    }

    else if(x == 2){
      setState(() {
        currentScreenIndex = 2;
        selectedBottomNav = bottomNavs[2];
        isAnimatedAddIconActive = true;
      });

      Future.delayed(const Duration(milliseconds: 1000), () {
        setState(() {
          isAnimatedAddIconActive = false;
        });
      });
    }

  }

}

class RiveAsset{
  final String artboard, stateMachineName, title, src;
  late SMIBool? input;

  RiveAsset(this.src, {required this.stateMachineName, required this.title, this.input, required this.artboard});

  set setInput(SMIBool status){
    input  = status;
  }

}

List<RiveAsset> bottomNavs = [
  RiveAsset("assets/rive/1298-2487-animated-icon-set-1-color.riv", stateMachineName: "HOME_interactivity", title: "Home", artboard: "HOME"),
  RiveAsset("assets/rive/1298-2487-animated-icon-set-1-color.riv", stateMachineName: "CHAT_Interactivity", title: "CHAT", artboard: "CHAT"),
  RiveAsset("assets/rive/1298-2487-animated-icon-set-1-color.riv", stateMachineName: "SEARCH_Interactivity", title: "Search", artboard: "SEARCH"),
  RiveAsset("assets/rive/1298-2487-animated-icon-set-1-color.riv", stateMachineName: "SEARCH_Interactivity", title: "Search", artboard: "SEARCH"),
  RiveAsset("assets/rive/1298-2487-animated-icon-set-1-color.riv", stateMachineName: "USER_Interactivity", title: "User", artboard: "USER"),

];


