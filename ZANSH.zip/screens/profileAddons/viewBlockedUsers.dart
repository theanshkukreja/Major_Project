import 'package:flutter/material.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../../modals/chatUser.dart';
import '../../widgets/chatCard.dart';

class ViewBlockedUsers extends StatefulWidget {
  const ViewBlockedUsers({super.key});

  @override
  State<ViewBlockedUsers> createState() => _ViewBlockedUsersState();
}

class _ViewBlockedUsersState extends State<ViewBlockedUsers> {

  late List<ChatUser> blockedUsersList = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            _appBar(),

            StreamBuilder(
                      stream: APIs.getBlockedUsers(),
                      builder: (context, snapshot){

            return StreamBuilder(
              stream: APIs.getAllUsers(
                snapshot.data?.docs.map((e) => e.id).toList() ?? [''],
              ),

              builder: (context, snapshot){


                switch(snapshot.connectionState){

                  case ConnectionState.waiting:
                    return Center(child: Padding(
                      padding: EdgeInsets.only(top: mq.height * 0.4),
                      child: const CircularProgressIndicator(),
                    ));
                  case ConnectionState.none:

                  case ConnectionState.active:
                  case ConnectionState.done:

                    var data = snapshot.data?.docs;
                    blockedUsersList = data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];

                    if(blockedUsersList.isNotEmpty){

                      return Expanded(
                        child: ListView.builder(
                            itemCount: blockedUsersList.length,
                            padding: const EdgeInsets.only(top: 7),
                            physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                            itemBuilder: (context, index){
                              return ChatCard(user: blockedUsersList[index], isBlocked: true,);
                            }
                        ),
                      );

                    }else{
                      return Column(
                        children: [
                          SizedBox(height: mq.height * 0.4,),
                           Text("No Blocked Users : ]", style: TextStyle(fontSize: mq.width * .04, fontWeight: FontWeight.w400),),
                        ],
                      );
                    }

                }
              },
            );

                      },
                    )
          ],
        ),
      ),
    );
  }

  Widget _appBar(){
    return Padding(
      padding: EdgeInsets.symmetric(vertical: mq.width * 0.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(width: mq.width * 0.024,),

          IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: const Icon(Icons.arrow_back_ios_new_sharp, color: Colors.white, size: 21,)),

          SizedBox(width: mq.width * 0.04,),

          const Text("Blocked Users", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, letterSpacing: 0.2, fontFamily: "Monts"),),

          const Spacer(),
        ],
      ),
    );
  }

}
