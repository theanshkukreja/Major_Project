import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../api/apis.dart';
import '../../main.dart';
import 'package:image_picker/image_picker.dart';
import '../../modals/chatUser.dart';
import '../../showUps/dialogs.dart';

class UpdateProfile extends StatefulWidget {
  final ChatUser user = APIs.me;
  UpdateProfile({super.key});

  @override
  State<UpdateProfile> createState() => _UpdateProfileState();
}

class _UpdateProfileState extends State<UpdateProfile> {

  final _formKey = GlobalKey<FormState>();
  String? _image;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          backgroundColor: Colors.black,
          body: SingleChildScrollView(
            child: Column(
              children: [
                _appBar(),
                SizedBox(width: mq.width, height: mq.height * 0.04,),

            FutureBuilder<String>(
                future: APIs.getCurrentUser(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator(strokeWidth: 2,));
                  }
                  else if (snapshot.hasError) {
                    return const Center(child: Text('Something Went Wrong!',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),));
                  }
                  else if (snapshot.connectionState == ConnectionState.done) {
                    return Form(
                      key: _formKey,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [

                            _image != null ?
                            GestureDetector(
                              onTap: (){
                                _showImageBottomSheet();
                              },
                              child: Container(
                                height: mq.width * 0.49,
                                width: mq.width * 0.49,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(mq.width * 0.245),
                                    border: Border.all(color: Colors.white70, width: 1)
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(mq.width * 0.22),
                                  child: Image.file(
                                    File(_image!),
                                    height: mq.width * 0.44,
                                    width: mq.width * 0.44,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ) :

                            GestureDetector(
                              onTap: (){
                                _showImageBottomSheet();
                              },
                              child: Container(
                                height: mq.width * 0.44,
                                width: mq.width * 0.44,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(mq.width * 0.22),
                                    border: Border.all(color: Colors.white70, width: 1)
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(mq.width * 0.22),
                                  child: CachedNetworkImage(
                                    height: mq.width * 0.44,
                                    width: mq.width * 0.44,
                                    fit: BoxFit.cover,
                                    imageUrl: widget.user.image,
                                    placeholder: (context, url) => const CircularProgressIndicator(),
                                    errorWidget: (context, url, error) => const CircleAvatar(child:Icon(Icons.account_circle, color: Colors.white70, size: 40,),),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(height: mq.height * 0.04),
                            Container(
                                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 7),
                                width: mq.width * 0.8,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: Colors.white24,
                                ),
                                child: SelectableText(widget.user.email, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Colors.white70), textAlign: TextAlign.center,maxLines: 1,)
                            ),

                            SizedBox(height: mq.height * 0.047),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: mq.height * 0.0035),
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                decoration: BoxDecoration(
                                  color: const Color.fromARGB(255, 30, 30, 30),
                                  border: Border.all(color: Colors.white70, width: 1),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: TextFormField(
                                  key: const ValueKey("Name"),
                                  decoration: InputDecoration(
                                    hintText: "Name..",
                                    hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                                    border: InputBorder.none,
                                    errorStyle: TextStyle(
                                        color: Colors.red.shade400, // Change error text color here
                                        fontStyle: FontStyle.italic,
                                        letterSpacing: 0.9,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 11
                                    ),
                                  ),
                                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: 0.4, color: Color.fromARGB(255, 213, 213, 218)),
                                  initialValue: widget.user.name,
                                  onSaved: (val)=> APIs.me.name = val ?? '',
                                  validator: (val)=> val != null && val.isNotEmpty ? null : "Required Field",
                                  maxLength: 29,
                                ),
                              ),
                            ),

                            SizedBox(height: mq.height * 0.017),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: mq.height * 0.0035),
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                decoration: BoxDecoration(
                                  color: const Color.fromARGB(255, 30, 30, 30),
                                  border: Border.all(color: Colors.white70, width: 1),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: TextFormField(
                                  key: const ValueKey("Bio"),
                                  decoration: InputDecoration(
                                    hintText: "Bio..",
                                    hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                                    border: InputBorder.none,
                                    errorStyle: TextStyle(
                                        color: Colors.red.shade400, // Change error text color here
                                        fontStyle: FontStyle.italic,
                                        letterSpacing: 0.9,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 11
                                    ),
                                  ),
                                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: 0.4, color: Color.fromARGB(255, 213, 213, 218)),
                                  initialValue: widget.user.about,
                                  onSaved: (value)=> APIs.me.about = value ?? '',
                                  validator: (value)=> value != null && value.isNotEmpty ? null : "Required Field",
                                  maxLength: 49,
                                ),
                              ),
                            ),

                            SizedBox(height: mq.height * 0.017),



                          ],
                        ),
                      ),
                    );
                  }
                  else{
                    return const Center(child: CircularProgressIndicator(strokeWidth: 2,));
                  }
                }
            ),


              ],
            ),
          )

        ),
      ),
    );
  }

  void _showImageBottomSheet(){
    showModalBottomSheet(context: context, builder: (_){
      return ListView(
        shrinkWrap: true,
        padding: EdgeInsets.only(top: mq.height * 0.027, bottom: mq.height * 0.097),
        children: [

          const Text("Upload Profile Picture", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 17, color: Color.fromARGB(255, 213, 213, 218)), textAlign: TextAlign.center,),

          const SizedBox(height: 40,),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: ()async{
                  final ImagePicker picker = ImagePicker();
                  final XFile? image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 19);

                  if(image != null){
                    setState(() {
                      _image = image.path;
                    });
                    Navigator.pop(context);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: const CircleBorder(),
                  fixedSize: Size(mq.width * 0.27, mq.width * 0.27),
                ),
                child: Image.asset('assets/images/gallery.png'),
              ),

              const SizedBox(width: 47),
              ElevatedButton(
                onPressed: ()async{

                  final ImagePicker picker = ImagePicker();
                  final XFile? photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 19);
                  if(photo != null){
                    setState(() {
                      _image = photo.path;
                    });
                    Navigator.pop(context);
                  }

                },
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: const CircleBorder(),
                    fixedSize: Size(mq.width * 0.27, mq.width * 0.27)
                ),
                child: Image.asset('assets/images/camera.png'),
              ),
            ],
          ),

          const Center(
            child: Padding(
              padding: EdgeInsets.only(top: 40.0),
              child: Text("( Note - Images with 1:1 aspect ratio fits best :) )", style: TextStyle(fontSize: 11),),
            ),
          )

        ],
      );
    },
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(29), topLeft: Radius.circular(29)))
    );
  }
  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: const Icon(Icons.arrow_back_ios_new_sharp, color: Colors.white, size: 21,)
        ),
        //const Icon(Icons.edit, color: Colors.white70, size: 21,),
        SizedBox(width: mq.width * 0.04,),
        const Text("Update Profile", style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500, fontFamily: "Monts"),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
          textAlign: TextAlign.start,
        ),

        const Spacer(),

        ElevatedButton(
          onPressed: (){
            if( _formKey.currentState!.validate() ){
              _formKey.currentState!.save();
              Dialogs.showCircularProgress(context, Colors.white70);
              if(_image != null){
                APIs.updateProfilePic(File(_image!)).then((value) {
                  APIs.updateUserDetails().then((value){
                    Navigator.pop(context);
                    Navigator.pop(context);
                    Dialogs.showSnackBar(context, "Profile Updated!");
                  });
                });
              }
              else{
                APIs.updateUserDetails().then((value){
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Dialogs.showSnackBar(context, "Profile Updated!");
                });
              }
            }
          },
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: mq.width * 0.06),
            backgroundColor: Colors.white,
            shape: const StadiumBorder(),
            minimumSize: Size(mq.width * 0.12, mq.width * 0.09),),
          child: const Text("Update", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black, fontFamily: "Monts"),),
        ),

        SizedBox(width: mq.width * 0.04,)

      ],
    );
  }
}