import 'package:flutter/material.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../../modals/newJob.dart';
import '../../modals/newService.dart';
import '../../widgets/jobCard.dart';
import '../../widgets/serviceCard.dart';

class ViewMyPosts extends StatefulWidget {
  final String email;
  final bool isMe;
  const ViewMyPosts({super.key, required this.email, this.isMe = false});

  @override
  State<ViewMyPosts> createState() => _ViewMyPostsState();
}

class _ViewMyPostsState extends State<ViewMyPosts> {

  List<JobPost> jobsList = [];
  List<ServicePost> servicesList = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            _appBar(),

            StreamBuilder(
              stream: APIs.getMyJobs(widget.email),
              builder: (context, snapshot){

                switch(snapshot.connectionState){
                  case ConnectionState.waiting:
                    return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                  case ConnectionState.none:

                  case ConnectionState.active:
                  case ConnectionState.done:

                    var data = snapshot.data?.docs;
                    jobsList = data?.map((e) => JobPost.fromJson(e.data())).toList() ?? [];

                    return StreamBuilder(
                        stream: APIs.getMyServices(widget.email),
                        builder: (context, snapshot){

                          switch(snapshot.connectionState){
                            case ConnectionState.waiting:
                              return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                            case ConnectionState.none:

                            case ConnectionState.active:
                            case ConnectionState.done:

                              var data = snapshot.data?.docs;
                              servicesList = data?.map((e) => ServicePost.fromJson(e.data())).toList() ?? [];

                              if(jobsList.isNotEmpty || servicesList.isNotEmpty){
                                return Expanded(
                                  child: ListView(
                                    physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                    children: [
                                      SizedBox(height: mq.width * 0.02),

                                      ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: (jobsList.length + servicesList.length),
                                          //padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                          physics: const BouncingScrollPhysics(
                                              decelerationRate: ScrollDecelerationRate.fast
                                          ),
                                          itemBuilder: (context, index) {

                                            if(jobsList.length > index){
                                              return Padding(
                                                  padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                  child: JobCard(job: jobsList[index], isNearby: false, isMe: true,)
                                              );
                                            }
                                            else if(jobsList.length <= index){
                                              return Padding(
                                                  padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                  child: ServiceCard(service: servicesList[index - jobsList.length], isNearby: false, isMe: true,)
                                              );
                                            }
                                            else{
                                              return null;
                                            }

                                          }
                                      ),

                                    ],
                                  ),
                                );
                              }
                              else{
                                return Column(
                                  children: [
                                    SizedBox(height: mq.height * 0.4,),
                                    Text("No Posts Yet!", style: TextStyle(fontSize: mq.width * 0.04, fontWeight: FontWeight.w400),),
                                  ],
                                );
                              }

                          }
                        }
                    );

                }

              },
            ),
          ],
        ),
      ),
    );
  }

  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(width: mq.width * 0.024,),
        IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: const Icon(Icons.arrow_back_ios_new_sharp, color: Colors.white, size: 21,)
        ),
        //const Icon(Icons.edit, color: Colors.white70, size: 21,),
        SizedBox(width: mq.width * 0.04,),
        const Text("My Posts", style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500, fontFamily: "Monts"),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
          textAlign: TextAlign.start,
        ),

      ],
    );
  }

}
