import 'package:flutter/material.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../../modals/newJob.dart';
import '../../modals/newService.dart';
import '../../widgets/jobCard.dart';
import '../../widgets/serviceCard.dart';

class ViewSavedPosts extends StatefulWidget {
  const ViewSavedPosts({super.key});

  @override
  State<ViewSavedPosts> createState() => _ViewSavedPostsState();
}

class _ViewSavedPostsState extends State<ViewSavedPosts> {

  List<JobPost> jobsList = [];
  List<ServicePost> servicesList = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            _appBar(),
            
            StreamBuilder(
            stream: APIs.getSavedPosts(),
            builder: (context, snapshot){

              switch(snapshot.connectionState){
                case ConnectionState.waiting:
                  return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                case ConnectionState.none:

                case ConnectionState.active:
                case ConnectionState.done:

                List<String> savedPosts = snapshot.data?.docs.map((e) => e.id).toList() ?? [''];

                if(savedPosts.isNotEmpty && savedPosts != ['']){
                  return StreamBuilder(
                    stream: APIs.getSavedJobs(savedPosts),
                    builder: (context, snapshot){

                      switch(snapshot.connectionState){
                        case ConnectionState.waiting:
                          return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                        case ConnectionState.none:

                        case ConnectionState.active:
                        case ConnectionState.done:

                          var data = snapshot.data?.docs;
                          jobsList = data?.map((e) => JobPost.fromJson(e.data())).toList() ?? [];

                          return StreamBuilder(
                              stream: APIs.getSavedServices(savedPosts),
                              builder: (context, snapshot){

                                switch(snapshot.connectionState){
                                  case ConnectionState.waiting:
                                    return const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 1.7,));
                                  case ConnectionState.none:

                                  case ConnectionState.active:
                                  case ConnectionState.done:

                                    var data = snapshot.data?.docs;
                                    servicesList = data?.map((e) => ServicePost.fromJson(e.data())).toList() ?? [];

                                    return Expanded(
                                      child: ListView(
                                        physics: const BouncingScrollPhysics(decelerationRate: ScrollDecelerationRate.fast),
                                        children: [
                                          SizedBox(height: mq.width * 0.02),
                                      
                                          ListView.builder(
                                              shrinkWrap: true,
                                              itemCount: (jobsList.length + servicesList.length),
                                              //padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                              physics: const BouncingScrollPhysics(
                                                  decelerationRate: ScrollDecelerationRate.fast
                                              ),
                                              itemBuilder: (context, index) {
                                      
                                                if(jobsList.length > index){
                                                  return Padding(
                                                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                      child: JobCard(job: jobsList[index], isNearby: false)
                                                  );
                                                }
                                                else if(jobsList.length <= index){
                                                  return Padding(
                                                      padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                                                      child: ServiceCard(service: servicesList[index - jobsList.length], isNearby: false)
                                                  );
                                                }
                                                else{
                                                  return null;
                                                }
                                      
                                              }
                                          ),
                                      
                                        ],
                                      ),
                                    );

                                }
                              }
                          );

                      }

                    },
                  );
                }
                else{
                  return Column(
                    children: [
                      SizedBox(
                        height: mq.height * 0.4,
                      ),
                      const Text("No Saved Posts!", style: TextStyle(fontSize: 14),),
                    ],
                  );
                }


               }
              },
            ),
          ],
        ),
      ),
    );
  }

  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(width: mq.width * 0.024,),
        IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: const Icon(Icons.arrow_back_ios_new_sharp, color: Colors.white, size: 21,)
        ),
        //const Icon(Icons.edit, color: Colors.white70, size: 21,),
        SizedBox(width: mq.width * 0.04,),
        const Text("Saved Posts", style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w500, fontFamily: "Monts"),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
          textAlign: TextAlign.start,
        ),

      ],
    );
  }

}
