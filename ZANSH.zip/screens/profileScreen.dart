import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:zansh/modals/chatUser.dart';
import 'package:zansh/screens/profileAddons/updateProfile.dart';
import 'package:zansh/screens/profileAddons/viewMyPosts.dart';
import 'package:zansh/screens/profileAddons/viewSavedPosts.dart';
import 'package:zansh/screens/profileAddons/viewBlockedUsers.dart';
import '../../api/apis.dart';
import '../../main.dart';
import '../showUps/developerBottomSheet.dart';
import '../showUps/dialogs.dart';

class ProfileScreen extends StatefulWidget {
  late ChatUser user = APIs.me;
  ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor:  Colors.black, //APIs.me.darkTheme ? Colors.black : Colors.white,
        body: FutureBuilder<String>(
          future: APIs.getCurrentUser(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white,));
            }
            else if (snapshot.hasError) {
                return const Center(child: Text('Something Went Wrong!',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),));
            }
            else if (snapshot.connectionState == ConnectionState.done) {
              widget.user = APIs.me;
              return Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _appBar(),

                  InkWell(
                    onTap: (){
                      Navigator.push(
                        context,
                        PageRouteBuilder(
                          transitionDuration: const Duration(milliseconds: 200),
                          pageBuilder: (_, __, ___) => UpdateProfile(),
                          transitionsBuilder: (_, animation, __, child) {
                            return FadeTransition(
                              opacity: animation,
                              child: child,
                            );
                          },
                        ),
                      );
                    },
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    splashColor: Colors.black,
                    child: Padding(
                      padding: EdgeInsets.only( top: mq.width * 0.04),

                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [

                          Container(
                            height: mq.width * 0.258,
                            width: mq.width * 0.258,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.white70, width: 1.7), //APIs.me.darkTheme ? Colors.white70 : Colors.black87
                              borderRadius: BorderRadius.circular(mq.width * 0.129),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(mq.width * 0.12),
                              child: CachedNetworkImage(
                                height: mq.width * 0.24,
                                width: mq.width * 0.24,
                                fit: BoxFit.cover,
                                imageUrl: widget.user.image,
                                placeholder: (context, url) => const CircularProgressIndicator(color: Colors.white70, strokeWidth: 1.2,), //APIs.me.darkTheme ? Colors.white70 : Colors.black
                                errorWidget: (context, url, error) => const CircleAvatar(child:Icon(Icons.account_circle, color: Colors.white70),), //APIs.me.darkTheme ? Colors.white70 : Colors.black
                              ),
                            ),
                          ),

                          SizedBox(width: mq.width * 0.04),

                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                  width: mq.width * 0.46,
                                  child: Text(widget.user.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),maxLines: 1, overflow: TextOverflow.ellipsis,)), //APIs.me.darkTheme ? Colors.white : Colors.black
                              SizedBox(height: mq.height * 0.007,),
                              SizedBox(
                                  width: mq.width * 0.46,
                                  child: Text(widget.user.email, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.white70),maxLines: 1, overflow: TextOverflow.ellipsis,)),  //APIs.me.darkTheme ? Colors.white70 : Colors.black54
                              // SizedBox(height: mq.height * 0.01,),
                              // Text(widget.user.about, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Colors.black54),),
                            ],
                          ),

                        ],
                      ),
                    ),
                  ),

                  const Padding(
                    padding: EdgeInsets.only(top: 19, bottom: 2),
                    child: Divider(
                      thickness: 0.2,
                      color: Colors.white, //APIs.me.darkTheme ? Colors.white : Colors.black,
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    child: RichText(text: TextSpan(
                        children: [
                          TextSpan(
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: APIs.me.darkTheme ? Colors.white : Colors.black),
                              text: 'Bio : '
                          ),
                          TextSpan(
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: APIs.me.darkTheme ? Colors.white : Colors.black, letterSpacing: 0.29),
                            text: widget.user.about,
                          ),
                        ]
                    ),
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.only(top: 2, bottom: 2.9),
                    child: Divider(
                      thickness: 0.2,
                      color: APIs.me.darkTheme ? Colors.white : Colors.black,
                    ),
                  ),

                  ListView(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    shrinkWrap: true,
                    children: [
                      Card(
                        color: APIs.me.darkTheme ? Colors.white12 : Colors.lightBlue,
                        child: ListTile(
                          onTap: (){
                            Navigator.push(
                              context,
                              PageRouteBuilder(
                                transitionDuration: const Duration(milliseconds: 200),
                                pageBuilder: (_, __, ___) => UpdateProfile(),
                                transitionsBuilder: (_, animation, __, child) {
                                  return FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  );
                                },
                              ),
                            );
                          },
                          leading: Icon(Icons.person, color: APIs.me.darkTheme ? Colors.blue : Colors.white,),
                          title: const Text("Update Profile", style: TextStyle(fontWeight: FontWeight.w400,color: Colors.white, fontSize: 14),),
                        ),
                      ),

                      Card(
                        color: APIs.me.darkTheme ? Colors.white12 : Colors.lightBlue,
                        child: ListTile(
                          onTap: (){
                            Navigator.push(
                              context,
                              PageRouteBuilder(
                                transitionDuration: const Duration(milliseconds: 200),
                                pageBuilder: (_, __, ___) => ViewMyPosts(email: widget.user.email, isMe: true,),
                                transitionsBuilder: (_, animation, __, child) {
                                  return FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  );
                                },
                              ),
                            );
                          },
                          leading: Icon(Icons.my_library_books, color: APIs.me.darkTheme ? Colors.blue : Colors.white,),
                          title: const Text("My Posts", style: TextStyle(fontWeight: FontWeight.w400,color: Colors.white, fontSize: 14),),
                        ),
                      ),

                      Card(
                        color: APIs.me.darkTheme ? Colors.white12 : Colors.lightBlue,
                        child: ListTile(
                          onTap: (){
                            Navigator.push(
                              context,
                              PageRouteBuilder(
                                transitionDuration: const Duration(milliseconds: 200),
                                pageBuilder: (_, __, ___) => const ViewSavedPosts(),
                                transitionsBuilder: (_, animation, __, child) {
                                  return FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  );
                                },
                              ),
                            );
                          },
                          leading: Icon(Icons.bookmark_outlined, color: APIs.me.darkTheme ? Colors.blue : Colors.white),
                          title: const Text("Saved Posts", style: TextStyle(fontWeight: FontWeight.w400,color: Colors.white, fontSize: 14),),
                        ),
                      ),

                      Card(
                        color: APIs.me.darkTheme ? Colors.white12 : Colors.lightBlue,
                        child: ListTile(
                          onTap: (){
                            Navigator.push(
                              context,
                              PageRouteBuilder(
                                transitionDuration: const Duration(milliseconds: 200),
                                pageBuilder: (_, __, ___) => const ViewBlockedUsers(),
                                transitionsBuilder: (_, animation, __, child) {
                                  return FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  );
                                },
                              ),
                            );
                          },
                          leading: Icon(Icons.block, color: APIs.me.darkTheme ? Colors.blue : Colors.white,),
                          title: const Text("Blocked Users", style: TextStyle(fontWeight: FontWeight.w400,color: Colors.white, fontSize: 14),),
                        ),
                      ),

                    ],
                  )


                ],
              );
            }
            else{
              return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white,));
            }
          }
        )

      ),
    );
  }


  _appBar(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(width: mq.width * 0.07,),
        Icon(Icons.person, color: APIs.me.darkTheme ? Colors.white : Colors.black, size: 17,),
        SizedBox(width: mq.width * 0.029,),
        SizedBox(
            width: mq.width * 0.6,
            child: Text("Profile", style: TextStyle(fontSize: 14.9, color: APIs.me.darkTheme ? Colors.white : Colors.black, fontWeight: FontWeight.w500, fontFamily: "Monts"),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              textAlign: TextAlign.start,
            )
        ),

        const Spacer(),

        PopupMenuButton(
            icon: Icon(Icons.more_vert_rounded, color: APIs.me.darkTheme ? Colors.white : Colors.black),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
            color: Colors.grey,
            itemBuilder: ((context){
              return [

                PopupMenuItem(
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(19),
                      color: Colors.grey,
                    ),
                    child: ListTile(

                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                      leading: const Padding(
                        padding: EdgeInsets.only(left: 12.0),
                        child: Icon(Icons.account_circle, color: Colors.black,),
                      ),
                      title: const Text("Contact Us", style: TextStyle(fontWeight: FontWeight.w600, color: Colors.black87),),
                      onTap: (){
                        Navigator.pop(context);
                        Future.delayed(const Duration(milliseconds: 100), (){
                          showModalBottomSheet(
                              backgroundColor: Colors.white70,
                              shape: const OutlineInputBorder(
                                borderRadius: BorderRadius.only(topLeft: Radius.circular(27), topRight: Radius.circular(27)),
                              ),
                              context: context, builder: (context){
                            return DeveloperBottomSheet();
                          });
                        });
                      },
                      minVerticalPadding: 0,
                      contentPadding: const EdgeInsets.all(0),
                    ),
                  ),

                ),

                PopupMenuItem(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(19),
                        color: Colors.grey,
                      ),
                      child: ListTile(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                        leading: const Padding(
                          padding: EdgeInsets.only(left: 12.0),
                          child: Icon(Icons.logout, color: Colors.black,),
                        ),
                        title: const Text("Logout", style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87),),
                        onTap: (){
                          loggingOutDialog();
                        },
                      ),
                    ),
                ),

                // PopupMenuItem(
                //   child: Container(
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(19),
                //       color: Colors.grey,
                //     ),
                //     child: ListTile(
                //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                //       leading: const Padding(
                //         padding: EdgeInsets.only(left: 12.0),
                //         child: Icon(Icons.app_settings_alt, color: Colors.black,),
                //       ),
                //       title: const Text("Dark Theme", style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black87),),
                //       onTap: (){
                //         // if(APIs.me.darkTheme){
                //         //   APIs.updateAppTheme(false).then((value){
                //         //     setState(() {
                //         //
                //         //     });
                //         //   });
                //         // }
                //         // else{
                //         //   APIs.updateAppTheme(true).then((value){
                //         //     setState(() {
                //         //
                //         //     });
                //         //   });
                //         // }
                //
                //       },
                //     ),
                //   ),
                // ),
              ];

            })),

        SizedBox(width: mq.width * 0.04,),
      ],
    );
  }

  signOutWGoogle()async{
    await FirebaseAuth.instance.signOut();
    await GoogleSignIn().signOut().then((value) {
      Navigator.of(context).pushNamedAndRemoveUntil(
          '/login', (Route<dynamic> route) => false
      );
    });
  }

  void loggingOutDialog(){
    showDialog(context: context, builder: (_) => AlertDialog(
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      backgroundColor: const Color.fromARGB(255, 43, 45, 48),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(9),
      ),
      title: const Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
        Icon(Icons.logout, color: Colors.white, size: 24,),
        SizedBox(width: 12,),
        Text('Logout from  ', style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
        Text('ZANSH', style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w600, fontFamily: "Monts"),),
      ],),

      content: Container(
        margin: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
        ),
        child: const Text(
          "Are you sure, you want to Logout!",
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white70),
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 16, color: Colors.white70),),),

        MaterialButton(onPressed: (){
          Dialogs.showCircularProgress(context, Colors.white);
          APIs.getCurrentUser().then((value) {
            APIs.updateActiveStatus(false).then((value) {
              signOutWGoogle();
            });
          });
        }, child: const Text('Logout!', style: TextStyle(fontSize: 16, color: Colors.blue),),),
      ],
    ));
  }

}
