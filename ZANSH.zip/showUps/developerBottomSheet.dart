import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:zansh/main.dart';

class DeveloperBottomSheet extends StatelessWidget {

  DeveloperBottomSheet({super.key});

  Color menuColor = Colors.white;


  @override
  Widget build(BuildContext context) {



    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(27), topRight: Radius.circular(27)),
        color: Colors.black87,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
              padding: EdgeInsets.only(top: mq.height * 0.04, bottom: mq.height * 0.02),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.account_circle, color: Colors.blue,),
                  SizedBox(width: mq.width * 0.02,),
                  Text(' Ansh Kukreja', style: TextStyle(fontSize: 16, color: menuColor, letterSpacing: 0.4, fontWeight: FontWeight.w400, fontFamily: "Monts"),),
                ],
              )
          ),


          Padding(
              padding: EdgeInsets.only(top: mq.height * 0.02, bottom: mq.height * 0.07),
              child: InkWell(
                onTap: ()async{
                  await Clipboard.setData(const ClipboardData(text: 'anshkukreja.dev.contact@gmail.com')).then((value){
                  });
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.mail, color: Colors.blue),
                    SizedBox(width: mq.width * 0.027,),
                    SelectableText('anshkukreja.dev.contact@gmail.com', style: TextStyle(fontSize: 9.9, color: menuColor, letterSpacing: 0.4, fontFamily: "Monts"),),
                  ],
                ),
              )
          ),

        ],
      ),
    );
  }
}
