import 'package:flutter/material.dart';

class Dialogs{

  static void showSnackBar(BuildContext context, String text, {int duration = 1000, double fSize = 17}){
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          //behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.black87,
          duration: Duration(milliseconds: duration),
          content: Center(child: Text(text,
            style: TextStyle( letterSpacing: 2.7, fontSize: fSize, fontFamily: 'Edo', color: Colors.white),
          ),),
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(
              topRight: Radius.circular(14), topLeft: Radius.circular(14)
          )),
          padding: const EdgeInsets.only(top: 14, bottom: 17, left: 14, right: 14),
        )
    );
  }

  static void showCircularProgress(BuildContext context, Color color, {bool isDismissable = false}){
    showDialog(
        context: context,
        barrierDismissible: isDismissable,
        builder: (_) => Center(
      child: CircularProgressIndicator(
        color: color,
        strokeWidth: 2.9,
      ),
    ),
    );
  }

}