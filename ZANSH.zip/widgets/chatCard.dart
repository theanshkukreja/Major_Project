import 'package:flutter/material.dart';
import 'package:zansh/main.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:zansh/api/apis.dart';
import 'package:zansh/modals/messageModal.dart';
import 'package:zansh/screens/search/viewUserProfile.dart';
import '../screens/chatUserScreen.dart';
import '../modals/chatUser.dart';

class ChatCard extends StatefulWidget {
  final ChatUser user;
  bool isViewingUser;
  bool isBlocked;
  bool inMessages;
  ChatCard({super.key, required this.user, this.isViewingUser = false, this.isBlocked = false, this.inMessages = false});

  @override
  State<ChatCard> createState() => _ChatCardState();
}

class _ChatCardState extends State<ChatCard> {
  Message? _msg;

  @override
  Widget build(BuildContext context) {
    return Card(
        margin: EdgeInsets.symmetric(vertical: 0.0, horizontal: mq.width * 0.004),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        color: Colors.white10,
        elevation: 1,
        child: InkWell(
          onTap: (){
            if(widget.inMessages){
              APIs.addNewUser(widget.user.email).then((value) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ChatUserScreen(user: widget.user)));
              });
            }
            else if(widget.isViewingUser){
              Navigator.push(context, MaterialPageRoute(builder: (context) => ViewUserProfile(user: widget.user)));
            }
            else{
              Navigator.push(context, MaterialPageRoute(builder: (context) => ChatUserScreen(user: widget.user, isBlocked: widget.isBlocked)));
            }
          },
          child: StreamBuilder(
            stream: APIs.getLastMessage(widget.user),
            builder: (context, snapshot) {

              final data = snapshot.data?.docs;
              final list = data?.map((e) => Message.fromJson(e.data())).toList() ?? [];
              if(list.isNotEmpty) _msg = list[0];
              // if(data != null && data.first.exists){
              // _msg = Message.fromJson(data.first.data());
              // }

              return ListTile(
                //leading: CircleAvatar(child:Image.network(widget.user.image),),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(mq.width * 0.074),
                  child: CachedNetworkImage(
                    height: mq.width * 0.147,
                    width: mq.width * 0.147,
                    imageUrl: widget.user.image,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => const CircularProgressIndicator(color: Colors.white70, strokeWidth: 4),
                    errorWidget: (context, url, error) => const CircleAvatar(child:Icon(Icons.account_circle, color: Colors.white70),),
                  ),
                ),

                title: Text(widget.user.name, maxLines: 1,style: const TextStyle(fontSize: 14.9, fontWeight: FontWeight.w600, color: Colors.white),),
                subtitle: Text(_msg != null ?
                _msg?.type == Type.image ?
                'Photo'
                    :
                _msg!.message : widget.user.about,
                  maxLines: 1,
                  style: const TextStyle( color: Colors.white70, fontSize: 14),),

                trailing: _msg == null ? null :
                _msg!.read.isEmpty && _msg!.fromId != APIs.user.uid?
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(right: 9),
                      height: 9,
                      width: 9,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4.5),
                          color: Colors.greenAccent
                      ),),

                    const SizedBox(height: 4,),

                    Text("${getLastMessageTime(_msg!.sent)}   ", style: const TextStyle(
                      color: Colors.greenAccent,
                      fontSize: 12,

                    ),),
                  ],
                ) :
                Text(getLastMessageTime(_msg!.sent), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Colors.white60),),
              );
            },),
        )
    );
  }


  String getLastMessageTime(String time){
    final DateTime sent = DateTime.fromMillisecondsSinceEpoch(int.parse(time));
    final DateTime now = DateTime.now();

    if(now.day == sent.day && now.month == sent.month && now.year == sent.year){
      return TimeOfDay.fromDateTime(sent).format(context);
    }
    else{
      return '${sent.day} ${getMonth(sent)}';
    }

  }

  static String getMonth(DateTime date){
    switch(date.month){
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return 'NA';
    }

  }

}
