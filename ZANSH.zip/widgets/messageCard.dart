import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../main.dart';
import 'package:zansh/api/apis.dart';
import '../modals/messageModal.dart';

class MessageCard extends StatefulWidget {

  const MessageCard({super.key, required this.message});

  final Message message;
  @override
  State<MessageCard> createState() => _MessageCardState();
}

class _MessageCardState extends State<MessageCard> {

  late bool isOnlyEmoji = false;
  bool isMessageTypeDefined = true;

  @override
  void initState() {
    super.initState();
    //isOnlyEmoji = containsOnlyEmojis(widget.message.message);
  }

  @override
  Widget build(BuildContext context) {
    bool isMe = APIs.user.uid == widget.message.fromId;

    return InkWell(
      onLongPress: (){
        _showMessageBottomSheet(isMe);
      },
      child: isMe ? blueMessage() : greyMessage(),
    );

  }

  Widget blueMessage(){
    Color readIconColor;
    if(widget.message.read.isEmpty){
      readIconColor = Colors.white60;
    }
    else{
      readIconColor = Colors.blue;
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            SizedBox(width: mq.width * 0.04),

            // if(widget.message.read.isNotEmpty)
            Icon(Icons.done_all_rounded, color: readIconColor, size: 19,),

            SizedBox(width: mq.width * 0.019),
            Text(widget.message.read.isEmpty ? "" : getFormattedTime(widget.message.read), style: const TextStyle(fontSize: 9.7, color: Colors.white70),),
          ],
        ),

        Flexible(
          child: Container(
            decoration: BoxDecoration(
                color: isOnlyEmoji || !isMessageTypeDefined ? Colors.transparent : Colors.blueAccent.shade400,  //blue.shade700
                borderRadius: const BorderRadius.only(topLeft: Radius.circular(29), topRight:  Radius.circular(29), bottomLeft:  Radius.circular(29)),
                border: Border.all(color: isOnlyEmoji ? Colors.transparent : Colors.blueAccent.shade400, width: 0.5)
            ),
            padding: EdgeInsets.only(
              left: widget.message.type == Type.image ? mq.width * 0.01 : mq.width * 0.037,
              right: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 :mq.width * 0.037,
              top: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 : mq.width * 0.024,
              bottom: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 : mq.width * 0.024,
            ),
            margin: EdgeInsets.symmetric(horizontal: mq.width * 0.029, vertical: isOnlyEmoji ? 0 : mq.height * 0.0029),

            child: widget.message.type == Type.text ?
            Text(!isMessageTypeDefined ?  ".." : widget.message.message, style: TextStyle(color: Colors.white, fontSize: isMessageTypeDefined && isOnlyEmoji ? 21 : 16 ,letterSpacing: 0.1, fontWeight: FontWeight.w400), textAlign: TextAlign.left)
                :
            ClipRRect(
              borderRadius: BorderRadius.circular(mq.height * 0.029),

              child: CachedNetworkImage(
                imageUrl: widget.message.message,
                placeholder: (context, url) => const CircularProgressIndicator(strokeWidth: 2,),
                errorWidget:  (context, url, error) => const Icon(Icons.image, size: 70),
              ),
            ),

          ),
        ),

      ],
    );
  }


  Widget greyMessage(){
    if(widget.message.read.isEmpty){
      APIs.updateMessageReadStatus(widget.message);
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Container(
            decoration: BoxDecoration(
                color: !isMessageTypeDefined || isOnlyEmoji ? Colors.transparent : Colors.white24,
                borderRadius: const BorderRadius.only(topLeft: Radius.circular(29), topRight:  Radius.circular(29), bottomRight:  Radius.circular(29)),
                border: Border.all(color: Colors.transparent),
            ),
            padding: EdgeInsets.only(
              left: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 : mq.width * 0.037,
              right: widget.message.type == Type.image ? mq.width * 0.01 : mq.width * 0.037,
              top: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 : mq.width * 0.029,
              bottom: widget.message.type == Type.image ? mq.width * 0.01 : isOnlyEmoji ? mq.width * 0.002 : mq.width * 0.029,
            ),

            margin: EdgeInsets.symmetric(horizontal: mq.width * 0.029, vertical: isOnlyEmoji ? 0 : mq.height * 0.0029),
            child: widget.message.type == Type.text ?
            Text(!isMessageTypeDefined ?  ".." : widget.message.message, style: TextStyle(color: Colors.white, fontSize: isMessageTypeDefined && isOnlyEmoji ? 21 : 16, letterSpacing: 0.1),textAlign: TextAlign.left)
                :
            ClipRRect(
              borderRadius: BorderRadius.circular(mq.height * 0.029),

              child: CachedNetworkImage(
                imageUrl: widget.message.message,
                placeholder: (context, url) => const CircularProgressIndicator(strokeWidth: 2),
                errorWidget:  (context, url, error) => const Icon(Icons.image, size: 70),
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(right: mq.width *0.04),
          child: Text(getFormattedTime(widget.message.sent), style: const TextStyle(fontSize: 9.7, color: Colors.white70),),
        ),
      ],
    );
  }



  String getFormattedTime(String time){
    final date = DateTime.fromMillisecondsSinceEpoch(int.parse(time));
    return TimeOfDay.fromDateTime(date).format(context);
  }

  void _showMessageBottomSheet(bool isMe){

    showModalBottomSheet(
      backgroundColor: const Color.fromARGB(255, 30, 31, 34),
      useSafeArea: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(29), topLeft: Radius.circular(29))),
      context: context, builder: (_){
      return ListView(
        shrinkWrap: true,
        children: [

          Container(
            height: 4,
            margin: EdgeInsets.only(top: mq.height * 0.02, left: mq.width * 0.4, right: mq.width * 0.4 , bottom: mq.height * 0.02),
            decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.circular(9)
            ),
          ),

          widget.message.type == Type.text ?
          ListTile(
            contentPadding: EdgeInsets.only(left: mq.width * 0.07),
              leading: const Icon(Icons.copy_all_rounded, color: Colors.blue,),
              title: const Text('Copy Text', style: TextStyle(color: Colors.white70),),

              onTap: () async {
                    await Clipboard.setData(ClipboardData(text: widget.message.message)).then((value){
                    Navigator.pop(context);
                     });
              }
              )
              :
          ListTile(
              contentPadding: EdgeInsets.only(left: mq.width * 0.07),
              leading: const Icon(Icons.download_rounded, color: Colors.blue,),
              title: const Text('Save Image', style: TextStyle(color: Colors.white70)),
              onTap: ()async{
                  Navigator.pop(context);
                 await APIs.saveImageToGallery(widget.message.message, context);}
          ),

          if(isMe)
            Divider(
              color: Colors.white24,
              indent: mq.width * 0.049,
              endIndent: mq.width * 0.049,
              thickness: 0.4,
            ),

          if(widget.message.type == Type.text && isMe)
            ListTile(
                contentPadding: EdgeInsets.only(left: mq.width * 0.07),
                leading: const Icon(Icons.edit, color: Colors.blue,),
                title: const Text('Edit Message', style: TextStyle(color: Colors.white70)),
                onTap: (){
                  Navigator.pop(context);
                  showMessageUpdateDialog();
                 }),

          if(isMe)
            ListTile(
                contentPadding: EdgeInsets.only(left: mq.width * 0.07),
                leading: const Icon(Icons.delete_forever, color: Colors.red,),
                title: const Text('Delete Message', style: TextStyle(color: Colors.white70)),
                onTap: () {
                  APIs.deleteMessage(widget.message);
                  Navigator.pop(context);
                }
            ),

          Divider(
            color: Colors.white24,
            indent: mq.width * 0.049,
            endIndent: mq.width * 0.049,
            thickness: 0.4,
          ),

          // ${getFormattedTime(widget.message.sent)}

          ListTile(
              contentPadding: EdgeInsets.only(left: mq.width * 0.07),
              leading: const Icon(Icons.remove_red_eye, color: Colors.grey,),
              title: Text('Sent Time :  ${getMessageDateTime(widget.message.sent)}', style: const TextStyle(color: Colors.white70)),
              onTap: (){}
          ),

          ListTile(
              contentPadding: EdgeInsets.only(left: mq.width * 0.07),
              leading: const Icon(Icons.remove_red_eye, color: Colors.blue,),
              title: Text(widget.message.read.isNotEmpty ? 'Read Time :  ${getMessageDateTime(widget.message.read)}' : 'Read Time :  Unread',
                  style: const TextStyle(color: Colors.white70)
              ),
              onTap: (){}),

          SizedBox(height: mq.height * 0.017,),


        ],
      );},
    );
  }

  void showMessageUpdateDialog(){
    String updatedMsg = widget.message.message;
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color.fromARGB(255, 60, 63, 65),
      contentPadding: const EdgeInsets.only(left: 24, right: 24, top: 20, bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(29),
      ),
      title: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
        // const Icon(Icons.message, color: Colors.blue, size: 24,),
        //SizedBox(width: mq.width * 0.05,),
        Text('Update Message', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),),
      ],),

      content: TextFormField(
        maxLines: null,
        cursorColor: Colors.white70,
        onChanged: (value) => updatedMsg=value,
        initialValue: updatedMsg,
        decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(19),
              borderSide: const BorderSide(color: Colors.white70)
            ),
          focusedBorder:  OutlineInputBorder(
            borderRadius: BorderRadius.circular(19),
            borderSide: const BorderSide(color: Colors.white70)
          )
        ),
      ),

      actions: [
        MaterialButton(onPressed: (){Navigator.pop(context);}, child: const Text('Cancel', style: TextStyle(fontSize: 16, color: Colors.blue),),),

        MaterialButton(onPressed: (){
          Navigator.pop(context);
          APIs.updateMessage(widget.message, updatedMsg);
        }, child: const Text('Update', style: TextStyle(fontSize: 16, color: Colors.blue),),),
      ],
    ));
  }

  String getMessageDateTime(String time){
    final DateTime sent = DateTime.fromMillisecondsSinceEpoch(int.parse(time));
    final DateTime now = DateTime.now();

    if(now.day == sent.day && now.month == sent.month && now.year == sent.year){
      return TimeOfDay.fromDateTime(sent).format(context);
    }
    else{
      return '${sent.day} ${getMonth(sent)} (${TimeOfDay.fromDateTime(sent).format(context)})';
    }

  }
  static String getMonth(DateTime date){
    switch(date.month){
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return 'NA';
    }

  }


  // bool containsOnlyEmojis(String text) {
  //   for (var char in text.characters) {
  //     bool x = containsAlphabets(char);
  //     bool y = containsNumbers(char);
  //     bool z = containsSpecialCharacters(char);
  //     bool a = containsSpaces(char);
  //
  //     if( x == true || y == true || z == true || a == true ){
  //         isMessageTypeDefined = true;
  //
  //       return false;
  //     }
  //   }
  //
  //
  //     isMessageTypeDefined = true;
  //
  //   return true;
  // }
  //
  // bool containsSpaces(String text){
  //   return text == "" || text == " ";
  // }
  //
  // bool containsAlphabets(String text) {
  //   return RegExp(r'[a-zA-Z]').hasMatch(text);
  // }
  //
  // bool containsNumbers(String text) {
  //   return RegExp(r'[0-9]').hasMatch(text);
  // }
  //
  // bool containsSpecialCharacters(String text) {
  //   return RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(text);
  // }


// bool _isEmoji(int codePoint) {
  //   // Emoji range in Unicode
  //   return (codePoint >= 0x1F300 && codePoint <= 0x1F9FF) ||
  //       (codePoint >= 0x2600 && codePoint <= 0x27BF) ||
  //       (codePoint >= 0x1F680 && codePoint <= 0x1F6FF) ||
  //       (codePoint >= 0x1F900 && codePoint <= 0x1F9FF);
  // }

  // bool isEmoji(String text) {
  //   RegExp emojiRegex = RegExp(
  //     r"(\uD83C[\uDF00-\uDFFF])|(\uD83D[\uDC00-\uDE4F])|"
  //     "([\u2600-\u26FF\u2700-\u27BF])",
  //     caseSensitive: false,
  //     unicode: true,
  //   );
  //   return emojiRegex.hasMatch(text);
  // }
  //
  // bool isOnlyEmojis(String text){
  //   for (var char in text.characters) {
  //     if (!isEmoji(char)) {
  //       log("----------- MESSAGE CONTAINS STRING -----------------");
  //       return false;
  //     }
  //   }
  //   log("----------- MESSAGE IS ONLY EMOJIS -----------------");
  //   return true;
  // }


}

// class _OptionItem extends StatelessWidget {
//   final Icon icon;
//   final String name;
//   final VoidCallback onTap;
//   const _OptionItem({super.key, required this.icon, required this.name, required this.onTap});
//
//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: () => onTap(),
//
//       child: Padding(
//         padding: EdgeInsets.only(left: mq.width * 0.07, top: mq.width * 0.034, bottom: mq.width * 0.034),
//         child: Row(
//           children: [
//             icon,
//             Flexible(
//               child: Text('  $name', style: const TextStyle(fontSize: 14.7, letterSpacing: 0.5, color: Colors.black54),),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }



