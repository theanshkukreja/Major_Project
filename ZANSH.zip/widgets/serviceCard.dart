import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zansh/screens/viewPosts/viewServiceBriefly.dart';
import '../api/apis.dart';
import '../main.dart';
import '../modals/newService.dart';
import '../showUps/dialogs.dart';

class ServiceCard extends StatefulWidget {
  final ServicePost service;
  final bool isNearby;
  final bool isMe;
  const ServiceCard({super.key, required this.service, required this.isNearby, this.isMe = false});

  @override
  State<ServiceCard> createState() => _ServiceCardState();
}

class _ServiceCardState extends State<ServiceCard> {
  bool isSaved = false;
  late String? distance;

  @override
  void initState() {
    super.initState();
    checkSaveStatus(widget.service.id);
  }

  @override
  Widget build(BuildContext context) {
    if(widget.isNearby == true){
      distance  = widget.service.distance?.toStringAsFixed(1) ?? "";
    }
    return GestureDetector(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(builder: (context) => ViewServiceBriefly(service: widget.service, isMe: widget.isMe,)));
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: mq.width * 0.04),
        height: mq.width * 0.64,
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: Colors.white70, width: 0.4),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.3),
              spreadRadius: 2.9,
              blurRadius: 7,
              offset: const Offset(0, 4), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(top: mq.width * 0.029, left: mq.width * 0.049),
                  child: SizedBox(
                    width: mq.width * 0.7,
                    child: Text(widget.service.sTitle, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: Color.fromARGB(255, 253, 253, 253), letterSpacing: 0.4),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                ),
                const Spacer(),
                Padding(
                  padding: EdgeInsets.only(top: mq.width * 0.01),
                  child: IconButton(
                      constraints: const BoxConstraints(minWidth: 0, minHeight: 0),
                      onPressed: (){
                        void savePost()async {
                          await APIs.savePost(widget.service.id ?? "").then((value) {
                            Dialogs.showSnackBar(context, "Saved!");
                          });
                          setState(() {
                            isSaved = !isSaved;
                          });
                        }
                        void unSavePost()async{
                          await APIs.unSavePost(widget.service.id ?? "");
                          setState(() {
                            isSaved = !isSaved;
                          });
                        }

                        isSaved ?
                        unSavePost()
                            :
                        savePost();
                      },
                      icon: widget.isMe ?
                          const SizedBox()
                          :
                      Icon(isSaved ? CupertinoIcons.bookmark_fill : CupertinoIcons.bookmark, size: 29, color: Colors.blue,)
                  ),
                ),
              ],
            ),
            const Divider(color: Colors.white70, thickness: 0.1,),

            widget.service.sImage == "" || widget.service.sImage.isEmpty || widget.service.sImage == "null" || widget.service.sImage == " "?
            Padding(
              padding: EdgeInsets.only(top: mq.width * 0.021, bottom: mq.width * 0.021, left: mq.width * 0.049, right: mq.width * 0.029),
              child: SizedBox(
                height: mq.width * 0.14,
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(widget.service.sDesc, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Color.fromARGB(
                      255, 222, 218, 229), letterSpacing: 0.4),
                    overflow: TextOverflow.fade,
                  ),
                ),
              ),
            )
                :
            Padding(
              padding: EdgeInsets.only(top: mq.width * 0.021, bottom: mq.width * 0.021, left: mq.width * 0.049, ),
              child: Row(
                children: [
                  SizedBox(
                    height: mq.width * 0.14,
                    width: mq.width * 0.64,
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(widget.service.sDesc, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Color.fromARGB(
                          255, 222, 218, 229), letterSpacing: 0.4),
                        overflow: TextOverflow.fade,
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 9),
                    height: mq.width * 0.14,
                    width: mq.width * 0.14,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(9),
                      child: CachedNetworkImage(imageUrl: widget.service.sImage, fit: BoxFit.cover,),
                    ),
                  ),
                ],
              ),
            ),

            const Divider(color: Colors.white70, thickness: 0.1,),
            Padding(
              padding: EdgeInsets.only(top: mq.width * 0.01, left: mq.width * 0.049, right: mq.width * 0.029),
              child: Row(
                children: [
                  Text(widget.service.sFeesCurrency == "rupee" ? "₹ " : "\$ ", style: TextStyle(fontSize: widget.service.sFeesCurrency == "rupee" ? 16 : 14, fontWeight: FontWeight.w600, color: Colors.greenAccent, letterSpacing: 0.4),),
                  Text(widget.service.sFees, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.greenAccent, letterSpacing: 0.4),),
                  const SizedBox(width: 7,),
                  Text(widget.service.sFeesPer, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color.fromARGB(255, 218, 217, 217), letterSpacing: 0.4),),

                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.blue, width: 1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Center(child: Text("Service", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color.fromARGB(255, 228, 226, 231), letterSpacing: 0.4),)),
                  )

                ],
              ),
            ),
            const Divider(color: Colors.white70, thickness: 0.1,),
            Padding(
              padding: EdgeInsets.only(top: mq.width * 0.01, left: mq.width * 0.049, right: mq.width * 0.029),
              child: Row(
                children: [
                  SizedBox(
                      width: mq.width * 0.49,
                      child: Text("${widget.service.sCity} , ${widget.service.sState}",
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Color.fromARGB(255, 222, 218, 229), letterSpacing: 0.4),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )
                  ),

                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    // decoration: BoxDecoration(
                    //   // border: Border.all(color: Colors.blue, width: 1),
                    //   // borderRadius: BorderRadius.circular(4),
                    // ),
                    child: Row(
                      children: [
                        Icon(widget.isNearby ? Icons.location_on : Icons.access_time_filled_rounded, color: widget.isNearby ? Colors.blue : Colors.black, size: 16,),
                        const SizedBox(width: 1,),
                        Text(widget.isNearby ? "$distance km" : getUploadTime(uploadTime: widget.service.uploadTime), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: Color.fromARGB(255, 222, 218, 229)),),
                      ],
                    ),
                  )

                ],
              ),
            ),

          ],
        ),
      ),
    );
  }

  Future<void> checkSaveStatus(String postId) async {
    List<DocumentSnapshot>? allSaves;

    Future<void> getAllSaves() async {
      final CollectionReference airChatsFireRef = FirebaseFirestore.instance.collection('users').doc(APIs.user.uid).collection('savedPosts');
      QuerySnapshot querySnapshot = await airChatsFireRef.get();
      allSaves = querySnapshot.docs;
    }

    await getAllSaves().then((value) {
      if (allSaves != null) {
        for (DocumentSnapshot a in allSaves!) {
          var data = a.data() as Map<String, dynamic>?;

          if(a.id.toString() == postId){
            log("-- Working ${a.id} ----");
            setState(() {
              isSaved = true;
            });
          }
        }}
    }

    );
  }

  getUploadTime({required String uploadTime}){

    final int i = int.tryParse(uploadTime) ?? -1;

    if(i == -1) return '--';

    DateTime time = DateTime.fromMillisecondsSinceEpoch(i);
    String formattedTime = TimeOfDay.fromDateTime(time).format(context);
    int y = time.day;
    String month = _getMonth(time);

    return '${time.day} $month, ${time.year}';

  }

  static String _getMonth(DateTime date){
    switch(date.month){
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return 'NA';
    }

  }

}
