import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../api/apis.dart';
import '../main.dart';
import '../showUps/dialogs.dart';

class EmailPassSignUp extends StatefulWidget {
  const EmailPassSignUp({super.key});

  @override
  State<EmailPassSignUp> createState() => _EmailPassSignUpState();
}

class _EmailPassSignUpState extends State<EmailPassSignUp> {
  final _formkey = GlobalKey<FormState>();

  String uEmail = " ";
  String uPassword = " ";
  String uName = " ";

  String tempPass = " ";

  bool obscureText1 = true;
  bool obscureText2 = true;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text("Create Account", style: TextStyle(fontFamily: "Monts", fontSize: 17, color: Colors.white),),
        ),

        body: SingleChildScrollView(
          child: Form(
            key: _formkey,
            child: Column(
              children: [
                SizedBox(width: mq.width, height: mq.height * 0.049,),
                Container(
                  padding: const EdgeInsets.all(4),
                  width: mq.width * 0.24,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(19),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.4),
                        spreadRadius: 1.4,
                        blurRadius: 7,
                        offset: const Offset(0, 0),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(19),
                    child: Image.asset("assets/images/logo.png"),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.12,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("name"),
                      decoration: InputDecoration(
                        hintText: "Full Name",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        if(value == null || value == " " || value.length <= 1 || value.length >= 40){
                          return "Please Enter a Valid Name";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uName = val.toString();
                        });
                      },
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.0035,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("email"),
                      decoration: InputDecoration(
                        hintText: "Email",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        if(value == null || value == " " || value.length <= 1 || !value.contains("@")){
                          return "Please Enter a Valid Email";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uEmail = val.toString();
                        });
                      },
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.0035,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("password"),
                      obscureText: obscureText1,
                      decoration: InputDecoration(
                        hintText: "Password",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              obscureText1 = !obscureText1;
                            });
                          },
                          child: Icon(
                            !obscureText1 ? Icons.visibility : Icons.visibility_off,
                            color: !obscureText1 ? Colors.blue : Colors.grey,
                          ),
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        tempPass = value.toString();
                        if(value == null || (value.length < 6) || value == " "){
                          return "Password must have atleast 6 characters";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uPassword = val.toString();
                        });
                      },
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.0035,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("rPassword"),
                      obscureText: obscureText2,
                      decoration: InputDecoration(
                        hintText: "Re-Enter Password",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              obscureText2 = !obscureText2;
                            });
                          },
                          child: Icon(
                            !obscureText2 ? Icons.visibility : Icons.visibility_off,
                            color: !obscureText2 ? Colors.blue : Colors.grey,
                          ),
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        if(value == null || (value.length < 6) || value == " "){
                          return "Password must have atleast 6 characters";
                        }
                        else if(value != tempPass){
                          return "Passwords didn't match!";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uPassword = val.toString();
                        });
                      },
                    ),
                  ),
                ),

                SizedBox(height: mq.height * 0.04,),

                InkWell(
                  onTap: (){
                    Future<bool> createUser()async {
                      bool x = await APIs.signUpUserWithEmailPassword(uEmail, uPassword, uName, context);
                      return Future.value(x);
                    }

                    if(_formkey.currentState!.validate()){
                      _formkey.currentState!.save();
                      Dialogs.showCircularProgress(context, Colors.white);
                      createUser().then((value) {
                          if(value == true){
                            Navigator.of(context).pushNamedAndRemoveUntil(
                                '/login', (Route<dynamic> route) => false
                            );
                          }
                          else{
                            Navigator.pop(context);
                          }
                      });
                    }
                  },
                  child: Container(
                    width: mq.width * 0.84,
                    height: mq.width * 0.1,
                    decoration: BoxDecoration(
                      color: Colors.lightBlue.shade900,
                      borderRadius: BorderRadius.circular(19),
                    ),
                    child: const Center(child: Text("Create Account", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w400, fontSize: 12, fontFamily: "Monts"),)),

                  ),

                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
