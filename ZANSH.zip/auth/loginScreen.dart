import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:zansh/showUps/dialogs.dart';
import '../api/apis.dart';
import '../main.dart';
import 'emailPassSignUp.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _obscureText = true;

  String uEmail = " ";
  String uPassword = " ";

  bool invalidCreds = false;
  bool isCredsValidated = false;

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          automaticallyImplyLeading: false,
          title: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Welcome to ", style: TextStyle(fontSize: 17, fontFamily: "Monts"),),
              Text("ZANSH", style: TextStyle(fontSize: 19, fontFamily: "Monts", letterSpacing: 0.7),),
            ],
          ),
        ),
        backgroundColor: Colors.black87,

        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: mq.width, height: mq.height * 0.049,),
                Container(
                  padding: const EdgeInsets.all(4),
                  width: mq.width * 0.29,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(19),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.4),
                        spreadRadius: 1.4,
                        blurRadius: 7,
                        offset: const Offset(0, 0),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(19),
                    child: Image.asset("assets/images/logo.png"),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.height * 0.12,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: mq.width * 0.04),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("email"),
                      decoration: InputDecoration(
                        hintText: "Email",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        if(value == null || !value.contains("@") || value == " "){
                          return "Please Enter a Valid Email Address";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uEmail = val.toString();
                        });
                      },
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.07, right: mq.width * 0.07, top: mq.width * 0.0035,bottom: mq.height * 0.0035),
                  child: Container(
                    padding: EdgeInsets.only(left: mq.width * 0.04, right: mq.width * 0.02),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 30, 30, 30),
                      border: Border.all(color: Colors.white70, width: 1),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextFormField(
                      key: const ValueKey("password"),
                      obscureText: _obscureText,
                      decoration: InputDecoration(
                        hintText: "Password",
                        hintFadeDuration: const Duration(milliseconds: 247),
                        hintStyle: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w400, fontSize: 14.9),
                        border: InputBorder.none,
                        errorStyle: TextStyle(
                            color: Colors.red.shade400, // Change error text color here
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.9,
                            fontWeight: FontWeight.w500,
                            fontSize: 11
                        ),
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              _obscureText = !_obscureText;
                            });
                          },
                          child: Icon(
                            !_obscureText ? Icons.visibility : Icons.visibility_off,
                            color: !_obscureText ? Colors.blue : Colors.grey,
                          ),
                        ),
                      ),
                      style: const TextStyle(fontSize: 14),
                      validator: (value) {
                        if(value == null || (value.length < 6) || value == " "){
                          return "Password must have atleast 6 characters";
                        }
                        else{
                          return null;
                        }
                      },
                      onSaved: (val){
                        setState(() {
                          uPassword = val.toString();
                        });
                      },
                      onChanged: (val){
                         if(val.length >= 6){
                           if(_formKey.currentState!.validate()){
                             setState(() {
                               isCredsValidated = true;
                             });
                           }
                         }
                         if(val.length < 6){
                           if(isCredsValidated){
                             setState(() {
                               isCredsValidated = false;
                             });
                           }
                         }
                      },
                    ),
                  ),
                ),

                invalidCreds ?
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text("Invalid Credentials!", style: TextStyle(
                      color: Colors.red.shade400,
                      fontStyle: FontStyle.italic,
                      letterSpacing: 0.9,
                      fontWeight: FontWeight.w500,
                      fontSize: 11
                  ),),
                )
                :
                    const SizedBox(),

                SizedBox(height: mq.height * 0.029,),

                InkWell(
                  onTap: (){
                    FocusScope.of(context).unfocus();
                    if(_formKey.currentState!.validate()){
                      _formKey.currentState!.save();

                      loginWithEmailPassword().then((value) {

                        if(value != null){
                          Navigator.of(context).pushNamedAndRemoveUntil(
                              '/homeScreen', (Route<dynamic> route) => false
                          );
                        }
                        else{
                          setState(() {
                            invalidCreds = true;
                          });
                        }

                      });
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 249),
                    width: mq.width * 0.84,
                    height: mq.width * 0.1,
                    decoration: BoxDecoration(
                      color: isCredsValidated ? Colors.lightBlue.shade900 : Colors.white24,
                      //color: const Color.fromARGB(255, 82, 82, 89),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Center(child: Text("Login", style: TextStyle(color: isCredsValidated ? const Color.fromARGB(255, 219, 222, 222) : Colors.white70, fontWeight: FontWeight.w400, fontFamily: "Monts", fontSize: 12),)),

                  ),
                ),

                const Padding(
                  padding: EdgeInsets.only(top: 4.0, bottom: 2),
                  child: Divider(color: Colors.white70, thickness: 0.1),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Don't have an Account?  ", style: TextStyle(fontSize: 12,fontFamily: "Monts" ,fontWeight: FontWeight.w600, color: Colors.white70),),
                      InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const EmailPassSignUp()));
                        },
                        child: const Text("SignUp", style: TextStyle(fontSize: 12.9, fontFamily: "Monts",fontWeight: FontWeight.w600, color: Colors.blue),),
                      ),
                    ],
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.only(top: 4.0, bottom: 2),
                  child: Divider(color: Colors.white70, thickness: 0.1),
                ),

                const Text("or", style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  color: Colors.white70,
                  fontFamily: "Monts"
                ),),

                SizedBox(height: mq.height * 0.02,),

                Padding(
                  padding: EdgeInsets.only(left: mq.width * 0.2, right: mq.width * 0.2, bottom: mq.width * 0.2),
                  child: ElevatedButton(onPressed: (){
                    loginWithGoogle();
                  },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue.shade900,
                        //backgroundColor: const Color.fromARGB(255, 82, 82, 89),
                        shape: const StadiumBorder(),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 24,
                            child: Image.asset("assets/images/search.png"),
                          ),

                          SizedBox(width: mq.width * 0.04,),
                          const Text("SignIn With Google", style: TextStyle(fontWeight: FontWeight.w400, color: Color.fromARGB(
                              255, 219, 222, 222), fontSize: 12, fontFamily: "Monts"),)
                        ],
                      )
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void loginWithGoogle(){
    Dialogs.showCircularProgress(context, Colors.white);
    _signInWithGoogle().then((user) async {
      if(user != null){
        if(await APIs.userExists()){
          Navigator.of(context).pushNamedAndRemoveUntil(
              '/homeScreen', (Route<dynamic> route) => false
          );
        }
        else{
          APIs.createNewUser().then((value) {
            Navigator.of(context).pushNamedAndRemoveUntil(
                '/homeScreen', (Route<dynamic> route) => false
            );
          });
        }

      }
    });
  }

  Future<UserCredential?> loginWithEmailPassword()async{
    Dialogs.showCircularProgress(context, Colors.white);

    try{
      await InternetAddress.lookup("google.com");

      return APIs.signInUserWithEmailPassword(uEmail, uPassword, context);
    }
    catch(e){
      FocusScope.of(context).unfocus();
      Navigator.pop(context);
      Dialogs.showSnackBar(context, "You are Offline!");
    }
    return null;
  }

  Future<UserCredential?> _signInWithGoogle() async {
    try{
      await InternetAddress.lookup("www.google.com");
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      // Obtain the auth details from the request
      final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      // Once signed in, return the UserCredential
      return await APIs.auth.signInWithCredential(credential);
    }
    catch(e){
      Navigator.pop(context);
      Dialogs.showSnackBar(context, "Something went Wrong!");
      return null;
    }
  }

}
