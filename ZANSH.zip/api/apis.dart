import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:zansh/modals/newJob.dart';
import 'package:zansh/modals/newService.dart';
import 'package:zansh/showUps/dialogs.dart';
import '../auth/loginScreen.dart';
import '../modals/chatUser.dart';
import 'package:zansh/modals/messageModal.dart';
import 'package:crypto/crypto.dart';

class APIs{

  static FirebaseAuth auth = FirebaseAuth.instance;

  static FirebaseFirestore firestore = FirebaseFirestore.instance;

  static FirebaseStorage fStorage = FirebaseStorage.instance;

  static User get user => auth.currentUser!;

  static late ChatUser me;

  static Future<bool> signUpUserWithEmailPassword(String email, String password, String name, BuildContext context) async{

    try{
      UserCredential userCreds = await auth.createUserWithEmailAndPassword(email: email, password: password);

      await auth.currentUser!.updateDisplayName(name);
      await auth.currentUser!.updateEmail(email);
      String uid = auth.currentUser!.uid;
      await createNewEmailPassUser(name, password, email, uid).then((value) {
        Dialogs.showSnackBar(context, "Account Created!", duration: 1200);
      });
      return Future.value(true);

    } on FirebaseAuthException catch(e){
      if(e.code == 'weak-password'){
        Dialogs.showSnackBar(context, "Entered Password is too Weak");
      }
      else if(e.code == 'email-already-in-use'){
        Dialogs.showSnackBar(context, "Email Already Exists");
      }
      else{
        Dialogs.showSnackBar(context, "Invalid Email!");
      }
      return Future.value(false);
    }
    catch(e){
      log(e.toString());
      Dialogs.showSnackBar(context, "Something Went Wrong!");
      return Future.value(false);
    }

  }

  static Future<void> createNewEmailPassUser(String xName, String xPassword, String xEmail, String xUid)async{
    final time = DateTime.now().millisecondsSinceEpoch.toString();
    final newUser = ChatUser(
      image: "",
      about: "Just Vibing..",
      name: xName,
      createdAt: time,
      id: xUid ,
      lastActive: '',
      isOnline: true,
      pushToken: '',
      email: xEmail,
      phoneNumber: "Pass:$xPassword",
    );
    await firestore.collection('users').doc(xUid).set(newUser.toJson());
  }

  static Future<UserCredential?> signInUserWithEmailPassword(String email, String password, BuildContext context)async{
    log("--LOGIN-CREDENTIALS--");
    log(email);
    log(password);
    try{
      return await auth.signInWithEmailAndPassword(email: email, password: password);

    } on FirebaseAuthException catch(e){
      log(e.code.toString());
      if(e.code.toString() == "INVALID_LOGIN_CREDENTIALS" || e.code.toString() == 'invalid-email'){
        Dialogs.showSnackBar(context, "Invalid Credentials!");
      }
      else if(e.code == 'wrong-password'){
        Dialogs.showSnackBar(context, "Email and Password did not match!");
      }
      else{
        FocusScope.of(context).unfocus();
        Navigator.pop(context);
        Dialogs.showSnackBar(context, "Invalid Credentials!");
      }
    }
    catch(e){
      log(e.toString());
      FocusScope.of(context).unfocus();
      Navigator.pop(context);
      Dialogs.showSnackBar(context, "Something Went Wrong!");
    }
    return null;
  }

  static Future<bool> userExists()async{
    return (await firestore.collection('users').doc(user.uid).get()).exists;
  }

  static Future<void> createNewUser()async{
    final time = DateTime.now().millisecondsSinceEpoch.toString();
    final newUser = ChatUser(
      image: user.photoURL.toString(),
      about: "Just Vibing..",
      name: user.displayName.toString(),
      createdAt: time,
      id: user.uid.toString(),
      lastActive: '',
      isOnline: true,
      pushToken: '',
      email: user.email.toString(),
      phoneNumber: user.phoneNumber.toString(),
    );
    return (await firestore.collection('users').doc(user.uid).set(newUser.toJson()));
  }

  static Future<String> getCurrentUser() async {
    await firestore.collection('users').doc(user.uid).get().then((user) async {

      if(user.exists){
        me = ChatUser.fromJson(user.data()!);
        //await getFirebaseMessagingToken();
      }
      else{
        await createNewUser().then((value) => getCurrentUser());
      }

    }).then((value){
      return "UserFetched";
    });
    return "error";
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>> getMyUsersId(){
    return firestore.collection('users').doc(user.uid).collection('my_users').snapshots();
  }

  static Future<bool> addNewUser(String email)async{
    final data = await firestore.collection('users').where('email', isEqualTo: email).get();

    if(data.docs.isNotEmpty && data.docs.first.id != user.uid){
      firestore.collection('users').doc(user.uid).collection('my_users').doc(data.docs.first.id).set({});
      return true;
    }
    else{
      return false;
    }

  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getAllUsers(List<String> myUsersId){

    if(myUsersId.isNotEmpty){
      return firestore.collection('users').where('id', whereIn: myUsersId).snapshots();
    }
    else{
      return null;
    }

  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getAllFuckingUsers(){
    return firestore.collection('users').snapshots();
  }

  static Future<void> sendFirstMessage(ChatUser chatUser, String msg, Type type, {String isApplication = "false"})async{
    if(isApplication == "true"){
      await firestore.collection('users').doc(chatUser.id).collection('my_users').doc(user.uid).set({}).then((value) => sendMessage(chatUser, msg, type, isApplication: "true"));
    }
    else{
      await firestore.collection('users').doc(chatUser.id).collection('my_users').doc(user.uid).set({}).then((value) => sendMessage(chatUser, msg, type));
    }
  }

  static Future<void> updateUserDetails()async{
    await firestore.collection('users').doc(user.uid).update({
      'name': me.name,
      'about': me.about,
    });
  }

  static Future<void> updateAppTheme(bool darkTheme)async{
    await firestore.collection('users').doc(user.uid).update({
      'darkTheme': darkTheme,
    });
  }

  static Future<void> updateProfilePic(File file) async {
    final ext = file.path.split('.').last;
    final ref = fStorage.ref().child('profile_pictures/${user.uid}.$ext');
    await ref.putFile(file, SettableMetadata(contentType: "image/$ext")).then((p0) {
      log("---- Data Transfferred : ${p0.bytesTransferred / 1000} kb ----");
    });
    me.image = await ref.getDownloadURL();

    await firestore.collection('users').doc(user.uid).update({
      'image' : me.image,
    });
  }

  // static String getConversationId(String id) => user.uid.hashCode <= id.hashCode
  //     ? '${user.uid}_$id'
  //     : '${id}_${user.uid}';

  static String getConversationId(String id) {
    String id2 = user.uid;
    List<String> sortedIds = [id, id2]..sort();
    String combinedIds = sortedIds.join();

    // Generate SHA-256 hash of the combined IDs
    var bytes = utf8.encode(combinedIds);
    var digest = sha256.convert(bytes);

    // Convert the hash digest to a string
    String conversationId = digest.toString();
    log("@@@@@@@@ CONVERSATION ID : $conversationId @@@@@@@@@@");
    return conversationId;
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>> getAllMessages(ChatUser user){
    return firestore.collection('chats/${getConversationId(user.id)}/messages/').orderBy('sent', descending: true).snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> getUserInfo (ChatUser gigauser){

    return firestore.collection('users').where('id', isEqualTo: gigauser.id).snapshots();
  }

  static Future<void> updateActiveStatus(bool isOnline)async{
    await firestore.collection('users').doc(user.uid).update({
      'is_online' : isOnline,
      'last_active' : DateTime.now().millisecondsSinceEpoch.toString(),
      'push_token' : me.pushToken,
    }
    );
  }

  static Future<void> sendMessage(ChatUser chatUser, String msg, Type type, {String isApplication = "false"})async {

    if(isApplication == "true"){
      final time = DateTime.now().millisecondsSinceEpoch.toString();
      final Message message = Message(read: '', fromId: user.uid, toId: chatUser.id, type: type, message: msg, sent: time, isApplication: "true");
      final ref = firestore.collection('chats/${getConversationId(chatUser.id)}/messages/');
      await ref.doc(time).set(message.toJson());  //.then((value) => sendPushNotifications(chatUser,type == Type.text ? msg:'Photo'))
    }
    else{
      final time = DateTime.now().millisecondsSinceEpoch.toString();
      final Message message = Message(read: '', fromId: user.uid, toId: chatUser.id, type: type, message: msg, sent: time);
      final ref = firestore.collection('chats/${getConversationId(chatUser.id)}/messages/');
      await ref.doc(time).set(message.toJson()); //.then((value) => sendPushNotifications(chatUser,type == Type.text ? msg:'Photo'))
    }

  }

  static Future<void> updateMessageReadStatus(Message message)async{
    firestore.collection('chats/${getConversationId(message.fromId)}/messages/')
        .doc(message.sent)
        .update({'read': DateTime.now().millisecondsSinceEpoch.toString()});
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>> getLastMessage(ChatUser user){
    return firestore.collection('chats/${getConversationId(user.id)}/messages/').orderBy('sent', descending: true).limit(1).snapshots();
  }

  static Future<void> sendChatImage(ChatUser gigaUser,File file) async{
    final ext = file.path.split('.').last;

    final ref = fStorage.ref().child('images/${getConversationId(gigaUser.id)}/${DateTime.now().millisecondsSinceEpoch}.$ext');

    await ref.putFile(file, SettableMetadata(contentType: "image/$ext")).then((p0) {
      log("---- Data Transfferred : ${p0.bytesTransferred / 1000} kb ----");
    });

    final imageUrl = await ref.getDownloadURL();

    await sendMessage(gigaUser, imageUrl, Type.image);
  }

  static FirebaseMessaging fMessaging = FirebaseMessaging.instance;

  // static Future<void> getFirebaseMessagingToken()async{
  //   await fMessaging.requestPermission();
  //   fMessaging.getToken().then((t) {
  //     if(t != null){
  //       me.pushToken = t;
  //       log("P U S H   T O K E N : $t");
  //       log(' : E N D');
  //     }
  //
  //     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
  //       log('Got a message whilst in the foreground!');
  //       log('Message data: ${message.data}');
  //
  //       if (message.notification != null) {
  //         log('Message also contained a notification: ${message.notification}');
  //       }
  //     });
  //
  //   });
  // }

  // static Future<void> sendPushNotifications(ChatUser gUser, String msg)async{
  //
  //   try{
  //     final body = {
  //       "to":gUser.pushToken,
  //       "notification":{
  //         "title":me.name,
  //         "body":msg,
  //         "android_channel_id":"chats",
  //       },
  //       "data": {
  //         "some_data" : "User id: ${me.id}",
  //       },
  //     };
  //     var url = Uri.https('example.com', 'whatsit/create');
  //     var response = await post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
  //         headers: {
  //           HttpHeaders.contentTypeHeader: 'application/json',
  //           HttpHeaders.authorizationHeader: 'key=AAAARdNFZLw:APA91bHjEYobHkAXlBv20_4b-j_bqxTUOonengD7hf-0UDUY0aJJv3vU7di7QR5ofVWdbZ4bQjAfMl_4yThZ0dcW8Gv5EXCk1kxtFZdhUTUxpS-eGQVhJZtNoMc4FfqJRJ8zcwBHRiw9',
  //         }
  //         , body: jsonEncode(body));
  //     log('Response status: ${response.statusCode}');
  //     log('Response body: ${response.body}');
  //   }
  //   catch(e){
  //     log('E R R O R : $e');
  //   }
  // }

  static signOutWGoogle(BuildContext context)async{
    await FirebaseAuth.instance.signOut();
    await GoogleSignIn().signOut().then((value) {

      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const LoginScreen()));
      // Navigator.of(context).pushNamedAndRemoveUntil(
      //     '/login', (Route<dynamic> route) => false
      // );
    });
  }

  static Future<void> deleteMessage(Message message)async{
    await firestore.collection('chats/${getConversationId(message.toId)}/messages/')
        .doc(message.sent).delete();

    if(message.type == Type.image){
      await fStorage.refFromURL(message.message).delete();
    }
  }

  static Future<void> updateMessage(Message message, String updatedMessage)async{

    await firestore.collection('chats/${getConversationId(message.toId)}/messages/')
        .doc(message.sent).update({ 'message': updatedMessage});
  }

  static Future<void> saveImageToGallery(String imageURL,BuildContext context) async {
    try {
      final response = await http.get(Uri.parse(imageURL));
      if (response.statusCode == 200) {
        final uint8List = response.bodyBytes;
        final result = await ImageGallerySaver.saveImage(uint8List);
        if (result != null) {
          Dialogs.showSnackBar(context,'Image saved to gallery');
        } else {
          log('Error');
        }
      } else {
        log('Error');
      }
    } catch (e) {
      Dialogs.showSnackBar(context, 'Error in Saving Image');
    }
  }

  static Future<bool> blockUser(String email)async{
    final data = await firestore.collection('users').where('email', isEqualTo: email).get();

    if(data.docs.isNotEmpty && data.docs.first.id != user.uid){
      await firestore.collection('users').doc(user.uid).collection('blocked_users').doc(data.docs.first.id).set({});
      await firestore.collection('users').doc(user.uid).collection('my_users').doc(data.docs.first.id).delete();
      return true;
    }
    else{
      return false;
    }

  }

  static Future<bool> unBlockUser(String email)async{
    final data = await firestore.collection('users').where('email', isEqualTo: email).get();

    if(data.docs.isNotEmpty && data.docs.first.id != user.uid){
      await firestore.collection('users').doc(user.uid).collection('my_users').doc(data.docs.first.id).set({});
      await firestore.collection('users').doc(user.uid).collection('blocked_users').doc(data.docs.first.id).delete();
      return true;
    }
    else{
      return false;
    }

  }


  static Future<void> updateXPostViews({required String pId, required int views})async{
    await firestore.collection('posts').doc(pId).update({
      'postViews' : views.toString(),
    });
  }

  static Future<void> updateXCallAction({required String pId, required int aCount})async{
    await firestore.collection('posts').doc(pId).update({
      'callAction' : aCount.toString(),
    });
  }

  static Future<void> updateXChatAction({required String pId, required int aCount})async{
    await firestore.collection('posts').doc(pId).update({
      'chatAction' : aCount.toString(),
    });
  }


  static Stream<QuerySnapshot<Map<String,dynamic>>> getBlockedUsers(){
    return firestore.collection('users').doc(user.uid).collection('blocked_users').snapshots();
  }

  // POSTS


  static Stream<QuerySnapshot<Map<String,dynamic>>>? getAllJobs(){
    return firestore.collection('posts').where('isJob', isEqualTo: true).snapshots();
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getAllServices(){
    return firestore.collection('posts').where('isJob', isEqualTo: false).snapshots();
  }


  static Stream<QuerySnapshot<Map<String,dynamic>>>? getMyJobs(String email){
    return firestore.collection('posts').where('isJob', isEqualTo: true).where("email", isEqualTo: email).snapshots();
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getMyServices(String email){
    return firestore.collection('posts').where('isJob', isEqualTo: false).where("email", isEqualTo: email).snapshots();
  }

  static Future<void> savePost(String postId)async{
  await firestore.collection('users').doc(user.uid).collection('savedPosts').doc(postId).set({
    'WYTB': true
  });
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>> getSavedPosts(){
    return firestore.collection('users').doc(user.uid).collection('savedPosts').snapshots();
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getSavedJobs(List<String> mySavedPosts){
    if(mySavedPosts.isNotEmpty) {
      return firestore.collection('posts')
          .where('isJob', isEqualTo: true)
          .where('id', whereIn: mySavedPosts)
          .snapshots();
    }
    return null;
  }

  static Stream<QuerySnapshot<Map<String,dynamic>>>? getSavedServices(List<String> mySavedPosts){
    if(mySavedPosts.isNotEmpty) {
      return firestore.collection('posts')
          .where('isJob', isEqualTo: false)
          .where('id', whereIn: mySavedPosts)
          .snapshots();
    }
    return null;
  }

  static Future<void> unSavePost(String postId)async{
    await firestore.collection('users').doc(user.uid).collection('savedPosts').doc(postId).delete();
  }

  static Future<ChatUser?> getPostUserWEmail(String emailW, String nameX) async {
    ChatUser? userX;
    List<DocumentSnapshot> lo;

    QuerySnapshot querySnapshot = await firestore.collection('users').where('email', isEqualTo: emailW).get();

    if (querySnapshot.docs.isNotEmpty) {
      lo = querySnapshot.docs;
      for( DocumentSnapshot a in lo){
        var data = a.data() as Map<String, dynamic>;
        userX = ChatUser.fromJson(data);
        if(userX.name == nameX){
          return userX;
        }
      }
    }
  }

  static Future<void> deleteMyPost(String postId, bool hasImage, String imgUrl)async{
    await firestore.collection('posts').doc(postId).delete();

    if(hasImage){
      await fStorage.refFromURL(imgUrl.toString()).delete();
    }
  }

  static Future<void> createNewJobPost({required String jPhone, required String jCity, required String jVisibility, required String jRequirements, required String jSalaryCurrency,required String longitude, required String latitude, required String jImage, required String jDesc, required String jState, required bool jisItAWorkFromHome, required String jSalary, required String jSalaryPer, required String jType, required String jTitle, required String jStreetAddress}) async{
  final time = DateTime.now().millisecondsSinceEpoch.toString();
  final newJob = JobPost(
      chatAction: "0",
      callAction: "0",
      postViews: "0",
      jPhone: jPhone,
      id: time,
      jTitle: jTitle,
      jDesc: jDesc,
      jVisibility: jVisibility,
      jRequirements: jRequirements,
      jSalaryCurrency: jSalaryCurrency,
      latitude: latitude,
      longitude: longitude,
      jImage: jImage,
      jStreetAddress: jStreetAddress,
      jState: jState,
      jCity: jCity,
      jisItAWorkFromHome: jisItAWorkFromHome,
      jSalary: jSalary,
      jSalaryPer: jSalaryPer,
      jType: jType,
      likes: "0",
      email: me.email,
      name: me.name,
      isJob: true,
      uploadTime: time,
      image: me.image,
  );
  return (await firestore.collection('posts').doc(time).set(newJob.toJson()));
}

  static Future<void> createNewServicePost({required String sPhone, required String sFeesPer, required String sVisibility, required String latitude, required String longitude, required String sCity,required String sTitle, required String sDesc, required String sFees, required String sState, required String sStreetAddress, required String sImage, required String sFeesCurrency}) async{
    final time = DateTime.now().millisecondsSinceEpoch.toString();
    final newService = ServicePost(
        postViews: "0",
        callAction: "0",
        chatAction: "0",
        sPhone: sPhone,
        id: time,
        isJob: false,
        sVisibility: sVisibility,
        sFeesPer: sFeesPer,
        latitude: latitude,
        longitude: longitude,
        sCity: sCity,
        sTitle: sTitle,
        sDesc: sDesc,
        sFees: sFees,
        sState: sState,
        sStreetAddress: sStreetAddress,
        sImage: sImage,
        sFeesCurrency: sFeesCurrency,
        image: me.image,
        likes: "0",
        email: me.email,
        name: me.name,
        uploadTime: time,
    );
    return (await firestore.collection('posts').doc(time).set(newService.toJson()));
  }




// static Future<void> deleteAirChat(String acID, bool hasImage, String imgUrl)async{
  //   await firestore.collection('air_chats').doc(acID).delete();
  //
  //
  //   QuerySnapshot querySnapshot = await firestore.collection('air_chats').doc(acID).collection('likes').get();
  //   for (QueryDocumentSnapshot docSnapshot in querySnapshot.docs) {
  //     await docSnapshot.reference.delete();
  //   }
  //   //await firestore.collection('air_chats').doc(acID).collection('likes').doc().delete();
  //
  //
  //   if(hasImage){
  //     await fStorage.refFromURL(imgUrl.toString()).delete();
  //   }
  // }




// static Future<void> createNewAirChat(String longitude, String latitude, String contentImage, String contentText)async{
//   final time = DateTime.now().millisecondsSinceEpoch.toString();
//   final newChat = JsonAirChat(
//     email: user.email.toString(),
//     name: user.displayName.toString(),
//     image: user.photoURL.toString(),
//     longitude: longitude,
//     latitude: latitude,
//     likes: "0",
//     contentImage: contentImage ?? "",
//     contentText: contentText,
//     uploadTime: time,
//   );
//   return (await firestore.collection('air_chats').doc(time).set(newChat.toJson()));
// }



// static Future<List<DocumentSnapshot>> fetchAirChats() async {
//   final CollectionReference airChatsFireRef = FirebaseFirestore.instance.collection('air_chats');
//   late List<DocumentSnapshot> documents;
//   QuerySnapshot querySnapshot = await airChatsFireRef.get();
//     documents = querySnapshot.docs;
//     return documents;
// }



// static Future<String> uploadAirChatImage(File file) async {
//   final time = DateTime.now().millisecondsSinceEpoch.toString();
//
//   final ext = file.path.split('.').last;
//   final ref = fStorage.ref().child('air_chat_images/$time.$ext');
//   await ref.putFile(file, SettableMetadata(contentType: "image/$ext")).then((p0) {
//     log("---- Data Transfferred : ${p0.bytesTransferred / 1000} kb ----");
//   });
//   return await ref.getDownloadURL();
// }




// static Future<void> likeAirChat(String airChatId, bool isLiked, int prevLikes)async{
//   await firestore.collection('air_chats').doc(airChatId).collection('likes').doc(user.uid).set({
//     'isLiked': isLiked,
//   });
//
//   if(isLiked){
//     await firestore.collection('air_chats').doc(airChatId).update({
//       'likes': '${prevLikes}',
//     });
//   }
//   else if(!isLiked){
//     await firestore.collection('air_chats').doc(airChatId).update({
//       'likes': '${prevLikes}',
//     });
//   }
// }

// static Future<void> checkLikeStatus(String airChatId)async {
//   // await firestore.collection('air_chats').doc(airChatId).get('');
//   // 'likes.${user.uid}',
//
//   Future<dynamic> getValueFromMap(String airChatId) async {
//     DocumentSnapshot<Map<String, dynamic>> documentSnapshot = await firestore.collection('air_chats').doc(airChatId).get();
//
//     if (documentSnapshot.exists) {
//       Map<String, dynamic> data = documentSnapshot.data()!;
//       // Check if the key exists in the map
//       if (data.containsKey(user.uid)) {
//         return data[user.uid];
//       } else {
//         log('---- YOU HAVE NOT LIKED THIS POST ----');
//         return null; // Key doesn't exist in the map
//       }
//     } else {
//       log('---- YOU HAVE NOT LIKED THIS POST ----');
//       return null; // Document doesn't exist
//     }
//   }
//
//   void fetchValue() async {
//
//     dynamic value = await getValueFromMap(airChatId);
//
//     if (value != null) {
//       log('---- YOU HAVE LIKED THIS POST ----');
//     } else {
//       log('---- YOU HAVE NOT LIKED THIS POST ----');
//     }
//   }
//
// }


// static Future<List<Map<String, dynamic>>> getLikeListOfAirChat(String airChatId) async {
//   List<Map<String, dynamic>> documentsList = [];
//   QuerySnapshot<Map<String, dynamic>> querySnapshot = await FirebaseFirestore.instance.collection('air_chat').doc(airChatId).collection('likes').get();
//
//   for (var doc in querySnapshot.docs) {
//     documentsList.add(doc.data());
//   }
//   return documentsList;
// }


// static Stream<QuerySnapshot<Map<String,dynamic>>>? fetchAirChats(){
//   return  firestore.collection('air_chats').snapshots();
// }



}