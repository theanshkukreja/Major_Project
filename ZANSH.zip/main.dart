import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:zansh/screens/chatsScreen.dart';
import 'package:zansh/screens/home/homeOne.dart';
import 'package:zansh/screens/homeScreen.dart';
import 'package:zansh/screens/homeScreenX.dart';
import 'package:zansh/screens/profileAddons/viewMyPosts.dart';
import 'package:zansh/screens/splashScreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'api/apis.dart';
import 'auth/loginScreen.dart';
import 'firebase_options.dart';

late Size mq;
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]).then((value) {
    initializeFirebase();
    runApp(const MyApp());
  });

}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ZANSH',
      theme: ThemeData(
        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Colors.white70,
          selectionColor: Colors.blue,
          selectionHandleColor: Colors.blue,

        ),
        appBarTheme: const AppBarTheme(
          color: Colors.black,
          centerTitle: true,
          iconTheme: IconThemeData(
            color: Colors.white,
          )
        ),
        colorScheme: const ColorScheme.dark(primary: Colors.black, background: Colors.black),
        useMaterial3: true,
      ),
      home: const SplashScreen(),

      routes: {
        '/home': (context) => const HomeOne(),
        '/homeScreen': (context) => const HomeScreen(),
        '/homeN': (context) => const HomeScreenX(),
        '/login': (context) => const LoginScreen(),
        '/chats': (context) => const ChatScreen(),
        '/viewMyPosts': (context) => ViewMyPosts(email: APIs.me.email, isMe: true),
      },
    );
  }
}

void initializeFirebase()async{
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

